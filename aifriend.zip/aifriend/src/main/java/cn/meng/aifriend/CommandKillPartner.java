package cn.meng.aifriend;

import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.text.TextComponentString;

import java.util.List;

public class CommandKillPartner extends CommandBase {

    @Override
    public String getName() { return "killpartner"; }

    @Override
    public String getUsage(ICommandSender sender) { return "/killpartner"; }

    @Override
    public void execute(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {
        EntityPlayer player = getCommandSenderAsPlayer(sender);
        List<AIPartnerEntity> list = player.world.getEntities(AIPartnerEntity.class, e -> true);
        if (list.isEmpty()) {
            player.sendMessage(new TextComponentString("当前没有伙伴"));
            return;
        }
        for (AIPartnerEntity p : list) p.setDead();
        player.sendMessage(new TextComponentString("伙伴已销毁"));
    }
}