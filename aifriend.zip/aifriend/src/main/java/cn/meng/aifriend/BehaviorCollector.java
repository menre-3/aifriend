package cn.meng.aifriend;

import net.minecraft.block.Block;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.world.BlockEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent;

@Mod.EventBusSubscriber(modid = AIFriendMod.MODID)
public class BehaviorCollector {

    @SubscribeEvent
    public static void onBreak(BlockEvent.BreakEvent event) {
        EntityPlayer p = event.getPlayer();
        if (p == null || p.world.isRemote) return;
        Block b = event.getState().getBlock();
        if (isImportant(b)) {
            MemoryManager.record(p.getName() + " 挖到了 " + b.getLocalizedName());
        }
    }

    @SubscribeEvent
    public static void onCraft(PlayerEvent.ItemCraftedEvent event) {
        if (event.player.world.isRemote) return;
        ItemStack stack = event.crafting;
        MemoryManager.record(event.player.getName() + " 合成了 " + stack.getDisplayName());
    }

    @SubscribeEvent
    public static void onKill(LivingDeathEvent event) {
        if (event.getSource().getTrueSource() instanceof EntityPlayer) {
            EntityPlayer p = (EntityPlayer) event.getSource().getTrueSource();
            MemoryManager.record(p.getName() + " 击杀了 " + event.getEntityLiving().getName());
        }
    }

    private static boolean isImportant(Block b) {
        return b == Blocks.DIAMOND_ORE || b == Blocks.LAPIS_ORE || b == Blocks.GOLD_ORE
                || b == Blocks.IRON_ORE || b == Blocks.COAL_ORE || b == Blocks.EMERALD_ORE
                || b == Blocks.MOB_SPAWNER || b == Blocks.CHEST || b == Blocks.DIAMOND_BLOCK;
    }
}