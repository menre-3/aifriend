package cn.meng.aifriend;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * 配置守卫：AI 通过 @@CFG@@ 动态调整模组参数时，必须经过白名单 + 范围钳制。
 * 三道闸：①白名单 ②范围钳制 ③敏感项永久禁止。
 */
public class ConfigGuard {

    private enum Type { DOUBLE, INT, BOOL }

    private static class Param {
        final Type type;
        final double min, max;
        Param(Type type, double min, double max) { this.type = type; this.min = min; this.max = max; }
    }

    // 内置白名单（安全基线，不可移除）
    private static final Map<String, Param> BUILTIN = new HashMap<>();
    static {
        BUILTIN.put("personality_talkative", new Param(Type.DOUBLE, 0.1, 5.0));
        BUILTIN.put("speak_budget_max",       new Param(Type.INT,    1,   20));
        BUILTIN.put("think_interval",         new Param(Type.INT,    100, 1200));
        BUILTIN.put("task_interval",          new Param(Type.INT,    20,  600));
        BUILTIN.put("auto_speak",             new Param(Type.BOOL,   0,   1));
        BUILTIN.put("auto_think",             new Param(Type.BOOL,   0,   1));
    }

    // 永久禁止修改（不受 cfg_whitelist 影响）
    private static final Set<String> FORBIDDEN = new HashSet<>(Arrays.asList(
            "api_url", "api_key", "model", "api_timeout", "reply_max_tokens"
    ));

    /** 尝试应用 @@CFG@@ key=value；成功返回 true */
    public static synchronized boolean apply(String key, String value) {
        if (key == null || value == null) return false;
        key = key.trim();
        value = value.trim();
        if (FORBIDDEN.contains(key)) return false; // 敏感项：直接拒绝
        Param p = BUILTIN.get(key);
        if (p == null) return false; // 不在内置白名单（cfg_whitelist 扩展本期不处理）
        return applyBuiltin(key, value, p);
    }

    private static boolean applyBuiltin(String key, String value, Param p) {
        try {
            switch (p.type) {
                case DOUBLE: {
                    double d = Double.parseDouble(value);
                    d = Math.max(p.min, Math.min(p.max, d)); // 钳制
                    if ("personality_talkative".equals(key)) AIFriendMod.personalityTalkative = d;
                    return true;
                }
                case INT: {
                    int i = Integer.parseInt(value);
                    i = (int) Math.max(p.min, Math.min(p.max, i)); // 钳制
                    if ("speak_budget_max".equals(key)) AIFriendMod.speakBudgetMax = i;
                    else if ("think_interval".equals(key)) AIFriendMod.thinkInterval = i;
                    else if ("task_interval".equals(key)) AIFriendMod.taskInterval = i;
                    return true;
                }
                case BOOL: {
                    boolean b = "1".equals(value) || "true".equalsIgnoreCase(value);
                    if ("auto_speak".equals(key)) AIFriendMod.autoSpeak = b;
                    else if ("auto_think".equals(key)) AIFriendMod.autoThink = b;
                    return true;
                }
                default:
                    return false;
            }
        } catch (Exception e) {
            return false; // 非法值：忽略，不崩
        }
    }
}