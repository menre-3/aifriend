package cn.meng.aifriend;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.text.TextComponentString;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.EntityItemPickupEvent;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

import java.util.List;

@Mod.EventBusSubscriber(modid = AIFriendMod.MODID)
public class EventSpeaker {

    private static long lastSpeak = 0;
    private static int periodicTimer = 0;

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent event) {
        if (!(event.getEntityLiving() instanceof EntityPlayer)) return;
        speak((EntityPlayer) event.getEntityLiving(), "主人刚刚死亡了，说一句话安慰或吐槽他");
    }

    @SubscribeEvent
    public static void onHurt(LivingHurtEvent event) {
        if (!(event.getEntityLiving() instanceof EntityPlayer)) return;
        EntityPlayer p = (EntityPlayer) event.getEntityLiving();
        if (p.getHealth() < 6.0F) {
            speak(p, "主人血量很低很危险，说一句话提醒他注意安全");
        }
    }

    @SubscribeEvent
    public static void onPickup(EntityItemPickupEvent event) {
        if (!(event.getEntity() instanceof EntityPlayer)) return;
        if (event.getItem().getItem().getItem() != Items.DIAMOND) return;
        speak((EntityPlayer) event.getEntity(), "主人挖到了钻石，说一句话祝贺他");
    }

    // 周期主动发言：每120秒，AI主动看情况说一句
    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        periodicTimer++;
        if (periodicTimer < 2400) return; // 120秒
        periodicTimer = 0;
        MinecraftServer server = FMLCommonHandler.instance().getMinecraftServerInstance();
        if (server == null) return;
        for (net.minecraft.world.World w : server.worlds) {
            if (w == null) continue;
            List<AIPartnerEntity> list = w.getEntities(AIPartnerEntity.class, e -> true);
            for (AIPartnerEntity partner : list) {
                EntityPlayer owner = partner.getOwnerPlayer();
                if (owner != null) {
                    speak(owner, "看看当前的天气、时间、环境情况，以伙伴身份主动说一句合适的话");
                }
            }
        }
    }

    private static void speak(EntityPlayer player, String eventDesc) {
        if (player == null || player.world.isRemote) return;
        if (!AIFriendMod.autoSpeak) return;

        long cooldown = (long) (30_000L * AIFriendMod.personalityTalkative);
        long now = System.currentTimeMillis();
        if (now - lastSpeak < cooldown) return;

        List<AIPartnerEntity> list = player.world.getEntities(AIPartnerEntity.class, e -> true);
        if (list.isEmpty()) return;
        final AIPartnerEntity partner = list.get(0);
        if (!partner.getSpeakBudget().canSpeak()) return;

        final EntityPlayer p = player;
        new Thread(() -> {
            String text = null;
            try {
                text = AiApiClient.speak(p, eventDesc);
            } catch (Exception e) {
                text = null;
            }
            final String result = text;
            if (result == null) return;
            if (p.getServer() != null) {
                p.getServer().addScheduledTask(() -> {
                    if (partner.getSpeakBudget().consume()) {
                        lastSpeak = System.currentTimeMillis();
                        p.sendMessage(new TextComponentString(AIFriendMod.partnerName + ": " + result));
                    }
                });
            }
        }).start();
    }
}