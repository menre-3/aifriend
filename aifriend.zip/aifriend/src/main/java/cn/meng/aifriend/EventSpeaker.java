package cn.meng.aifriend;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.util.text.TextComponentString;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.EntityItemPickupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import java.util.List;

/**
 * 主动发言：监听状态事件，触发 AI 以"名字+性格"说一句话。
 * 双重限制：SpeakBudget（8句）+ 发言冷却（受表达欲影响）。
 */
@Mod.EventBusSubscriber(modid = AIFriendMod.MODID)
public class EventSpeaker {

    private static long lastSpeak = 0; // 全局发言冷却时间戳（单伙伴场景）

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent event) {
        if (!(event.getEntityLiving() instanceof EntityPlayer)) return;
        EntityPlayer p = (EntityPlayer) event.getEntityLiving();
        speak(p, "主人刚刚死亡了，说一句话安慰/吐槽他");
    }

    @SubscribeEvent
    public static void onPickup(EntityItemPickupEvent event) {
        if (!(event.getEntity() instanceof EntityPlayer)) return;
        if (event.getItem().getItem().getItem() != Items.DIAMOND) return;
        speak((EntityPlayer) event.getEntity(), "主人挖到了钻石，说一句话祝贺他");
    }

    /** 尝试主动发言（只在重要事件触发） */
    private static void speak(EntityPlayer player, String eventDesc) {
        if (player == null || player.world.isRemote) return;
        if (!AIFriendMod.autoSpeak) return; // 主动发言开关

        // 冷却：基础30秒 * 表达欲（数值越小越频繁，性格影响）
        long cooldown = (long) (30_000L * AIFriendMod.personalityTalkative);
        long now = System.currentTimeMillis();
        if (now - lastSpeak < cooldown) return;

        AIPartnerEntity partner = findPartner(player);
        if (partner == null) return;
        if (!partner.getSpeakBudget().canSpeak()) return; // 预算用尽

        final EntityPlayer p = player;
        new Thread(() -> {
            String text = null;
            try {
                text = AiApiClient.speak(p, eventDesc);
            } catch (Exception e) {
                text = null;
            }
            final String result = text;
            if (result == null) return; // API 失败：不消耗预算
            if (p.getServer() != null) {
                p.getServer().addScheduledTask(() -> {
                    if (partner.getSpeakBudget().consume()) { // 成功才消耗
                        lastSpeak = System.currentTimeMillis();
                        p.sendMessage(new TextComponentString(AIFriendMod.partnerName + ": " + result));
                    }
                });
            }
        }).start();
    }

    private static AIPartnerEntity findPartner(EntityPlayer player) {
        List<AIPartnerEntity> list = player.world.getEntities(AIPartnerEntity.class, e -> true);
        return list.isEmpty() ? null : list.get(0);
    }
}