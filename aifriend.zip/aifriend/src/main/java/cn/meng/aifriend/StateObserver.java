package cn.meng.aifriend;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * 状态学习（通用版）：观察"玩家所处的条件 + 条件触发的状态变化"，
 * 自动学习游戏机制。加新规则只需往 PROBES 加一条。
 */
@Mod.EventBusSubscriber(modid = AIFriendMod.MODID)
public class StateObserver {

    /** 一条规则 = 条件判定 + 学到的描述 */
    private interface Probe {
        boolean active(EntityPlayer p);
        String rule();
    }

    private interface StatePredicate { boolean test(EntityPlayer p); }

    private static Probe probe(StatePredicate pred, String rule) {
        return new Probe() {
            public boolean active(EntityPlayer p) { return pred.test(p); }
            public String rule() { return rule; }
        };
    }

    /** 通用"条件 -> 状态"规则表（可无限扩展） */
    private static final List<Probe> PROBES = Arrays.asList(
        probe(p -> p.isInWater(), "玩家触碰到水时会游泳，身体趴下，判定高度只有1格高"),
        probe(p -> p.isBurning(), "玩家着火时会持续扣血，要跳进水里或灭火"),
        probe(p -> p.isOnLadder(), "玩家贴着梯子可以上下爬"),
        probe(p -> p.getAir() < 280, "玩家泡在水里太久会溺水，氧气条耗光会扣血"),
        probe(p -> p.getFoodStats().getFoodLevel() < 6, "玩家饥饿值过低时会掉血，需要吃东西"),
        probe(p -> p.getHealth() < 6.0F, "玩家血量过低时很危险，需要尽快回血"),
        probe(p -> p.isSprinting(), "玩家疾跑时移动速度更快"),
        probe(p -> p.isSneaking(), "玩家潜行时不会从方块边缘掉下去"),
        probe(p -> p.world.isRaining() && p.world.isThundering(), "雷雨天气会有雷声，露天可能被雷劈"),
        probe(p -> !p.world.isDaytime(), "夜晚会刷新怪物，要小心或躲进屋里")
    );

    // 每个玩家上次各状态（单人场景 1 个玩家）
    private static final Map<UUID, boolean[]> last = new HashMap<>();

    @SubscribeEvent
    public static void onUpdate(LivingEvent.LivingUpdateEvent event) {
        if (!(event.getEntityLiving() instanceof EntityPlayer)) return;
        EntityPlayer p = (EntityPlayer) event.getEntityLiving();
        if (p.world.isRemote) return; // 仅服务端

        UUID id = p.getUniqueID();
        boolean[] cur = new boolean[PROBES.size()];
        for (int i = 0; i < PROBES.size(); i++) cur[i] = PROBES.get(i).active(p);

        boolean[] old = last.get(id);
        if (old == null) { last.put(id, cur); return; } // 首次记录，不学习

        for (int i = 0; i < PROBES.size(); i++) {
            if (!old[i] && cur[i]) { // 状态变化边沿：false -> true 才学习
                KnowledgeStore.learn(PROBES.get(i).rule());
            }
        }
        last.put(id, cur);
    }
}