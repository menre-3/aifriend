package cn.meng.aifriend;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.server.MinecraftServer;

public class AIBrain {

    private final IPartnerBody body;
    private int thinkTimer = 0;   // 决策冷却计时
    private int execTimer = 0;    // 执行后忙碌计时
    private int watchdog = 0;     // thinking 看门狗
    private boolean thinking = false;
    private int generation = 0;   // 请求代数，防过期回调
    private IGoal goal;

    public AIBrain(IPartnerBody body) {
        this.body = body;
        this.goal = new SelfImproveGoal(); // 默认自我提升目标
    }

    public IPartnerBody getBody() { return this.body; }
    public IGoal getGoal() { return this.goal; }
    public void setGoal(IGoal g) { this.goal = g; }

    /** 每 tick 由身体调用 */
    public void onTick() {
        if (!this.body.isAlive()) return;
        if (this.execTimer > 0) { this.execTimer--; return; } // 忙碌跳过

        this.thinkTimer++;
        // 看门狗：思考超时强制释放锁，防永久卡死
        if (this.thinking) {
            this.watchdog++;
            if (this.watchdog >= 800) {
                this.thinking = false;
                this.watchdog = 0;
            }
        }
        if (this.thinkTimer >= currentInterval()) {
            this.thinkTimer = 0;
            think();
        }
    }

    /** 分档冷却：有任务用短间隔，无任务用长间隔 */
    private int currentInterval() {
        return (this.goal != null && !this.goal.isDone())
                ? AIFriendMod.taskInterval : AIFriendMod.thinkInterval;
    }

    /** 重生/外部事件后强制触发一次思考 */
    public void forceThink() {
        this.thinkTimer = Math.max(0, currentInterval() - 1);
        this.execTimer = 0;
        this.thinking = false;
        this.watchdog = 0;
    }

    private void think() {
        if (!AIFriendMod.autoThink) return; // 自主开关
        if (this.thinking) return;          // 上一轮未结束

        final EntityPlayer owner = this.body.getOwner();
        if (owner == null) return;          // 主人不在，不思考

        this.thinking = true;
        this.watchdog = 0;
        final int gen = ++this.generation;  // 代数自增，防过期回调

        final boolean hasGoal = (this.goal != null && !this.goal.isDone());
        final String prompt = hasGoal ? this.goal.getDecisionPrompt() : null;
        final float yaw = this.body.getRotationYaw();

        // 异步请求，绝不阻塞主线程
        new Thread(() -> {
            String text = null;
            try {
                if (prompt != null) text = AiApiClient.decideTask(owner, prompt, yaw);
                else text = AiApiClient.decideKeys(owner, yaw);
            } catch (Exception e) {
                text = null;
            }
            final String result = text;
            scheduleOnMain(() -> {
                if (gen != this.generation) return; // 过期回调丢弃
                this.thinking = false;
                this.watchdog = 0;
                if (result == null) { this.body.walk(0, 0, false); return; }
                // 主线程重新校验 goal 状态（不用异步快照）
                if (this.goal != null && !this.goal.isDone()) {
                    this.goal.applyResult(this, owner, result);
                } else {
                    ActionParser.execute(this, result);
                }
                this.execTimer = 40; // 执行后约2秒不再思考
            });
        }).start();
    }

    /** 回主线程执行，owner 判空 + 兜底，绝不死锁 */
    private void scheduleOnMain(Runnable r) {
        try {
            EntityPlayer o = this.body.getOwner();
            if (o == null || o.world == null) { r.run(); return; }
            MinecraftServer server = o.world.getMinecraftServer();
            if (server != null) server.addScheduledTask(r);
            else r.run();
        } catch (Exception e) {
            e.printStackTrace();
            this.thinking = false;
        }
    }
}