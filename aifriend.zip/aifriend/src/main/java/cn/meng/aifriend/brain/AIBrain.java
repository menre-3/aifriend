package cn.meng.aifriend.brain;

import cn.meng.aifriend.AIFriendConfig;
import cn.meng.aifriend.api.IPartnerBody;
import cn.meng.aifriend.info.EnvironmentInfo;
import cn.meng.aifriend.info.KnowledgeStore;
import cn.meng.aifriend.info.MemoryManager;
import cn.meng.aifriend.info.WorldEventSource;
import cn.meng.aifriend.lang.PromptBuilder;
import cn.meng.aifriend.lang.SpeakBudget;
import cn.meng.aifriend.net.AiApiClient;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import org.apache.logging.log4j.Logger;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * AI大脑（核心决策）
 */
public class AIBrain {

    private final AIFriendConfig config;
    private final IPartnerBody body;
    private final AiApiClient apiClient;
    private final EnvironmentInfo environment;
    private final KnowledgeStore knowledgeStore;
    private final MemoryManager memory;
    private final PromptBuilder promptBuilder;
    private final ActionParser actionParser;
    private final SpeakBudget speakBudget;
    private final Logger logger;
    private final ExecutorService executor;

    private long lastDecisionTick = 0;
    private boolean isThinking = false;
    private BrainState currentState = BrainState.IDLE;
    private String currentGoal = "跟随玩家";
    private String lastAiResponse = "";

    public AIBrain(AIFriendConfig config, IPartnerBody body, AiApiClient apiClient,
                   EnvironmentInfo environment, KnowledgeStore knowledgeStore,
                   MemoryManager memory, Logger logger) {
        this.config = config;
        this.body = body;
        this.apiClient = apiClient;
        this.environment = environment;
        this.knowledgeStore = knowledgeStore;
        this.memory = memory;
        this.logger = logger;
        this.promptBuilder = new PromptBuilder(config);
        this.actionParser = new ActionParser();
        this.speakBudget = new SpeakBudget(config.speakBudgetMax);
        this.executor = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "AI-Brain");
            t.setDaemon(true);
            return t;
        });
    }

    public void tick(long worldTick) {
        if (worldTick - lastDecisionTick < config.decisionIntervalTicks) return;
        if (isThinking) return;
        lastDecisionTick = worldTick;
        think();
    }

    private void think() {
        isThinking = true;
        CompletableFuture.supplyAsync(() -> {
            try {
                String context = buildContext();
                String prompt = promptBuilder.buildSystemPrompt() + "\n\n" + context
                        + "\n\n请根据当前情况做出反应。说话直接输出文本，动作用 @@ACT@@ 标记。";
                return apiClient.chat(prompt, memory.getRecentDialogue(config.memoryMaxTurns));
            } catch (Exception e) {
                logger.error("AI思考失败: {}", e.getMessage());
                return null;
            }
        }, executor).thenAccept(response -> {
            isThinking = false;
            if (response == null) return;
            lastAiResponse = response;
            ActionParser.ParseResult result = actionParser.parse(response);
            long tick = body.getWorldObject().getTotalWorldTime();
            if (result.hasSpeech() && speakBudget.canSpeak(tick)) {
                body.speak(result.speechText);
                memory.addAiMessage(result.speechText);
                speakBudget.consume(tick);
            }
            if (result.hasActions()) executeActions(result);
        });
    }

    private void executeActions(ActionParser.ParseResult result) {
        for (ActionParser.ActionIntent intent : result.actions) {
            try {
                executeSingleAction(intent);
            } catch (Exception e) {
                logger.error("执行动作失败 {}: {}", intent.action, e.getMessage());
            }
        }
    }

    private void executeSingleAction(ActionParser.ActionIntent intent) {
        switch (intent.action) {
            case "mine": {
                int x = intent.getIntParam("x", 0);
                int y = intent.getIntParam("y", 0);
                int z = intent.getIntParam("z", 0);
                body.getInteraction().mineBlock(new BlockPos(x, y, z));
                currentState = BrainState.WORKING;
                currentGoal = "挖掘方块";
                break;
            }
            case "attack": {
                EnvironmentInfo.EntityInfo hostile = environment.findNearestHostile();
                if (hostile != null && hostile.entityRef != null) {
                    body.getInteraction().attackEntity(hostile.entityRef);
                    body.setAttackTargetEntity(hostile.entityRef);
                    currentState = BrainState.COMBAT;
                    currentGoal = "战斗：" + hostile.name;
                }
                break;
            }
            case "follow": {
                if (body.getOwnerEntity() != null) {
                    body.getMovement().follow(body.getOwnerEntity(), config.followDistance);
                    currentState = BrainState.FOLLOWING;
                    currentGoal = "跟随玩家";
                }
                break;
            }
            case "move": {
                double x = intent.getDoubleParam("x", body.getPositionVec().x);
                double y = intent.getDoubleParam("y", body.getPositionVec().y);
                double z = intent.getDoubleParam("z", body.getPositionVec().z);
                body.getMovement().moveTo(new Vec3d(x, y, z), 1.0);
                currentState = BrainState.MOVING;
                break;
            }
            case "place": {
                int x = intent.getIntParam("x", 0);
                int y = intent.getIntParam("y", 0);
                int z = intent.getIntParam("z", 0);
                String itemName = intent.getParam("item");
                ItemStack stack = findItemInInventory(itemName);
                if (stack != null) body.getInteraction().placeBlock(new BlockPos(x, y, z), stack);
                break;
            }
            case "equip": {
                String itemType = intent.getParam("item");
                if (itemType != null) {
                    if (itemType.contains("sword") || itemType.contains("weapon")) body.getInventory().equipBetterWeapon();
                    else if (itemType.contains("armor") || itemType.contains("helmet") || itemType.contains("chestplate")
                            || itemType.contains("leggings") || itemType.contains("boots")) body.getInventory().equipBetterArmor();
                    else body.getInventory().equipBetterTool(itemType);
                }
                break;
            }
            case "sneak":
                body.setBodySneaking(true);
                break;
            case "jump":
                body.doJump();
                break;
            case "sprint":
                body.setBodySprinting(true);
                break;
            case "stop":
                body.getMovement().stopMoving();
                body.setBodySneaking(false);
                body.setBodySprinting(false);
                currentState = BrainState.IDLE;
                break;
            case "lookat": {
                double x = intent.getDoubleParam("x", 0);
                double y = intent.getDoubleParam("y", 0);
                double z = intent.getDoubleParam("z", 0);
                body.getMovement().lookAt(new Vec3d(x, y, z));
                break;
            }
            case "wander":
                body.getMovement().wander();
                currentState = BrainState.WANDERING;
                break;
            case "pickup": {
                EnvironmentInfo.EntityInfo item = environment.findNearestItem();
                if (item != null) body.getMovement().moveTo(item.position, 1.2);
                break;
            }
            case "defend": {
                if (body.getOwnerEntity() != null) {
                    EnvironmentInfo.EntityInfo hostile = environment.findNearestHostile();
                    if (hostile != null && hostile.entityRef != null) {
                        body.setAttackTargetEntity(hostile.entityRef);
                        currentState = BrainState.COMBAT;
                        currentGoal = "保护玩家";
                    } else {
                        body.getMovement().follow(body.getOwnerEntity(), 1.5);
                    }
                }
                break;
            }
            case "selfimprove":
                if (config.enableSelfImprove) {
                    body.getInventory().equipBetterArmor();
                    body.getInventory().equipBetterWeapon();
                }
                break;
            default:
                logger.debug("未知动作: {}", intent.action);
        }
    }

    private ItemStack findItemInInventory(String itemName) {
        if (itemName == null) return null;
        for (ItemStack stack : body.getInventory().getAllItems()) {
            if (stack != null && !stack.isEmpty()) {
                String name = stack.getItem().getRegistryName().toString();
                if (name.contains(itemName.toLowerCase()) || stack.getDisplayName().toLowerCase().contains(itemName.toLowerCase())) {
                    return stack;
                }
            }
        }
        return null;
    }

    private String buildContext() {
        StringBuilder ctx = new StringBuilder();
        ctx.append("【自身】名字：").append(config.partnerName).append("\n");
        ctx.append("位置：(").append(String.format("%.1f", body.getPositionVec().x)).append(",")
                .append(String.format("%.1f", body.getPositionVec().y)).append(",")
                .append(String.format("%.1f", body.getPositionVec().z)).append(")\n");
        ctx.append("生命：").append(body.getHealthValue()).append("/").append(body.getMaxHealthValue()).append("\n");
        ctx.append("状态：").append(currentState.getDisplayName()).append("，目标：").append(currentGoal).append("\n");
        ctx.append("背包：").append(body.getInventory().getInventorySummaryMap()).append("\n");
        ctx.append(environment.buildSummary()).append("\n");
        String eventSummary = WorldEventSource.buildSummary();
        if (!eventSummary.isEmpty()) ctx.append(eventSummary).append("\n");
        String dialogue = memory.buildDialogueContext();
        if (!dialogue.isEmpty()) ctx.append(dialogue).append("\n");
        String behavior = memory.buildBehaviorSummary();
        if (!behavior.isEmpty()) ctx.append(behavior).append("\n");
        String knowledge = knowledgeStore.retrieve(currentGoal, "生存");
        if (!knowledge.isEmpty()) ctx.append("【知识】\n").append(knowledge).append("\n");
        ctx.append("【发言预算】剩余").append(speakBudget.getRemaining()).append("/").append(config.speakBudgetMax).append("句\n");
        return ctx.toString();
    }

    public void onPlayerSpeak(String message) {
        memory.addPlayerMessage(message);
        CompletableFuture.supplyAsync(() -> {
            try {
                String context = buildContext();
                String prompt = promptBuilder.buildSystemPrompt() + "\n\n" + context
                        + "\n\n玩家对你说：" + message + "\n\n请回复，可以用 @@ACT@@ 执行动作。";
                return apiClient.chat(prompt, memory.getRecentDialogue(config.memoryMaxTurns));
            } catch (Exception e) {
                logger.error("AI回复失败: {}", e.getMessage());
                return null;
            }
        }, executor).thenAccept(response -> {
            if (response == null) return;
            lastAiResponse = response;
            ActionParser.ParseResult result = actionParser.parse(response);
            long tick = body.getWorldObject().getTotalWorldTime();
            if (result.hasSpeech()) {
                body.speak(result.speechText);
                memory.addAiMessage(result.speechText);
            }
            if (result.hasActions()) executeActions(result);
        });
    }

    public void onUrgentEvent(String description) {
        logger.info("紧急事件: {}", description);
        lastDecisionTick = 0;
    }

    public BrainState getCurrentState() { return currentState; }
    public String getCurrentGoal() { return currentGoal; }
    public String getLastAiResponse() { return lastAiResponse; }
    public boolean isThinking() { return isThinking; }
    public SpeakBudget getSpeakBudget() { return speakBudget; }

    public void shutdown() {
        executor.shutdownNow();
    }

    public enum BrainState {
        IDLE("空闲"), FOLLOWING("跟随"), MOVING("移动"), WORKING("工作"),
        COMBAT("战斗"), WANDERING("闲逛"), INTERACTING("互动");
        private final String displayName;
        BrainState(String displayName) { this.displayName = displayName; }
        public String getDisplayName() { return displayName; }
    }
}
