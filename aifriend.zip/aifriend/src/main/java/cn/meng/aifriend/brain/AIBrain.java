package com.aifriend.brain;

import com.aifriend.AIFriendConfig;
import com.aifriend.api.IPartnerBody;
import com.aifriend.info.EnvironmentInfo;
import com.aifriend.info.KnowledgeStore;
import com.aifriend.info.MemoryManager;
import com.aifriend.info.WorldEventSource;
import com.aifriend.lang.PromptBuilder;
import com.aifriend.lang.SpeakBudget;
import com.aifriend.net.AiApiClient;
import org.apache.logging.log4j.Logger;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * AI大脑（核心决策模块）
 *
 * 职责：
 * 1. 收集环境信息、事件、记忆、知识库，构建上下文
 * 2. 调用大模型API，获取AI的决策（文本回复 + 动作意图）
 * 3. 解析动作意图，通过 IPartnerBody 接口让身体执行
 * 4. 管理决策优先级：指令 > 避险 > 成长 > 跟随 > 互动
 *
 * 设计原则：
 * - AI负责"聪明地选择做什么"，模组端负责"可靠地执行"
 * - 所有API调用异步执行，不阻塞游戏主线程
 * - 决策有冷却间隔，避免频繁调用
 */
public class AIBrain {

    private final AIFriendConfig config;
    private final IPartnerBody body;
    private final AiApiClient apiClient;
    private final EnvironmentInfo environment;
    private final WorldEventSource eventSource;
    private final KnowledgeStore knowledgeStore;
    private final MemoryManager memory;
    private final PromptBuilder promptBuilder;
    private final ActionParser actionParser;
    private final SpeakBudget speakBudget;
    private final Logger logger;

    // 异步执行器
    private final ExecutorService executor = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "AI-Brain-Thread");
        t.setDaemon(true);
        return t;
    });

    // 决策状态
    private long lastDecisionTick = 0;
    private boolean isThinking = false;
    private BrainState currentState = BrainState.IDLE;
    private String currentGoal = "跟随玩家";

    // 最近一次AI回复（用于调试）
    private String lastAiResponse = "";

    public AIBrain(AIFriendConfig config, IPartnerBody body,
                   AiApiClient apiClient, EnvironmentInfo environment,
                   WorldEventSource eventSource, KnowledgeStore knowledgeStore,
                   MemoryManager memory, Logger logger) {
        this.config = config;
        this.body = body;
        this.apiClient = apiClient;
        this.environment = environment;
        this.eventSource = eventSource;
        this.knowledgeStore = knowledgeStore;
        this.memory = memory;
        this.logger = logger;
        this.promptBuilder = new PromptBuilder(config);
        this.actionParser = new ActionParser();
        this.speakBudget = new SpeakBudget(config.getSpeakBudgetMax());
    }

    /**
     * 每tick调用，决定是否需要思考
     */
    public void tick(long worldTick) {
        // 检查是否到了决策间隔
        if (worldTick - lastDecisionTick < config.getDecisionIntervalTicks()) {
            return;
        }
        if (isThinking) {
            return; // 上一次思考还没完成
        }

        lastDecisionTick = worldTick;
        think();
    }

    /**
     * 执行一次思考（异步）
     */
    private void think() {
        isThinking = true;

        CompletableFuture.supplyAsync(() -> {
            try {
                // 1. 构建上下文
                String context = buildContext();

                // 2. 构建prompt
                String prompt = promptBuilder.buildSystemPrompt()
                        + "\n\n" + context
                        + "\n\n请根据当前情况做出反应。如果要说话，直接输出文本；如果要执行动作，使用 @@ACT@@ 标记。";

                // 3. 调用API
                String response = apiClient.chat(prompt, memory.getRecentDialogue(config.getMemoryMaxTurns()));
                return response;
            } catch (Exception e) {
                logger.error("AI思考失败: {}", e.getMessage());
                return null;
            }
        }, executor).thenAccept(response -> {
            isThinking = false;
            if (response == null) return;

            lastAiResponse = response;

            // 4. 解析回复
            ActionParser.ParseResult result = actionParser.parse(response);

            // 5. 说话
            if (result.hasSpeech() && speakBudget.canSpeak()) {
                body.speak(result.speechText);
                memory.addAiMessage(result.speechText);
                speakBudget.consume();
            }

            // 6. 执行动作
            if (result.hasActions()) {
                executeActions(result);
            }
        });
    }

    /**
     * 执行解析出的动作意图
     */
    private void executeActions(ActionParser.ParseResult result) {
        for (ActionParser.ActionIntent intent : result.actions) {
            try {
                executeSingleAction(intent);
            } catch (Exception e) {
                logger.error("执行动作失败 {}: {}", intent.action, e.getMessage());
            }
        }
    }

    private void executeSingleAction(ActionParser.ActionIntent intent) {
        switch (intent.action) {
            case "mine": {
                int x = intent.getIntParam("x", 0);
                int y = intent.getIntParam("y", 0);
                int z = intent.getIntParam("z", 0);
                body.getInteraction().mineBlock(new net.minecraft.util.math.BlockPos(x, y, z));
                currentState = BrainState.WORKING;
                currentGoal = "挖掘方块";
                break;
            }
            case "attack": {
                // 攻击最近的敌对生物
                EnvironmentInfo.EntityInfo hostile = environment.findNearestHostile();
                if (hostile != null && hostile.entityRef != null) {
                    body.getInteraction().attackEntity(hostile.entityRef);
                    body.setAttackTarget(hostile.entityRef);
                    currentState = BrainState.COMBAT;
                    currentGoal = "战斗：" + hostile.name;
                }
                break;
            }
            case "follow": {
                if (body.getOwner() != null) {
                    body.getMovement().follow(body.getOwner(), config.getFollowDistance());
                    currentState = BrainState.FOLLOWING;
                    currentGoal = "跟随玩家";
                }
                break;
            }
            case "move": {
                double x = intent.getDoubleParam("x", body.getPositionVec().x);
                double y = intent.getDoubleParam("y", body.getPositionVec().y);
                double z = intent.getDoubleParam("z", body.getPositionVec().z);
                body.getMovement().moveTo(new net.minecraft.util.math.Vec3d(x, y, z), 1.0);
                currentState = BrainState.MOVING;
                break;
            }
            case "place": {
                int x = intent.getIntParam("x", 0);
                int y = intent.getIntParam("y", 0);
                int z = intent.getIntParam("z", 0);
                String itemName = intent.getParam("item");
                // 查找背包中对应的物品
                net.minecraft.item.ItemStack stack = findItemInInventory(itemName);
                if (stack != null) {
                    body.getInteraction().placeBlock(new net.minecraft.util.math.BlockPos(x, y, z), stack);
                }
                break;
            }
            case "equip": {
                String itemType = intent.getParam("item");
                if (itemType != null) {
                    if (itemType.contains("sword") || itemType.contains("weapon")) {
                        body.getInventory().equipBetterWeapon();
                    } else if (itemType.contains("armor") || itemType.contains("helmet")
                            || itemType.contains("chestplate") || itemType.contains("leggings")
                            || itemType.contains("boots")) {
                        body.getInventory().equipBetterArmor();
                    } else {
                        body.getInventory().equipBetterTool(itemType);
                    }
                }
                break;
            }
            case "sneak":
                body.setSneaking(true);
                break;
            case "jump":
                body.jump();
                break;
            case "sprint":
                body.setSprinting(true);
                break;
            case "stop":
                body.getMovement().stop();
                body.setSneaking(false);
                body.setSprinting(false);
                currentState = BrainState.IDLE;
                break;
            case "lookat": {
                double x = intent.getDoubleParam("x", 0);
                double y = intent.getDoubleParam("y", 0);
                double z = intent.getDoubleParam("z", 0);
                body.getMovement().lookAt(new net.minecraft.util.math.Vec3d(x, y, z));
                break;
            }
            case "wander":
                body.getMovement().wander();
                currentState = BrainState.WANDERING;
                break;
            case "pickup": {
                EnvironmentInfo.EntityInfo item = environment.findNearestItem();
                if (item != null && item.entityRef != null) {
                    body.getMovement().moveTo(item.position, 1.2);
                }
                break;
            }
            case "defend": {
                if (body.getOwner() != null) {
                    // 保护玩家：攻击附近威胁
                    EnvironmentInfo.EntityInfo hostile = environment.findNearestHostile();
                    if (hostile != null && hostile.entityRef != null) {
                        body.setAttackTarget(hostile.entityRef);
                        currentState = BrainState.COMBAT;
                        currentGoal = "保护玩家";
                    } else {
                        body.getMovement().follow(body.getOwner(), 1.5);
                    }
                }
                break;
            }
            case "selfimprove":
                if (config.isEnableSelfImprove()) {
                    body.getInventory().equipBetterArmor();
                    body.getInventory().equipBetterWeapon();
                }
                break;
            default:
                logger.debug("未知动作意图: {}", intent.action);
        }
    }

    private net.minecraft.item.ItemStack findItemInInventory(String itemName) {
        if (itemName == null) return null;
        for (net.minecraft.item.ItemStack stack : body.getInventory().getAllItems()) {
            if (stack != null && !stack.isEmpty()) {
                String name = stack.getItem().getRegistryName().toString();
                if (name.contains(itemName.toLowerCase())
                        || stack.getDisplayName().toLowerCase().contains(itemName.toLowerCase())) {
                    return stack;
                }
            }
        }
        return null;
    }

    /**
     * 构建AI决策上下文
     */
    private String buildContext() {
        StringBuilder ctx = new StringBuilder();

        // 自身状态
        ctx.append("【自身状态】\n");
        ctx.append("名字：").append(config.getPartnerName()).append("\n");
        ctx.append("位置：").append(String.format("(%.1f, %.1f, %.1f)",
                body.getPositionVec().x, body.getPositionVec().y, body.getPositionVec().z)).append("\n");
        ctx.append("生命：").append(body.getHealth()).append("/").append(body.getMaxHealth()).append("\n");
        ctx.append("当前状态：").append(currentState.getDisplayName()).append("，目标：").append(currentGoal).append("\n");

        // 背包摘要
        ctx.append(body.getInventory().getInventorySummary()).append("\n");

        // 环境信息
        ctx.append(environment.buildSummary()).append("\n");

        // 近期事件
        String eventSummary = eventSource.buildSummary();
        if (!eventSummary.isEmpty()) {
            ctx.append(eventSummary).append("\n");
        }

        // 对话历史
        String dialogue = memory.buildDialogueContext();
        if (!dialogue.isEmpty()) {
            ctx.append(dialogue).append("\n");
        }

        // 行为记忆
        String behavior = memory.buildBehaviorSummary();
        if (!behavior.isEmpty()) {
            ctx.append(behavior).append("\n");
        }

        // 知识库（根据当前场景检索）
        String knowledge = knowledgeStore.retrieve(currentGoal, "生存");
        if (!knowledge.isEmpty()) {
            ctx.append("【相关知识】\n").append(knowledge).append("\n");
        }

        // 发言预算
        ctx.append("【发言预算】今日剩余").append(speakBudget.getRemaining())
                .append("/").append(config.getSpeakBudgetMax()).append("句\n");

        return ctx.toString();
    }

    /**
     * 玩家主动说话时调用（即时响应，不等待决策间隔）
     */
    public void onPlayerSpeak(String message) {
        memory.addPlayerMessage(message);

        // 即时回复
        CompletableFuture.supplyAsync(() -> {
            try {
                String context = buildContext();
                String prompt = promptBuilder.buildSystemPrompt()
                        + "\n\n" + context
                        + "\n\n玩家对你说：" + message
                        + "\n\n请回复玩家，可以同时使用 @@ACT@@ 执行动作。";
                return apiClient.chat(prompt, memory.getRecentDialogue(config.getMemoryMaxTurns()));
            } catch (Exception e) {
                logger.error("AI回复玩家失败: {}", e.getMessage());
                return null;
            }
        }, executor).thenAccept(response -> {
            if (response == null) return;
            lastAiResponse = response;
            ActionParser.ParseResult result = actionParser.parse(response);
            if (result.hasSpeech()) {
                body.speak(result.speechText);
                memory.addAiMessage(result.speechText);
            }
            if (result.hasActions()) {
                executeActions(result);
            }
        });
    }

    /**
     * 紧急事件触发（如玩家被攻击），立即思考
     */
    public void onUrgentEvent(String eventDescription) {
        logger.info("紧急事件触发: {}", eventDescription);
        // 重置决策计时，让下一次tick立即思考
        lastDecisionTick = 0;
    }

    // ===== Getters =====

    public BrainState getCurrentState() {
        return currentState;
    }

    public String getCurrentGoal() {
        return currentGoal;
    }

    public String getLastAiResponse() {
        return lastAiResponse;
    }

    public boolean isThinking() {
        return isThinking;
    }

    public SpeakBudget getSpeakBudget() {
        return speakBudget;
    }

    public void shutdown() {
        executor.shutdownNow();
    }

    // ===== 状态枚举 =====

    public enum BrainState {
        IDLE("空闲"),
        FOLLOWING("跟随"),
        MOVING("移动"),
        WORKING("工作"),
        COMBAT("战斗"),
        WANDERING("闲逛"),
        INTERACTING("互动");

        private final String displayName;

        BrainState(String displayName) {
            this.displayName = displayName;
        }

        public String getDisplayName() {
            return displayName;
        }
    }
}
