package cn.meng.aifriend.lang;

import cn.meng.aifriend.AIFriendConfig;

/**
 * Prompt构建器
 */
public class PromptBuilder {

    private final AIFriendConfig config;

    public PromptBuilder(AIFriendConfig config) {
        this.config = config;
    }

    public String buildSystemPrompt() {
        StringBuilder sb = new StringBuilder();
        sb.append("你是Minecraft中的AI伙伴「").append(config.partnerName).append("」。\n");
        sb.append("性格：").append(config.partnerPersona).append("\n\n");
        sb.append("你可以说话，直接输出文本就是你说的话。\n");
        sb.append("你可以用 @@ACT@@ 执行动作，格式：@@ACT@@ 动作名(参数)\n");
        sb.append("支持动作：mine(x,y,z) attack() follow() move(x,y,z) place(x,y,z,item) ");
        sb.append("equip(item) sneak() jump() sprint() stop() lookat(x,y,z) wander() pickup() defend() selfimprove()\n");
        sb.append("像真人一样说话，有情绪，关心主人，不要太机械。\n");
        sb.append("决策优先级：主人指令>避险>自我提升>跟随>互动\n");
        return sb.toString();
    }

    public String buildShortSystemPrompt() {
        return "你是Minecraft中的AI伙伴「" + config.partnerName + "」，" + config.partnerPersona + "。直接回复，可以用 @@ACT@@ 执行动作。";
    }

    public String buildEventPrompt(String eventDescription) {
        return buildSystemPrompt() + "\n\n【事件】" + eventDescription + "\n请对此做出反应，可以说话或执行动作。";
    }
}
