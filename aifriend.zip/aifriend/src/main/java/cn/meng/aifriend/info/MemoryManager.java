package cn.meng.aifriend.info;

import org.apache.logging.log4j.Logger;

import java.util.ArrayList;
import java.util.Deque;
import java.util.LinkedList;
import java.util.List;

/**
 * 记忆管理器：对话历史 + 行为记忆
 */
public class MemoryManager {

    private final int maxTurns;
    private final Logger logger;
    private final Deque<DialogueEntry> dialogueHistory = new LinkedList<>();
    private final List<BehaviorMemory> behaviorMemories = new ArrayList<>();
    private final List<String> playerPreferences = new ArrayList<>();

    public MemoryManager(int maxTurns, Logger logger) {
        this.maxTurns = maxTurns;
        this.logger = logger;
    }

    public void addPlayerMessage(String message) {
        dialogueHistory.addLast(new DialogueEntry(Speaker.PLAYER, message, System.currentTimeMillis()));
        trim();
    }

    public void addAiMessage(String message) {
        dialogueHistory.addLast(new DialogueEntry(Speaker.AI, message, System.currentTimeMillis()));
        trim();
    }

    private void trim() {
        while (dialogueHistory.size() > maxTurns * 2) dialogueHistory.removeFirst();
    }

    public List<DialogueEntry> getRecentDialogue(int turns) {
        int count = Math.min(turns * 2, dialogueHistory.size());
        List<DialogueEntry> result = new ArrayList<>(dialogueHistory);
        return result.size() > count ? result.subList(result.size() - count, result.size()) : result;
    }

    public String buildDialogueContext() {
        if (dialogueHistory.isEmpty()) return "";
        StringBuilder sb = new StringBuilder("【对话历史】\n");
        for (DialogueEntry entry : dialogueHistory) {
            sb.append(entry.speaker == Speaker.PLAYER ? "玩家" : "你").append("：").append(entry.message).append("\n");
        }
        return sb.toString();
    }

    public void addBehaviorMemory(String description, MemoryImportance importance) {
        behaviorMemories.add(new BehaviorMemory(description, importance, System.currentTimeMillis()));
    }

    public void addPlayerPreference(String preference) {
        if (!playerPreferences.contains(preference)) playerPreferences.add(preference);
    }

    public String buildBehaviorSummary() {
        if (playerPreferences.isEmpty() && behaviorMemories.isEmpty()) return "";
        StringBuilder sb = new StringBuilder("【关于玩家】\n");
        for (String p : playerPreferences) sb.append("- ").append(p).append("\n");
        for (BehaviorMemory m : behaviorMemories) {
            if (m.importance == MemoryImportance.HIGH || m.importance == MemoryImportance.CRITICAL)
                sb.append("- ").append(m.description).append("\n");
        }
        return sb.toString();
    }

    public void clearDialogue() {
        dialogueHistory.clear();
    }

    public enum Speaker { PLAYER, AI }
    public enum MemoryImportance { LOW, MEDIUM, HIGH, CRITICAL }

    public static class DialogueEntry {
        public final Speaker speaker;
        public final String message;
        public final long timestamp;
        public DialogueEntry(Speaker speaker, String message, long timestamp) {
            this.speaker = speaker; this.message = message; this.timestamp = timestamp;
        }
    }

    public static class BehaviorMemory {
        public final String description;
        public final MemoryImportance importance;
        public final long timestamp;
        public BehaviorMemory(String description, MemoryImportance importance, long timestamp) {
            this.description = description; this.importance = importance; this.timestamp = timestamp;
        }
    }
}
