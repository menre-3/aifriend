package com.aifriend.info;

import org.apache.logging.log4j.Logger;

import java.util.ArrayList;
import java.util.Deque;
import java.util.LinkedList;
import java.util.List;

/**
 * 记忆管理器
 * 管理两种记忆：
 * 1) 对话历史：最近N轮对话，用于持续对话、随时插嘴
 * 2) 行为记忆：玩家的行为模式、偏好、重要事件，用于长期个性化
 *
 * 对话历史保留最近 memoryMaxTurns 轮，超出自动丢弃最旧的
 */
public class MemoryManager {

    private final int maxTurns;
    private final Logger logger;

    // 对话历史（最新的在末尾）
    private final Deque<DialogueEntry> dialogueHistory = new LinkedList<>();

    // 行为记忆（重要事件，不自动清除）
    private final List<BehaviorMemory> behaviorMemories = new ArrayList<>();

    // 玩家偏好（学习到的玩家习惯）
    private final List<String> playerPreferences = new ArrayList<>();

    public MemoryManager(int maxTurns, Logger logger) {
        this.maxTurns = maxTurns;
        this.logger = logger;
    }

    // ===== 对话记忆 =====

    /**
     * 记录玩家说的话
     */
    public void addPlayerMessage(String message) {
        dialogueHistory.addLast(new DialogueEntry(Speaker.PLAYER, message, System.currentTimeMillis()));
        trimHistory();
    }

    /**
     * 记录AI说的话
     */
    public void addAiMessage(String message) {
        dialogueHistory.addLast(new DialogueEntry(Speaker.AI, message, System.currentTimeMillis()));
        trimHistory();
    }

    private void trimHistory() {
        while (dialogueHistory.size() > maxTurns * 2) { // *2 因为一轮包含玩家+AI各一句
            dialogueHistory.removeFirst();
        }
    }

    /**
     * 获取最近的对话历史（用于AI上下文）
     */
    public List<DialogueEntry> getRecentDialogue(int turns) {
        int count = Math.min(turns * 2, dialogueHistory.size());
        List<DialogueEntry> result = new ArrayList<>(dialogueHistory);
        if (result.size() > count) {
            return result.subList(result.size() - count, result.size());
        }
        return result;
    }

    /**
     * 获取全部对话历史
     */
    public List<DialogueEntry> getAllDialogue() {
        return new ArrayList<>(dialogueHistory);
    }

    /**
     * 清空对话历史
     */
    public void clearDialogue() {
        dialogueHistory.clear();
    }

    /**
     * 生成对话历史文本（用于AI上下文）
     */
    public String buildDialogueContext() {
        if (dialogueHistory.isEmpty()) return "";
        StringBuilder sb = new StringBuilder("【对话历史】\n");
        for (DialogueEntry entry : dialogueHistory) {
            sb.append(entry.speaker == Speaker.PLAYER ? "玩家" : "你")
                    .append("：").append(entry.message).append("\n");
        }
        return sb.toString();
    }

    // ===== 行为记忆 =====

    /**
     * 记录行为记忆
     */
    public void addBehaviorMemory(String description, MemoryImportance importance) {
        behaviorMemories.add(new BehaviorMemory(description, importance, System.currentTimeMillis()));
        logger.debug("记录行为记忆: [{}] {}", importance, description);
    }

    /**
     * 获取重要的行为记忆
     */
    public List<BehaviorMemory> getImportantMemories() {
        List<BehaviorMemory> result = new ArrayList<>();
        for (BehaviorMemory m : behaviorMemories) {
            if (m.importance == MemoryImportance.HIGH
                    || m.importance == MemoryImportance.CRITICAL) {
                result.add(m);
            }
        }
        return result;
    }

    /**
     * 生成行为记忆摘要
     */
    public String buildBehaviorSummary() {
        List<BehaviorMemory> important = getImportantMemories();
        if (important.isEmpty() && playerPreferences.isEmpty()) return "";
        StringBuilder sb = new StringBuilder("【关于玩家】\n");
        for (String pref : playerPreferences) {
            sb.append("- ").append(pref).append("\n");
        }
        for (BehaviorMemory m : important) {
            sb.append("- ").append(m.description).append("\n");
        }
        return sb.toString();
    }

    // ===== 玩家偏好 =====

    public void addPlayerPreference(String preference) {
        if (!playerPreferences.contains(preference)) {
            playerPreferences.add(preference);
        }
    }

    public List<String> getPlayerPreferences() {
        return new ArrayList<>(playerPreferences);
    }

    // ===== 数据结构 =====

    public enum Speaker {
        PLAYER, AI
    }

    public enum MemoryImportance {
        LOW,        // 低重要性，可能被遗忘
        MEDIUM,     // 中等
        HIGH,       // 高重要性，长期保留
        CRITICAL    // 关键，永久保留
    }

    public static class DialogueEntry {
        public final Speaker speaker;
        public final String message;
        public final long timestamp;

        public DialogueEntry(Speaker speaker, String message, long timestamp) {
            this.speaker = speaker;
            this.message = message;
            this.timestamp = timestamp;
        }
    }

    public static class BehaviorMemory {
        public final String description;
        public final MemoryImportance importance;
        public final long timestamp;

        public BehaviorMemory(String description, MemoryImportance importance, long timestamp) {
            this.description = description;
            this.importance = importance;
            this.timestamp = timestamp;
        }
    }
}
