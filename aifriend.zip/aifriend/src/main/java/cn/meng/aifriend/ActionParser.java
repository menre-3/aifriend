package cn.meng.aifriend;

public class ActionParser {

    private static final int MAX_INSTR = 5; // 单轮最多执行5条指令（防爆）

    public static void execute(AIBrain brain, String text) {
        if (text == null || text.isEmpty()) return;
        IPartnerBody body = brain.getBody();

        int executed = 0;
        // 移动：只保留最后一条移动指令（特殊规则）
        double lastDirX = 0, lastDirZ = 0;
        boolean lastJump = false;
        boolean hasMove = false;

        for (String rawLine : text.split("\n")) {
            String line = rawLine.trim();
            if (!line.startsWith("@@")) continue; // 对话行跳过
            if (executed >= MAX_INSTR) break;      // 防爆：最多5条

            if (line.startsWith("@@KEY@@")) {
                KeyResult r = parseKey(line, body);
                if (r.isMove) {
                    lastDirX = r.dirX; lastDirZ = r.dirZ; lastJump = r.jump; hasMove = true;
                }
                executed++;
            } else if (line.startsWith("@@GOAL@@")) {
                parseGoal(line, brain);
                executed++;
            } else if (line.startsWith("@@CFG@@")) {
                parseCfg(line);
                executed++;
            }
        }
        // 移动最后统一执行（只执行最后一条移动）
        body.walk(hasMove ? lastDirX : 0, hasMove ? lastDirZ : 0, hasMove && lastJump);
    }

    private static class KeyResult {
        double dirX = 0, dirZ = 0;
        boolean jump = false;
        boolean isMove = false;
    }

    private static KeyResult parseKey(String line, IPartnerBody body) {
        KeyResult r = new KeyResult();
        String args = line.substring("@@KEY@@".length()).trim();
        String[] parts = args.split(",");

        boolean hasLmb = false; int lmbCount = 1;
        boolean hasRmb = false;

        for (int i = 0; i < parts.length; i++) {
            String k = parts[i].trim().toLowerCase();
            if (k.equals("w")) { r.dirZ += 1.0; r.isMove = true; }
            else if (k.equals("s")) { r.dirZ -= 1.0; r.isMove = true; }
            else if (k.equals("a")) { r.dirX -= 1.0; r.isMove = true; }
            else if (k.equals("d")) { r.dirX += 1.0; r.isMove = true; }
            else if (k.equals("space")) { r.jump = true; r.isMove = true; }
            else if (k.equals("lmb")) {
                hasLmb = true;
                // 后面紧跟数字 = 左键次数（1~10）
                if (i + 1 < parts.length && parts[i + 1].trim().matches("\\d+")) {
                    lmbCount = clampInt(parts[i + 1].trim(), 1, 10);
                    i++;
                }
            } else if (k.equals("rmb")) {
                hasRmb = true;
            } else if (k.matches("[1-9]")) {
                body.selectSlot(Integer.parseInt(k)); // 切槽位 1-9
            }
            // 其他（时长/非法参数）忽略，用默认
        }
        // 点击立即执行
        for (int n = 0; n < lmbCount; n++) body.leftClick();
        if (hasRmb) body.rightClick();

        // 归一化移动方向（局部坐标，交给身体转世界）
        double len = Math.sqrt(r.dirX * r.dirX + r.dirZ * r.dirZ);
        if (len > 0.001) { r.dirX /= len; r.dirZ /= len; }
        return r;
    }

    private static int clampInt(String s, int min, int max) {
        try {
            return Math.max(min, Math.min(max, Integer.parseInt(s)));
        } catch (Exception e) {
            return min;
        }
    }

    private static void parseGoal(String line, AIBrain brain) {
        String args = line.substring("@@GOAL@@".length()).trim();
        String[] parts = args.split(",");
        if (parts.length < 3) return;
        String type = parts[0].trim();
        String arg = parts[1].trim();
        int count = clampInt(parts[2].trim(), 1, 64); // 钳制 1~64
        IGoal g = GoalRegistry.create(type, arg, count);
        if (g != null) brain.setGoal(g);
    }

    private static void parseCfg(String line) {
        String args = line.substring("@@CFG@@".length()).trim();
        String[] kv = args.split("=");
        if (kv.length == 2) {
            ConfigGuard.apply(kv[0].trim(), kv[1].trim());
        }
    }
}