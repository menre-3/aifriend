package cn.meng.aifriend.goal;

import cn.meng.aifriend.api.IPartnerBody;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLog;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

/**
 * 砍树目标
 */
public class ChoppingGoal implements IGoal {

    private boolean active = false;
    private BlockPos targetLog;
    private int stuckTimer = 0;

    @Override public String getName() { return "砍树"; }
    @Override public int getPriority() { return 45; }
    @Override public boolean isActive() { return active; }

    @Override
    public boolean shouldStart(IPartnerBody body) {
        if (active) return false;
        return findNearbyTree(body) != null;
    }

    @Override
    public void start(IPartnerBody body) {
        active = true;
        targetLog = findNearbyTree(body);
        stuckTimer = 0;
    }

    @Override
    public boolean update(IPartnerBody body) {
        if (targetLog == null || body.getWorldObject().isAirBlock(targetLog)) {
            targetLog = findNearbyTree(body);
            if (targetLog == null) return false;
        }
        double dist = body.getPositionVec().distanceTo(new Vec3d(targetLog.getX() + 0.5, targetLog.getY(), targetLog.getZ() + 0.5));
        if (dist > 4) {
            body.getMovement().moveTo(targetLog, 1.0);
            stuckTimer++;
            if (stuckTimer > 100) return false;
        } else {
            stuckTimer = 0;
            body.getInteraction().mineBlock(targetLog);
            if (!body.getInteraction().isMiningNow()) targetLog = null;
        }
        return true;
    }

    @Override
    public void stop(IPartnerBody body) {
        active = false;
        targetLog = null;
        body.getMovement().stopMoving();
    }

    @Override
    public String getDescription() {
        return targetLog != null ? "砍伐 (" + targetLog.getX() + "," + targetLog.getY() + "," + targetLog.getZ() + ")" : "寻找树木";
    }

    private BlockPos findNearbyTree(IPartnerBody body) {
        Vec3d pos = body.getPositionVec();
        BlockPos center = new BlockPos(pos);
        BlockPos nearest = null;
        double nearestDist = Double.MAX_VALUE;
        for (int dx = -10; dx <= 10; dx++) {
            for (int dy = -3; dy <= 3; dy++) {
                for (int dz = -10; dz <= 10; dz++) {
                    BlockPos p = center.add(dx, dy, dz);
                    if (!body.getWorldObject().isBlockLoaded(p)) continue;
                    IBlockState state = body.getWorldObject().getBlockState(p);
                    Block block = state.getBlock();
                    if (block instanceof BlockLog || block == Blocks.LOG || block == Blocks.LOG2) {
                        double d = p.distanceSq(center);
                        if (d < nearestDist) { nearestDist = d; nearest = p; }
                    }
                }
            }
        }
        return nearest;
    }
}
