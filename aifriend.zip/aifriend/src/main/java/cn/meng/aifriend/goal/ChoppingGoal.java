package com.aifriend.goal;

import com.aifriend.api.IPartnerBody;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLog;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

/**
 * 砍树目标
 * 寻找附近的树木并砍伐原木
 */
public class ChoppingGoal implements IGoal {

    private boolean active = false;
    private BlockPos targetLog;
    private int stuckTimer = 0;

    @Override
    public String getName() { return "砍树"; }

    @Override
    public int getPriority() { return 45; }

    @Override
    public boolean shouldStart(IPartnerBody body) {
        if (active) return false;
        return findNearbyTree(body) != null;
    }

    @Override
    public void start(IPartnerBody body) {
        active = true;
        targetLog = findNearbyTree(body);
        stuckTimer = 0;
    }

    @Override
    public boolean update(IPartnerBody body) {
        if (targetLog == null || body.getWorld().isAirBlock(targetLog)) {
            targetLog = findNearbyTree(body);
            if (targetLog == null) return false;
        }

        double dist = body.getPositionVec().distanceTo(
                new Vec3d(targetLog.getX() + 0.5, targetLog.getY(), targetLog.getZ() + 0.5));

        if (dist > 4) {
            body.getMovement().moveTo(targetLog, 1.0);
            stuckTimer++;
            if (stuckTimer > 100) return false;
        } else {
            stuckTimer = 0;
            body.getInteraction().mineBlock(targetLog);
            if (!body.getInteraction().isMining()) {
                targetLog = null;
            }
        }
        return true;
    }

    @Override
    public void stop(IPartnerBody body) {
        active = false;
        targetLog = null;
        body.getMovement().stop();
    }

    @Override
    public boolean isActive() { return active; }

    @Override
    public String getDescription() {
        if (targetLog != null) {
            return "正在砍伐 (" + targetLog.getX() + "," + targetLog.getY() + "," + targetLog.getZ() + ") 的树木";
        }
        return "寻找树木中";
    }

    private BlockPos findNearbyTree(IPartnerBody body) {
        Vec3d pos = body.getPositionVec();
        int range = 10;
        BlockPos center = new BlockPos(pos);
        BlockPos nearest = null;
        double nearestDist = Double.MAX_VALUE;

        for (int dx = -range; dx <= range; dx++) {
            for (int dy = -3; dy <= 3; dy++) {
                for (int dz = -range; dz <= range; dz++) {
                    BlockPos checkPos = center.add(dx, dy, dz);
                    if (!body.getWorld().isBlockLoaded(checkPos)) continue;
                    IBlockState state = body.getWorld().getBlockState(checkPos);
                    Block block = state.getBlock();
                    // 检查是否是原木
                    if (block instanceof BlockLog || block == Blocks.LOG || block == Blocks.LOG2) {
                        double dist = checkPos.distanceSq(center);
                        if (dist < nearestDist) {
                            nearestDist = dist;
                            nearest = checkPos;
                        }
                    }
                }
            }
        }
        return nearest;
    }
}
