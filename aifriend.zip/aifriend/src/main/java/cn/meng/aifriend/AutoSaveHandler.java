package cn.meng.aifriend;

import cn.meng.aifriend.entity.AIPartnerEntity;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.apache.logging.log4j.Logger;

import java.util.List;

/**
 * 自动保存处理器
 * 定期保存AI伙伴数据到NBT，防止数据丢失
 */
@Mod.EventBusSubscriber(modid = AIFriendMod.MOD_ID)
public class AutoSaveHandler {

    private static final int SAVE_INTERVAL_TICKS = 6000; // 5分钟
    private static int tickCounter = 0;

    @SubscribeEvent
    public static void onWorldTick(TickEvent.WorldTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (event.world.isRemote) return;

        tickCounter++;
        if (tickCounter >= SAVE_INTERVAL_TICKS) {
            tickCounter = 0;
            saveAllPartners(event.world);
        }
    }

    private static void saveAllPartners(World world) {
        Logger logger = AIFriendMod.getLogger();
        if (logger == null) return;

        List<AIPartnerEntity> partners = world.getEntitiesWithinAABB(
                AIPartnerEntity.class,
                new net.minecraft.util.math.AxisAlignedBB(
                        -30000000, 0, -30000000,
                        30000000, 256, 30000000));

        int count = 0;
        for (AIPartnerEntity partner : partners) {
            // 强制写入NBT数据（实体本身会在世界保存时自动保存）
            // 这里只做标记，确保数据是最新的
            partner.markDirty();
            count++;
        }

        if (count > 0) {
            logger.debug("自动保存 {} 个AI伙伴数据", count);
        }
    }

    /**
     * 世界保存时触发立即保存
     */
    @SubscribeEvent
    public static void onWorldSave(net.minecraftforge.event.world.WorldEvent.Save event) {
        if (event.getWorld().isRemote) return;
        Logger logger = AIFriendMod.getLogger();
        if (logger != null) {
            logger.debug("世界保存，AI伙伴数据将随世界一起保存");
        }
    }
}
