package cn.meng.aifriend;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

/**
 * 全局保存器：仅服务端运行。
 * 每 200 tick(10秒) 触发一次保存（内部 dirty 标记，无改动自动跳过写盘）。
 * 关服强制保存由 AIFriendMod.serverStopping 处理。
 */
@Mod.EventBusSubscriber(modid = AIFriendMod.MODID)
public class AutoSaveHandler {

    private static int counter = 0;

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        counter++;
        if (counter >= 200) { // 每 200 tick = 10 秒
            counter = 0;
            KnowledgeStore.save(); // learned.txt
            MemoryManager.save();  // memory.txt
        }
    }
}