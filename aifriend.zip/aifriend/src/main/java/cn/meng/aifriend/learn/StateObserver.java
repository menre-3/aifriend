package com.aifriend.learn;

import com.aifriend.info.KnowledgeStore;
import com.aifriend.info.MemoryManager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import org.apache.logging.log4j.Logger;

import java.util.HashMap;
import java.util.Map;

/**
 * 状态观察器（学习层）
 * 观察玩家的行为模式、物品使用习惯、建造偏好等，
 * 自动学习并记录到记忆和知识库中
 *
 * 学习内容：
 * 1. 玩家常用物品/工具（推断玩家偏好）
 * 2. 玩家建造风格（常用方块、建筑位置）
 * 3. 玩家作息规律（什么时候挖矿、什么时候建造）
 * 4. 玩家战斗习惯（近战/远程/逃跑）
 * 5. 新发现的物品/方块（自动记录到知识库）
 */
public class StateObserver {

    private final KnowledgeStore knowledgeStore;
    private final MemoryManager memory;
    private final Logger logger;

    // 玩家物品使用统计
    private final Map<String, Integer> itemUsageCount = new HashMap<>();
    // 玩家方块放置统计
    private final Map<String, Integer> blockPlaceCount = new HashMap<>();
    // 玩家位置历史（用于推断活动区域）
    private final java.util.Deque<BlockPos> positionHistory = new java.util.ArrayDeque<>();
    private static final int POSITION_HISTORY_SIZE = 20;

    // 玩家上次状态
    private boolean lastSneaking = false;
    private float lastHealth = 20.0f;
    private int lastHunger = 20;

    // 学习统计
    private long totalObservations = 0;
    private long learnedInsights = 0;

    public StateObserver(KnowledgeStore knowledgeStore, MemoryManager memory, Logger logger) {
        this.knowledgeStore = knowledgeStore;
        this.memory = memory;
        this.logger = logger;
    }

    /**
     * 观察玩家当前状态
     * @param player 玩家实体
     * @param currentTick 当前tick
     */
    public void observe(EntityPlayer player, long currentTick) {
        if (player == null) return;
        totalObservations++;

        // 记录位置
        BlockPos pos = player.getPosition();
        positionHistory.addLast(pos);
        if (positionHistory.size() > POSITION_HISTORY_SIZE) {
            positionHistory.removeFirst();
        }

        // 观察手持物品
        ItemStack held = player.getHeldItemMainhand();
        if (held != null && !held.isEmpty()) {
            String itemName = held.getItem().getRegistryName().toString();
            itemUsageCount.merge(itemName, 1, Integer::sum);

            // 新物品学习
            if (!knowledgeStore.isKnown("item:" + itemName)) {
                knowledgeStore.learn("item:" + itemName,
                        "玩家使用了 " + held.getDisplayName()
                                + "，物品ID：" + itemName
                                + "，最大堆叠：" + held.getMaxStackSize());
                learnedInsights++;
            }
        }

        // 健康变化检测
        float currentHealth = player.getHealth();
        if (currentHealth < lastHealth) {
            float damage = lastHealth - currentHealth;
            if (damage >= 4) {
                memory.addBehaviorMemory("玩家受到了" + damage + "点伤害",
                        MemoryManager.MemoryImportance.MEDIUM);
            }
        }
        lastHealth = currentHealth;

        // 饥饿变化
        int currentHunger = player.getFoodStats().getFoodLevel();
        if (currentHunger < lastHunger && currentHunger <= 6) {
            memory.addPlayerPreference("玩家饥饿值较低时需要食物");
        }
        lastHunger = currentHunger;

        // 蹲起变化（由EventSpeaker处理，这里只记录）
        boolean currentSneaking = player.isSneaking();
        if (currentSneaking != lastSneaking) {
            lastSneaking = currentSneaking;
        }

        // 定期生成学习洞察
        if (totalObservations % 200 == 0) {
            generateInsights();
        }
    }

    /**
     * 记录玩家放置方块
     */
    public void onBlockPlaced(String blockRegistryName, String localizedName) {
        blockPlaceCount.merge(blockRegistryName, 1, Integer::sum);

        // 新方块学习
        if (!knowledgeStore.isKnown("block:" + blockRegistryName)) {
            knowledgeStore.learn("block:" + blockRegistryName,
                    "玩家放置了 " + localizedName + "，方块ID：" + blockRegistryName);
            learnedInsights++;
        }
    }

    /**
     * 记录玩家挖掘方块
     */
    public void onBlockBroken(String blockRegistryName, String localizedName) {
        if (!knowledgeStore.isKnown("block:" + blockRegistryName)) {
            knowledgeStore.learn("block:" + blockRegistryName,
                    "玩家挖掘了 " + localizedName + "，方块ID：" + blockRegistryName);
            learnedInsights++;
        }
    }

    /**
     * 生成学习洞察（根据统计数据推断玩家偏好）
     */
    private void generateInsights() {
        // 最常用物品
        String favoriteItem = getMostUsed(itemUsageCount);
        if (favoriteItem != null) {
            int count = itemUsageCount.get(favoriteItem);
            if (count >= 10) {
                memory.addPlayerPreference("玩家经常使用 " + favoriteItem + "（已观察" + count + "次）");
            }
        }

        // 最常放置方块
        String favoriteBlock = getMostUsed(blockPlaceCount);
        if (favoriteBlock != null) {
            int count = blockPlaceCount.get(favoriteBlock);
            if (count >= 5) {
                memory.addPlayerPreference("玩家喜欢用 " + favoriteBlock + " 建造（已放置" + count + "次）");
            }
        }

        // 活动区域推断
        if (positionHistory.size() >= 10) {
            BlockPos avg = getAveragePosition();
            if (avg != null) {
                memory.addBehaviorMemory("玩家常在 (" + avg.getX() + "," + avg.getY() + "," + avg.getZ() + ") 附近活动",
                        MemoryManager.MemoryImportance.LOW);
            }
        }
    }

    private String getMostUsed(Map<String, Integer> map) {
        return map.entrySet().stream()
                .max(Map.Entry.comparingByValue())
                .map(Map.Entry::getKey)
                .orElse(null);
    }

    private BlockPos getAveragePosition() {
        if (positionHistory.isEmpty()) return null;
        int x = 0, y = 0, z = 0;
        for (BlockPos p : positionHistory) {
            x += p.getX();
            y += p.getY();
            z += p.getZ();
        }
        int n = positionHistory.size();
        return new BlockPos(x / n, y / n, z / n);
    }

    /**
     * 检查玩家是否在移动（用于看夕阳等场景）
     */
    public boolean isPlayerIdle() {
        if (positionHistory.size() < 5) return false;
        BlockPos[] positions = positionHistory.toArray(new BlockPos[0]);
        BlockPos first = positions[0];
        BlockPos last = positions[positions.length - 1];
        // 最近5个位置的移动距离小于3格算静止
        double distance = Math.sqrt(
                Math.pow(first.getX() - last.getX(), 2) +
                Math.pow(first.getZ() - last.getZ(), 2)
        );
        return distance < 3.0;
    }

    /**
     * 获取玩家最常用物品
     */
    public String getPlayerFavoriteItem() {
        return getMostUsed(itemUsageCount);
    }

    /**
     * 获取学习统计
     */
    public String getStats() {
        return "观察次数: " + totalObservations
                + ", 学习洞察: " + learnedInsights
                + ", 已知物品: " + itemUsageCount.size()
                + ", 已知方块: " + blockPlaceCount.size();
    }
}
