package cn.meng.aifriend.learn;

import cn.meng.aifriend.AIFriendMod;
import cn.meng.aifriend.info.KnowledgeStore;
import cn.meng.aifriend.info.MemoryManager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.common.Mod;
import org.apache.logging.log4j.Logger;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.Map;

/**
 * 状态观察器（学习层）
 */
@Mod.EventBusSubscriber(modid = AIFriendMod.MOD_ID)
public class StateObserver {

    private final KnowledgeStore knowledgeStore;
    private final MemoryManager memory;
    private final Logger logger;

    private final Map<String, Integer> itemUsageCount = new HashMap<>();
    private final Map<String, Integer> blockPlaceCount = new HashMap<>();
    private final Deque<BlockPos> positionHistory = new ArrayDeque<>();
    private static final int POSITION_HISTORY_SIZE = 20;

    private float lastHealth = 20.0f;
    private int lastHunger = 20;
    private long totalObservations = 0;
    private long learnedInsights = 0;

    public StateObserver(KnowledgeStore knowledgeStore, MemoryManager memory, Logger logger) {
        this.knowledgeStore = knowledgeStore;
        this.memory = memory;
        this.logger = logger;
    }

    public void observe(EntityPlayer player, long currentTick) {
        if (player == null) return;
        totalObservations++;

        BlockPos pos = player.getPosition();
        positionHistory.addLast(pos);
        if (positionHistory.size() > POSITION_HISTORY_SIZE) positionHistory.removeFirst();

        ItemStack held = player.getHeldItemMainhand();
        if (held != null && !held.isEmpty()) {
            String itemName = held.getItem().getRegistryName().toString();
            itemUsageCount.merge(itemName, 1, Integer::sum);
            if (!knowledgeStore.isKnown("item:" + itemName)) {
                knowledgeStore.learn("item:" + itemName, "玩家使用了 " + held.getDisplayName() + "，ID：" + itemName);
                learnedInsights++;
            }
        }

        float currentHealth = player.getHealth();
        if (currentHealth < lastHealth && lastHealth - currentHealth >= 4) {
            memory.addBehaviorMemory("玩家受到了" + (lastHealth - currentHealth) + "点伤害", MemoryManager.MemoryImportance.MEDIUM);
        }
        lastHealth = currentHealth;

        int currentHunger = player.getFoodStats().getFoodLevel();
        if (currentHunger < lastHunger && currentHunger <= 6) {
            memory.addPlayerPreference("玩家饥饿值低时需要食物");
        }
        lastHunger = currentHunger;

        if (totalObservations % 200 == 0) generateInsights();
    }

    public void onBlockPlaced(String blockRegistryName, String localizedName) {
        blockPlaceCount.merge(blockRegistryName, 1, Integer::sum);
        if (!knowledgeStore.isKnown("block:" + blockRegistryName)) {
            knowledgeStore.learn("block:" + blockRegistryName, "玩家放置了 " + localizedName);
            learnedInsights++;
        }
    }

    public void onBlockBroken(String blockRegistryName, String localizedName) {
        if (!knowledgeStore.isKnown("block:" + blockRegistryName)) {
            knowledgeStore.learn("block:" + blockRegistryName, "玩家挖掘了 " + localizedName);
            learnedInsights++;
        }
    }

    private void generateInsights() {
        String favoriteItem = getMostUsed(itemUsageCount);
        if (favoriteItem != null && itemUsageCount.get(favoriteItem) >= 10) {
            memory.addPlayerPreference("玩家经常使用 " + favoriteItem);
        }
        String favoriteBlock = getMostUsed(blockPlaceCount);
        if (favoriteBlock != null && blockPlaceCount.get(favoriteBlock) >= 5) {
            memory.addPlayerPreference("玩家喜欢用 " + favoriteBlock + " 建造");
        }
    }

    private String getMostUsed(Map<String, Integer> map) {
        return map.entrySet().stream().max(Map.Entry.comparingByValue()).map(Map.Entry::getKey).orElse(null);
    }

    public boolean isPlayerIdle() {
        if (positionHistory.size() < 5) return false;
        BlockPos[] positions = positionHistory.toArray(new BlockPos[0]);
        BlockPos first = positions[0];
        BlockPos last = positions[positions.length - 1];
        double distance = Math.sqrt(Math.pow(first.getX() - last.getX(), 2) + Math.pow(first.getZ() - last.getZ(), 2));
        return distance < 3.0;
    }

    public String getStats() {
        return "观察:" + totalObservations + ", 学习:" + learnedInsights + ", 物品:" + itemUsageCount.size() + ", 方块:" + blockPlaceCount.size();
    }
}
