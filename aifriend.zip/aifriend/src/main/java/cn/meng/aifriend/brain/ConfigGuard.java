package cn.meng.aifriend.brain;

import cn.meng.aifriend.AIFriendConfig;
import org.apache.logging.log4j.Logger;

import java.util.ArrayList;
import java.util.List;

/**
 * 配置守护：AI运行时动态调整配置，带安全边界
 */
public class ConfigGuard {

    private final AIFriendConfig config;
    private final Logger logger;
    private final List<ConfigChange> changeHistory = new ArrayList<>();
    private static final int MAX_HISTORY = 20;

    public ConfigGuard(AIFriendConfig config, Logger logger) {
        this.config = config;
        this.logger = logger;
    }

    public boolean adjustDetectRange(int newRange, String reason) {
        int oldRange = config.detectRange;
        if (newRange < 4 || newRange > 128) {
            logger.warn("拒绝调整探测范围到{}（超出4-128）", newRange);
            return false;
        }
        int maxChange = (int) (oldRange * 0.5);
        if (Math.abs(newRange - oldRange) > maxChange && oldRange > 0) {
            logger.warn("拒绝调整探测范围：从{}到{}变化超过50%", oldRange, newRange);
            return false;
        }
        config.setDetectRange(newRange);
        recordChange("detectRange", String.valueOf(oldRange), String.valueOf(newRange), reason);
        logger.info("探测范围从{}调整到{}，原因：{}", oldRange, newRange, reason);
        return true;
    }

    public boolean parseAndApply(String configDirective) {
        if (configDirective == null || !configDirective.contains("@@CONFIG@@")) return false;
        try {
            String content = configDirective.replace("@@CONFIG@@", "").trim();
            String[] parts = content.split("\\s+", 2);
            if (parts.length < 1) return false;
            String kv = parts[0];
            String reason = parts.length > 1 ? parts[1].replaceAll("^reason=\"?|\"?$", "") : "AI自动调整";
            int eq = kv.indexOf('=');
            if (eq < 0) return false;
            String key = kv.substring(0, eq).trim();
            String value = kv.substring(eq + 1).trim();
            if ("detectrange".equalsIgnoreCase(key)) {
                return adjustDetectRange(Integer.parseInt(value), reason);
            }
            logger.warn("不允许调整参数 {}", key);
            return false;
        } catch (Exception e) {
            logger.error("解析配置调整失败: {}", e.getMessage());
            return false;
        }
    }

    private void recordChange(String key, String oldValue, String newValue, String reason) {
        changeHistory.add(new ConfigChange(key, oldValue, newValue, reason, System.currentTimeMillis()));
        while (changeHistory.size() > MAX_HISTORY) changeHistory.remove(0);
    }

    public List<ConfigChange> getChangeHistory() {
        return new ArrayList<>(changeHistory);
    }

    public String buildConfigSummary() {
        return "【配置】探测范围=" + config.detectRange + "格，决策间隔=" + config.decisionIntervalTicks
                + "tick，发言预算=" + config.speakBudgetMax + "句/日。可调整：detectRange(4-128)。格式：@@CONFIG@@ key=value reason=\"原因\"";
    }

    public static class ConfigChange {
        public final String key, oldValue, newValue, reason;
        public final long timestamp;
        public ConfigChange(String key, String oldValue, String newValue, String reason, long timestamp) {
            this.key = key; this.oldValue = oldValue; this.newValue = newValue; this.reason = reason; this.timestamp = timestamp;
        }
    }
}
