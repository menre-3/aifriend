package com.aifriend.brain;

import com.aifriend.AIFriendConfig;
import org.apache.logging.log4j.Logger;

/**
 * 配置守护模块
 * 允许AI在运行时动态调整部分配置参数（如探测范围、决策间隔、发言预算），
 * 但所有调整都有安全边界，防止AI把配置调到不合理的值。
 *
 * 可调整的参数：
 * - detectRange: 探测范围（4-128格）
 * - decisionIntervalTicks: 决策间隔（10-200 tick）
 * - speakBudgetMax: 发言预算（0-50句/日）
 *
 * 不可调整的参数（安全相关）：
 * - apiEndpoint, apiKey, model
 * - partnerName, partnerPersona
 * - memoryMaxTurns
 */
public class ConfigGuard {

    private final AIFriendConfig config;
    private final Logger logger;

    // 调整历史（用于审计和回滚）
    private final java.util.List<ConfigChange> changeHistory = new java.util.ArrayList<>();
    private static final int MAX_HISTORY = 20;

    public ConfigGuard(AIFriendConfig config, Logger logger) {
        this.config = config;
        this.logger = logger;
    }

    /**
     * 尝试调整探测范围
     * @param newRange 新的范围（格）
     * @param reason 调整原因（由AI给出）
     * @return 是否调整成功
     */
    public boolean adjustDetectRange(int newRange, String reason) {
        int oldRange = config.getDetectRange();
        // 安全边界
        if (newRange < 4 || newRange > 128) {
            logger.warn("配置守护拒绝调整探测范围到{}（超出4-128），原因：{}", newRange, reason);
            return false;
        }
        // 变化幅度限制：单次不超过50%
        int maxChange = (int) (oldRange * 0.5);
        if (Math.abs(newRange - oldRange) > maxChange && oldRange > 0) {
            logger.warn("配置守护拒绝调整探测范围：从{}到{}变化超过50%，原因：{}", oldRange, newRange, reason);
            return false;
        }
        config.setDetectRange(newRange);
        recordChange("detectRange", String.valueOf(oldRange), String.valueOf(newRange), reason);
        logger.info("配置守护：探测范围从{}调整到{}，原因：{}", oldRange, newRange, reason);
        return true;
    }

    /**
     * 尝试调整决策间隔
     */
    public boolean adjustDecisionInterval(int newTicks, String reason) {
        int oldTicks = config.getDecisionIntervalTicks();
        if (newTicks < 10 || newTicks > 200) {
            logger.warn("配置守护拒绝调整决策间隔到{}（超出10-200），原因：{}", newTicks, reason);
            return false;
        }
        config.setDecisionIntervalTicks(newTicks);
        recordChange("decisionIntervalTicks", String.valueOf(oldTicks), String.valueOf(newTicks), reason);
        logger.info("配置守护：决策间隔从{}调整到{}，原因：{}", oldTicks, newTicks, reason);
        return true;
    }

    /**
     * 尝试调整发言预算
     */
    public boolean adjustSpeakBudget(int newBudget, String reason) {
        int oldBudget = config.getSpeakBudgetMax();
        if (newBudget < 0 || newBudget > 50) {
            logger.warn("配置守护拒绝调整发言预算到{}（超出0-50），原因：{}", newBudget, reason);
            return false;
        }
        config.setSpeakBudgetMax(newBudget);
        recordChange("speakBudgetMax", String.valueOf(oldBudget), String.valueOf(newBudget), reason);
        logger.info("配置守护：发言预算从{}调整到{}，原因：{}", oldBudget, newBudget, reason);
        return true;
    }

    /**
     * 解析AI的配置调整意图
     * 格式：@@CONFIG@@ key=value reason="..."
     */
    public boolean parseAndApply(String configDirective) {
        if (configDirective == null || !configDirective.contains("@@CONFIG@@")) {
            return false;
        }
        try {
            String content = configDirective.replace("@@CONFIG@@", "").trim();
            // 解析 key=value
            String[] parts = content.split("\\s+", 2);
            if (parts.length < 1) return false;

            String kv = parts[0];
            String reason = parts.length > 1 ? parts[1].replaceAll("^reason=\"?|\"?$", "") : "AI自动调整";

            int eq = kv.indexOf('=');
            if (eq < 0) return false;

            String key = kv.substring(0, eq).trim();
            String value = kv.substring(eq + 1).trim();

            switch (key.toLowerCase()) {
                case "detectrange":
                    return adjustDetectRange(Integer.parseInt(value), reason);
                case "decisioninterval":
                case "decisionintervalticks":
                    return adjustDecisionInterval(Integer.parseInt(value), reason);
                case "speakbudget":
                case "speakbudgetmax":
                    return adjustSpeakBudget(Integer.parseInt(value), reason);
                default:
                    logger.warn("配置守护：不允许调整参数 {}", key);
                    return false;
            }
        } catch (Exception e) {
            logger.error("解析配置调整意图失败: {}", e.getMessage());
            return false;
        }
    }

    private void recordChange(String key, String oldValue, String newValue, String reason) {
        changeHistory.add(new ConfigChange(key, oldValue, newValue, reason, System.currentTimeMillis()));
        while (changeHistory.size() > MAX_HISTORY) {
            changeHistory.remove(0);
        }
    }

    /**
     * 获取调整历史
     */
    public java.util.List<ConfigChange> getChangeHistory() {
        return new java.util.ArrayList<>(changeHistory);
    }

    /**
     * 生成当前配置摘要（用于AI上下文）
     */
    public String buildConfigSummary() {
        return "【当前配置】探测范围=" + config.getDetectRange() + "格，"
                + "决策间隔=" + config.getDecisionIntervalTicks() + "tick，"
                + "发言预算=" + config.getSpeakBudgetMax() + "句/日\n"
                + "可调整参数：detectRange(4-128), decisionInterval(10-200), speakBudget(0-50)\n"
                + "调整格式：@@CONFIG@@ key=value reason=\"原因\"";
    }

    // ===== 数据结构 =====

    public static class ConfigChange {
        public final String key;
        public final String oldValue;
        public final String newValue;
        public final String reason;
        public final long timestamp;

        public ConfigChange(String key, String oldValue, String newValue, String reason, long timestamp) {
            this.key = key;
            this.oldValue = oldValue;
            this.newValue = newValue;
            this.reason = reason;
            this.timestamp = timestamp;
        }
    }
}
