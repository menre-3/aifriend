package com.aifriend.api;

import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;

/**
 * 交互控制接口
 * 封装挖掘、放置、攻击、使用物品等交互能力
 * 所有操作由模组端代码可靠执行，AI只负责"选择做什么"
 */
public interface Interaction {

    // ===== 方块操作 =====

    /**
     * 挖掘指定方块
     * @param pos 方块位置
     * @return 是否开始挖掘
     */
    boolean mineBlock(BlockPos pos);

    /**
     * 放置方块到指定位置
     * @param pos 目标位置
     * @param stack 要放置的物品堆
     * @return 是否成功放置
     */
    boolean placeBlock(BlockPos pos, ItemStack stack);

    /**
     * 获取当前视线指向的方块
     */
    RayTraceResult rayTraceBlock(double range);

    /**
     * 获取指定位置的方块状态
     */
    IBlockState getBlockState(BlockPos pos);

    /**
     * 检查方块是否可挖掘
     */
    boolean canHarvestBlock(BlockPos pos);

    // ===== 实体交互 =====

    /**
     * 攻击目标实体
     * @param target 目标
     * @return 是否成功攻击
     */
    boolean attackEntity(Entity target);

    /**
     * 右键交互（对实体/方块使用物品）
     */
    boolean interact(Entity target, EnumHand hand);

    /**
     * 右键使用当前手持物品
     */
    boolean useItemRightClick(EnumHand hand);

    // ===== 物品使用 =====

    /**
     * 切换到指定槽位的物品
     */
    void setHeldItem(EnumHand hand, ItemStack stack);

    /**
     * 获取当前主手物品
     */
    ItemStack getHeldItemMainhand();

    /**
     * 吃食物（如果手持的是食物）
     */
    boolean eatFood();

    // ===== 状态查询 =====

    /**
     * 是否正在挖掘
     */
    boolean isMining();

    /**
     * 是否正在攻击
     */
    boolean isAttacking();

    /**
     * 获取当前目标方块
     */
    BlockPos getMiningTarget();
}
