package cn.meng.aifriend.api;

import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;

/**
 * 交互控制接口
 */
public interface Interaction {

    boolean mineBlock(BlockPos pos);
    boolean placeBlock(BlockPos pos, ItemStack stack);
    RayTraceResult rayTraceBlock(double range);
    IBlockState getBlockStateAt(BlockPos pos);
    boolean canHarvestBlockAt(BlockPos pos);

    boolean attackEntity(Entity target);
    boolean interactWith(Entity target, EnumHand hand);
    boolean useItemRightClick(EnumHand hand);

    void setHeldItemSlot(EnumHand hand, ItemStack stack);
    ItemStack getHeldItemMainhandNow();
    boolean eatFoodNow();

    boolean isMiningNow();
    boolean isAttackingNow();
    BlockPos getMiningTargetPos();
}
