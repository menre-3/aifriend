package cn.meng.aifriend.info;

import cn.meng.aifriend.AIFriendConfig;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.passive.IAnimals;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * 环境感知模块
 * 探测范围可配置，默认24格。注意AABB查询返回实体数常远超设定值。
 */
public class EnvironmentInfo {

    private final AIFriendConfig config;
    private final World world;
    private final Entity observer;

    private ScanResult lastResult;
    private long lastScanTick = -1;

    public EnvironmentInfo(AIFriendConfig config, World world, Entity observer) {
        this.config = config;
        this.world = world;
        this.observer = observer;
    }

    public ScanResult scan() {
        long currentTick = world.getTotalWorldTime();
        if (lastResult != null && currentTick == lastScanTick) {
            return lastResult;
        }

        int range = config.detectRange;
        int maxEntities = config.maxEntitiesPerScan;
        Vec3d pos = observer.getPositionVector();
        AxisAlignedBB aabb = new AxisAlignedBB(
                pos.x - range, pos.y - range, pos.z - range,
                pos.x + range, pos.y + range, pos.z + range);

        List<Entity> allEntities = world.getEntitiesWithinAABB(Entity.class, aabb);
        allEntities.sort(Comparator.comparingDouble(e -> e.getDistanceSq(observer)));

        List<EntityInfo> mobs = new ArrayList<>();
        List<EntityInfo> animals = new ArrayList<>();
        List<EntityInfo> players = new ArrayList<>();
        List<EntityInfo> items = new ArrayList<>();
        List<EntityInfo> others = new ArrayList<>();

        int counted = 0;
        for (Entity e : allEntities) {
            if (e == observer) continue;
            if (counted >= maxEntities) break;
            double dist = e.getDistance(observer);
            EntityInfo info = new EntityInfo(e, dist);
            if (e instanceof IMob) mobs.add(info);
            else if (e instanceof IAnimals) animals.add(info);
            else if (e instanceof EntityPlayer) players.add(info);
            else if (e instanceof EntityItem) items.add(info);
            else others.add(info);
            counted++;
        }

        EnvironmentState state = new EnvironmentState();
        state.timeOfDay = world.getWorldTime() % 24000;
        state.isDaytime = world.isDaytime();
        state.isRaining = world.isRaining();
        state.isThundering = world.isThundering();
        state.dimension = world.provider.getDimension();
        state.biome = world.getBiome(new BlockPos(pos)).getBiomeName();
        state.lightLevel = world.getLight(new BlockPos(pos));

        ScanResult result = new ScanResult();
        result.mobs = mobs;
        result.animals = animals;
        result.players = players;
        result.items = items;
        result.others = others;
        result.totalEntitiesFound = allEntities.size() - 1;
        result.state = state;
        result.scanRange = range;
        result.scanTick = currentTick;

        lastResult = result;
        lastScanTick = currentTick;
        return result;
    }

    public EntityInfo findNearestHostile() {
        ScanResult r = scan();
        return r.mobs.isEmpty() ? null : r.mobs.get(0);
    }

    public EntityInfo findNearestItem() {
        ScanResult r = scan();
        return r.items.isEmpty() ? null : r.items.get(0);
    }

    public String buildSummary() {
        ScanResult r = scan();
        StringBuilder sb = new StringBuilder();
        sb.append("【环境】范围").append(r.scanRange).append("格，发现").append(r.totalEntitiesFound).append("实体\n");
        sb.append("时间：").append(r.state.isDaytime ? "白天" : "夜晚")
                .append("，天气：").append(r.state.isRaining ? (r.state.isThundering ? "雷暴" : "下雨") : "晴朗")
                .append("，群系：").append(r.state.biome).append("\n");
        if (!r.mobs.isEmpty()) {
            sb.append("敌对(").append(r.mobs.size()).append(")：");
            for (int i = 0; i < Math.min(5, r.mobs.size()); i++)
                sb.append(r.mobs.get(i).name).append(" ");
            sb.append("\n");
        }
        if (!r.animals.isEmpty()) {
            sb.append("友好(").append(r.animals.size()).append(")：");
            for (int i = 0; i < Math.min(5, r.animals.size()); i++)
                sb.append(r.animals.get(i).name).append(" ");
            sb.append("\n");
        }
        if (!r.items.isEmpty()) {
            sb.append("掉落物(").append(r.items.size()).append(")：");
            for (int i = 0; i < Math.min(5, r.items.size()); i++)
                sb.append(r.items.get(i).name).append(" ");
            sb.append("\n");
        }
        return sb.toString();
    }

    public static class ScanResult {
        public List<EntityInfo> mobs;
        public List<EntityInfo> animals;
        public List<EntityInfo> players;
        public List<EntityInfo> items;
        public List<EntityInfo> others;
        public EnvironmentState state;
        public int totalEntitiesFound;
        public int scanRange;
        public long scanTick;
    }

    public static class EntityInfo {
        public String name;
        public String registryName;
        public double distance;
        public float health;
        public float maxHealth;
        public Vec3d position;
        public boolean isHostile;
        public Entity entityRef;

        public EntityInfo(Entity e, double distance) {
            this.name = e.getName();
            this.registryName = e.getClass().getSimpleName();
            this.distance = distance;
            this.position = e.getPositionVector();
            this.isHostile = e instanceof IMob;
            this.entityRef = e;
            if (e instanceof EntityLiving) {
                this.health = ((EntityLiving) e).getHealth();
                this.maxHealth = ((EntityLiving) e).getMaxHealth();
            }
        }
    }

    public static class EnvironmentState {
        public long timeOfDay;
        public boolean isDaytime;
        public boolean isRaining;
        public boolean isThundering;
        public int dimension;
        public String biome;
        public int lightLevel;
    }
}
