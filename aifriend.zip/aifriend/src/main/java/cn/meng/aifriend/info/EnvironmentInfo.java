package com.aifriend.info;

import com.aifriend.AIFriendConfig;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.passive.IAnimals;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * 环境感知模块（眼睛）
 * 探测周围的方块、生物、掉落物、天气、时间等信息
 *
 * 关于探测范围的重要说明：
 *   Minecraft 的 getEntitiesWithinAABB 使用轴对齐包围盒(AABB)查询，
 *   即使设置 detectRange=12，实际返回的实体数量往往有20+个，
 *   因为范围内包含：敌对生物、友好生物、玩家、掉落物、箭矢、
 *   经验球、物品展示框、盔甲架等各种实体。
 *   因此本模块：
 *   1) 探测范围可通过配置调整（默认24格）
 *   2) 对返回结果按距离排序并截断到 maxEntitiesPerScan
 *   3) 分类输出，避免信息过载
 */
public class EnvironmentInfo {

    private final AIFriendConfig config;
    private final World world;
    private final Entity observer;

    // 缓存最近一次扫描结果
    private ScanResult lastResult;
    private long lastScanTick = -1;

    public EnvironmentInfo(AIFriendConfig config, World world, Entity observer) {
        this.config = config;
        this.world = world;
        this.observer = observer;
    }

    /**
     * 执行一次完整环境扫描
     * 结果会被缓存，同一tick内多次调用只扫描一次
     */
    public ScanResult scan() {
        long currentTick = world.getTotalWorldTime();
        if (lastResult != null && currentTick == lastScanTick) {
            return lastResult;
        }

        int range = config.getDetectRange();
        int maxEntities = config.getMaxEntitiesPerScan();

        Vec3d pos = observer.getPositionVector();
        AxisAlignedBB aabb = new AxisAlignedBB(
                pos.x - range, pos.y - range, pos.z - range,
                pos.x + range, pos.y + range, pos.z + range
        );

        // 查询范围内所有实体
        List<Entity> allEntities = world.getEntitiesWithinAABB(Entity.class, aabb);

        // 按距离排序
        allEntities.sort(Comparator.comparingDouble(e -> e.getDistanceSq(observer)));

        // 分类
        List<EntityInfo> mobs = new ArrayList<>();
        List<EntityInfo> animals = new ArrayList<>();
        List<EntityInfo> players = new ArrayList<>();
        List<EntityInfo> items = new ArrayList<>();
        List<EntityInfo> others = new ArrayList<>();

        int counted = 0;
        for (Entity e : allEntities) {
            if (e == observer) continue;
            if (counted >= maxEntities) break;

            double dist = e.getDistance(observer);
            EntityInfo info = new EntityInfo(e, dist);
            if (e instanceof IMob) {
                mobs.add(info);
            } else if (e instanceof IAnimals) {
                animals.add(info);
            } else if (e instanceof EntityPlayer) {
                players.add(info);
            } else if (e instanceof EntityItem) {
                items.add(info);
            } else {
                others.add(info);
            }
            counted++;
        }

        // 周围方块信息（采样）
        List<BlockInfo> nearbyBlocks = scanNearbyBlocks(pos, 8);

        // 环境状态
        EnvironmentState state = new EnvironmentState();
        state.timeOfDay = world.getWorldTime() % 24000;
        state.isDaytime = world.isDaytime();
        state.isNighttime = world.isNighttime();
        state.isRaining = world.isRaining();
        state.isThundering = world.isThundering();
        state.dimension = world.provider.getDimension();
        state.difficulty = world.getDifficulty().name();
        state.biome = world.getBiome(new BlockPos(pos)).getBiomeName();
        state.lightLevel = world.getLight(new BlockPos(pos));

        ScanResult result = new ScanResult();
        result.mobs = mobs;
        result.animals = animals;
        result.players = players;
        result.items = items;
        result.others = others;
        result.totalEntitiesFound = allEntities.size() - 1; // 减去自己
        result.nearbyBlocks = nearbyBlocks;
        result.state = state;
        result.scanRange = range;
        result.scanTick = currentTick;

        lastResult = result;
        lastScanTick = currentTick;
        return result;
    }

    /**
     * 扫描周围方块（采样，不是全部）
     * 在观察者周围采样若干点，记录有意义的方块
     */
    private List<BlockInfo> scanNearbyBlocks(Vec3d center, int radius) {
        List<BlockInfo> blocks = new ArrayList<>();
        BlockPos centerPos = new BlockPos(center);

        // 采样策略：检查脚下、眼睛高度、头顶，以及4个方向
        int[][] offsets = {
                {0, -1, 0}, {0, 0, 0}, {0, 1, 0}, {0, 2, 0},
                {1, 0, 0}, {-1, 0, 0}, {0, 0, 1}, {0, 0, -1},
                {2, 0, 0}, {-2, 0, 0}, {0, 0, 2}, {0, 0, -2},
                {1, -1, 0}, {-1, -1, 0}, {0, -1, 1}, {0, -1, -1},
        };

        for (int[] off : offsets) {
            BlockPos pos = centerPos.add(off[0], off[1], off[2]);
            if (world.isBlockLoaded(pos)) {
                IBlockState state = world.getBlockState(pos);
                Block block = state.getBlock();
                String name = block.getRegistryName().toString();
                // 只记录非空气方块
                if (!block.isAir(state, world, pos)) {
                    blocks.add(new BlockInfo(name, pos, state.getBlock().getLocalizedName()));
                }
            }
        }
        return blocks;
    }

    /**
     * 查找最近的敌对生物
     */
    public EntityInfo findNearestHostile() {
        ScanResult r = scan();
        return r.mobs.isEmpty() ? null : r.mobs.get(0);
    }

    /**
     * 查找最近的掉落物
     */
    public EntityInfo findNearestItem() {
        ScanResult r = scan();
        return r.items.isEmpty() ? null : r.items.get(0);
    }

    /**
     * 查找最近的玩家（除了自己）
     */
    public EntityInfo findNearestPlayer() {
        ScanResult r = scan();
        return r.players.isEmpty() ? null : r.players.get(0);
    }

    /**
     * 生成环境摘要文本（用于AI上下文）
     */
    public String buildSummary() {
        ScanResult r = scan();
        StringBuilder sb = new StringBuilder();
        sb.append("【环境】探测范围").append(r.scanRange).append("格，共发现").append(r.totalEntitiesFound).append("个实体\n");
        sb.append("时间：").append(r.state.isDaytime ? "白天" : "夜晚")
                .append("，天气：").append(r.state.isRaining ? (r.state.isThundering ? "雷暴" : "下雨") : "晴朗")
                .append("，生物群系：").append(r.state.biome)
                .append("，光照：").append(r.state.lightLevel).append("\n");
        if (!r.mobs.isEmpty()) {
            sb.append("敌对生物(").append(r.mobs.size()).append(")：");
            for (int i = 0; i < Math.min(5, r.mobs.size()); i++) {
                sb.append(r.mobs.get(i).name).append("(").append(String.format("%.1f", r.mobs.get(i).distance)).append("m) ");
            }
            sb.append("\n");
        }
        if (!r.animals.isEmpty()) {
            sb.append("友好生物(").append(r.animals.size()).append(")：");
            for (int i = 0; i < Math.min(5, r.animals.size()); i++) {
                sb.append(r.animals.get(i).name).append("(").append(String.format("%.1f", r.animals.get(i).distance)).append("m) ");
            }
            sb.append("\n");
        }
        if (!r.items.isEmpty()) {
            sb.append("掉落物(").append(r.items.size()).append(")：");
            for (int i = 0; i < Math.min(5, r.items.size()); i++) {
                sb.append(r.items.get(i).name).append("(").append(String.format("%.1f", r.items.get(i).distance)).append("m) ");
            }
            sb.append("\n");
        }
        if (!r.nearbyBlocks.isEmpty()) {
            sb.append("周围方块：");
            for (BlockInfo b : r.nearbyBlocks) {
                sb.append(b.localizedName).append(" ");
            }
        }
        return sb.toString();
    }

    // ===== 数据结构 =====

    public static class ScanResult {
        public List<EntityInfo> mobs;
        public List<EntityInfo> animals;
        public List<EntityInfo> players;
        public List<EntityInfo> items;
        public List<EntityInfo> others;
        public List<BlockInfo> nearbyBlocks;
        public EnvironmentState state;
        public int totalEntitiesFound;
        public int scanRange;
        public long scanTick;
    }

    public static class EntityInfo {
        public String name;
        public String registryName;
        public double distance;
        public float health;
        public float maxHealth;
        public Vec3d position;
        public boolean isHostile;
        public Entity entityRef;

        public EntityInfo(Entity e, double distance) {
            this.name = e.getName();
            this.registryName = e.getClass().getSimpleName();
            this.distance = distance;
            this.position = e.getPositionVector();
            this.isHostile = e instanceof IMob;
            this.entityRef = e;
            if (e instanceof EntityLiving) {
                this.health = ((EntityLiving) e).getHealth();
                this.maxHealth = ((EntityLiving) e).getMaxHealth();
            }
        }
    }

    public static class BlockInfo {
        public String registryName;
        public BlockPos position;
        public String localizedName;

        public BlockInfo(String registryName, BlockPos position, String localizedName) {
            this.registryName = registryName;
            this.position = position;
            this.localizedName = localizedName;
        }
    }

    public static class EnvironmentState {
        public long timeOfDay;
        public boolean isDaytime;
        public boolean isNighttime;
        public boolean isRaining;
        public boolean isThundering;
        public int dimension;
        public String difficulty;
        public String biome;
        public int lightLevel;
    }
}
