package cn.meng.aifriend;

public interface IPartnerInteraction {
    /**
     * 左键：破坏方块 / 攻击实体
     * 自动使用实体自身视线瞄准目标；仅服务端生效，客户端空实现
     */
    void leftClick();

    /**
     * 右键：打开界面 / 放置方块 / 交互实体
     * 自动使用实体自身视线瞄准目标；仅服务端生效，客户端空实现
     */
    void rightClick();

    /**
     * 数字键1-9切换背包热栏
     * @param slot 键盘数字 1~9；实现内部自动转0-8数组下标；超出范围直接忽略
     */
    void selectSlot(int slot);
}