package cn.meng.aifriend;

public interface IPartnerMovement {
    /**
     * 局部本体坐标系移动
     * dirX: 本体向右; dirZ: 本体向前
     * w = dirZ=1.0; s = dirZ=-1.0; a = dirX=-1.0; d = dirX=1.0
     */
    void walk(double dirX, double dirZ, boolean jump);

    float getRotationYaw();

    void setRotationYaw(float yaw);
}