package cn.meng.aifriend.render;

import cn.meng.aifriend.entity.AIPartnerEntity;
import net.minecraft.client.model.ModelPlayer;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.entity.RenderPlayer;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.client.registry.IRenderFactory;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

/**
 * AI伙伴渲染器
 * 包装原版RenderPlayer，使用玩家人形模型，彻底解决白色长方体白模
 * 皮肤为空时回退Steve默认纹理
 */
@SideOnly(Side.CLIENT)
public class RenderAIPartner extends Render<AIPartnerEntity> {

    private final RenderPlayer innerPlayerRenderer;

    public RenderAIPartner(RenderManager renderManager) {
        super(renderManager);
        this.innerPlayerRenderer = new RenderPlayer(renderManager, false);
        this.mainModel = new ModelPlayer(0.0F, false);
        this.shadowSize = 0.5F;
    }

    @Nullable
    @Override
    protected ResourceLocation getEntityTexture(@Nonnull AIPartnerEntity entity) {
        String skinRes = entity.getPartnerSkin();
        if (skinRes == null || skinRes.isEmpty()) {
            return new ResourceLocation("minecraft:textures/entity/player/steve.png");
        }
        return new ResourceLocation(skinRes);
    }

    @Override
    public void doRender(@Nonnull AIPartnerEntity entity, double x, double y, double z, float entityYaw, float partialTicks) {
        // 委托原版玩家渲染，完整人形，杜绝白模
        innerPlayerRenderer.doRender(entity, x, y, z, entityYaw, partialTicks);
        super.doRender(entity, x, y, z, entityYaw, partialTicks);
    }

    @Override
    protected boolean canRenderName(AIPartnerEntity entity) {
        return true;
    }

    public static class Factory implements IRenderFactory<AIPartnerEntity> {
        @Override
        public Render<? super AIPartnerEntity> createRenderFor(RenderManager manager) {
            return new RenderAIPartner(manager);
        }
    }
}
