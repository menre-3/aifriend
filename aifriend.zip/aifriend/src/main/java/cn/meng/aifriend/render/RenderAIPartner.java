package com.aifriend.render;

import com.aifriend.entity.AIPartnerEntity;
import net.minecraft.client.model.ModelPlayer;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.client.registry.RenderingRegistry;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

import javax.annotation.Nullable;

/**
 * AI伙伴渲染器
 * 使用玩家模型(ModelPlayer)渲染，外观像真人玩家
 *
 * 皮肤支持：
 * - 默认使用Steve皮肤
 * - 可通过配置 partnerSkin 设置为玩家名（自动下载皮肤）或URL
 *
 * 注意：这是客户端代码，只在客户端加载
 */
@SideOnly(Side.CLIENT)
public class RenderAIPartner extends RenderLiving<AIPartnerEntity> {

    // 默认Steve皮肤
    private static final ResourceLocation DEFAULT_SKIN =
            new ResourceLocation("textures/entity/steve.png");

    // Alex皮肤（细手臂）
    private static final ResourceLocation ALEX_SKIN =
            new ResourceLocation("textures/entity/alex.png");

    public RenderAIPartner(RenderManager renderManager) {
        super(renderManager, new ModelPlayer(0.0F, false), 0.5F);
        // 添加层（护甲、手持物品等）
        this.addLayer(new net.minecraft.client.renderer.entity.layers.LayerBipedArmor(this));
        this.addLayer(new net.minecraft.client.renderer.entity.layers.LayerHeldItem(this));
        this.addLayer(new net.minecraft.client.renderer.entity.layers.LayerArrow(this));
    }

    @Nullable
    @Override
    protected ResourceLocation getEntityTexture(AIPartnerEntity entity) {
        // 目前使用默认皮肤
        // TODO: 支持从配置读取皮肤URL或玩家名并加载
        return DEFAULT_SKIN;
    }

    @Override
    public void doRender(AIPartnerEntity entity, double x, double y, double z,
                         float entityYaw, float partialTicks) {
        // 渲染名字标签
        super.doRender(entity, x, y, z, entityYaw, partialTicks);
    }

    @Override
    protected boolean canRenderName(AIPartnerEntity entity) {
        // 总是显示名字
        return true;
    }

    /**
     * 注册渲染器（在客户端预初始化时调用）
     */
    public static void register() {
        RenderingRegistry.registerEntityRenderingHandler(AIPartnerEntity.class,
                new net.minecraftforge.fml.client.registry.IRenderFactory<AIPartnerEntity>() {
                    @Override
                    public Render<? super AIPartnerEntity> createRenderFor(RenderManager manager) {
                        return new RenderAIPartner(manager);
                    }
                });
    }
}
