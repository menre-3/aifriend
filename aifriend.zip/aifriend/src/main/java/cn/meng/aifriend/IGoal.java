package cn.meng.aifriend;

import net.minecraft.entity.player.EntityPlayer;

public interface IGoal {
    String getName();
    String getDecisionPrompt();
    void applyResult(AIBrain brain, EntityPlayer owner, String text);
    boolean isDone();
}