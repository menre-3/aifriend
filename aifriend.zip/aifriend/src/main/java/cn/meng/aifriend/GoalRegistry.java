package cn.meng.aifriend;

import java.util.HashMap;
import java.util.Map;

public class GoalRegistry {

    public interface GoalFactory {
        IGoal create(String arg, int count);
    }

    private static final Map<String, GoalFactory> factories = new HashMap<>();

    /** AIFriendMod.preInit 调用，注册默认目标 */
    public static void registerDefaults() {
        register("mine", MiningGoal::new);
        register("chop", (arg, count) -> new ChoppingGoal(count));
        register("improve", (arg, count) -> new SelfImproveGoal());
    }

    public static void register(String type, GoalFactory factory) {
        factories.put(type.toLowerCase(), factory);
    }

    /** 按类型创建任务；未知类型返回 null */
    public static IGoal create(String type, String arg, int count) {
        GoalFactory f = factories.get(type.toLowerCase());
        return f == null ? null : f.create(arg, count);
    }
}