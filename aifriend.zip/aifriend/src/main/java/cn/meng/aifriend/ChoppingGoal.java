package cn.meng.aifriend;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.BlockPos;

public class ChoppingGoal implements IGoal {

    private final int target;
    private int chopped = 0;

    public ChoppingGoal(int target) { this.target = target; }

    @Override public String getName() { return "chop"; }
    @Override public boolean isDone() { return this.chopped >= this.target; }

    @Override
    public String getDecisionPrompt() {
        return "砍" + this.target + "个原木（已砍" + this.chopped + "个）。"
                + "看到近处有树就用 @@MINE@@ dx,dy,dz；只见方向就 @@KEY@@ 朝它走。";
    }

    @Override
    public void applyResult(AIBrain brain, EntityPlayer owner, String text) {
        int idx = text.indexOf("@@MINE@@");
        if (idx >= 0) {
            try {
                String[] p = text.substring(idx + "@@MINE@@".length()).trim().split(",");
                int dx = Integer.parseInt(p[0].trim());
                int dy = Integer.parseInt(p[1].trim());
                int dz = Integer.parseInt(p[2].trim());
                BlockPos pos = owner.getPosition().add(dx, dy, dz);
                brain.getBody().mineBlock(pos);
                this.chopped++;
            } catch (Exception ignored) {}
        }
        ActionParser.execute(brain, text);
    }
}