package cn.meng.aifriend;

import net.minecraft.entity.player.EntityPlayer;

public class SelfImproveGoal implements IGoal {

    @Override public String getName() { return "improve"; }

    /** 常驻目标，永不"完成"（自我提升是持续的） */
    @Override public boolean isDone() { return false; }

    @Override
    public String getDecisionPrompt() {
        return "你在自我提升：收集更多资源、合成装备、强化防御。"
                + "根据滤网环境和背包状态，自主决定下一步（挖矿/捡拾/合成/装备）。";
    }

    @Override
    public void applyResult(AIBrain brain, EntityPlayer owner, String text) {
        // 自我提升 = 自主行动，交给 ActionParser 键值执行
        ActionParser.execute(brain, text);
    }
}