package com.aifriend.api;

import net.minecraft.entity.Entity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

/**
 * AI伙伴身体接口
 * 大脑层通过此接口控制身体执行动作，解耦"决策"与"执行"
 * 身体层(AIPartnerEntity)实现此接口
 */
public interface IPartnerBody {

    // ===== 移动 =====
    Movement getMovement();

    // ===== 交互 =====
    Interaction getInteraction();

    // ===== 背包 =====
    Inventory getInventory();

    // ===== 位置与状态 =====
    Vec3d getPositionVec();
    BlockPos getPosition();
    float getHealth();
    float getMaxHealth();
    boolean isSneaking();
    boolean isSprinting();
    boolean isAlive();

    // ===== 动作 =====
    void setSneaking(boolean sneaking);
    void setSprinting(boolean sprinting);
    void jump();
    void swingArm();

    // ===== 说话 =====
    void speak(String message);

    // ===== 目标实体 =====
    Entity getOwner();
    void setAttackTarget(Entity target);
    Entity getAttackTarget();

    // ===== 世界 =====
    net.minecraft.world.World getWorld();
}
