package cn.meng.aifriend.api;

import net.minecraft.entity.Entity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * AI伙伴身体接口
 * 大脑层通过此接口控制身体，解耦决策与执行
 */
public interface IPartnerBody {

    Movement getMovement();
    Interaction getInteraction();
    Inventory getInventory();

    Vec3d getPositionVec();
    BlockPos getBlockPosition();
    float getHealthValue();
    float getMaxHealthValue();
    boolean isBodySneaking();
    boolean isBodySprinting();
    boolean isEntityAlive();

    void setBodySneaking(boolean sneaking);
    void setBodySprinting(boolean sprinting);
    void doJump();
    void doSwingArm();

    void speak(String message);

    Entity getOwnerEntity();
    void setAttackTargetEntity(Entity target);
    Entity getAttackTargetEntity();

    World getWorldObject();
}
