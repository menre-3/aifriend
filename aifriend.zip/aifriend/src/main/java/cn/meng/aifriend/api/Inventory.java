package cn.meng.aifriend.api;

import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

import java.util.List;
import java.util.Map;

/**
 * 背包管理接口
 */
public interface Inventory {

    List<ItemStack> getAllItems();
    int countItem(Item item);
    int countItemByName(String registryName);
    boolean hasItem(Item item);
    boolean hasItemWithCount(Item item, int minCount);
    ItemStack takeItem(Item item, int count);
    ItemStack addItem(ItemStack stack);
    boolean equipBetterArmor();
    boolean equipBetterWeapon();
    boolean equipBetterTool(String toolType);
    int getArmorValueNow();
    int getUsedSlotsCount();
    int getCapacitySlots();
    boolean isInventoryFull();
    void dropItemNow(Item item, int count);
    void sortInventoryNow();
    Map<String, Integer> getInventorySummaryMap();
}
