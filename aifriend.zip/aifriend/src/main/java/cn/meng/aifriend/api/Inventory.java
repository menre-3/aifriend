package com.aifriend.api;

import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

import java.util.List;
import java.util.Map;

/**
 * 背包管理接口
 * 封装AI伙伴的物品栏操作，支持查询、装备、合成等
 */
public interface Inventory {

    /**
     * 获取背包中所有物品
     */
    List<ItemStack> getAllItems();

    /**
     * 获取指定物品的数量
     */
    int countItem(Item item);

    /**
     * 获取指定物品的数量（按注册名）
     */
    int countItem(String registryName);

    /**
     * 检查是否拥有某物品（至少1个）
     */
    boolean hasItem(Item item);

    /**
     * 检查是否拥有某物品（至少指定数量）
     */
    boolean hasItem(Item item, int minCount);

    /**
     * 从背包中取出指定数量的物品
     * @return 实际取出的物品堆（可能不足）
     */
    ItemStack takeItem(Item item, int count);

    /**
     * 添加物品到背包
     * @return 放不下的部分
     */
    ItemStack addItem(ItemStack stack);

    /**
     * 装备护甲（如果有更好的）
     * @return 是否装备了新物品
     */
    boolean equipBetterArmor();

    /**
     * 装备武器（如果有更好的）
     */
    boolean equipBetterWeapon();

    /**
     * 装备工具（如果有更好的）
     */
    boolean equipBetterTool(String toolType);

    /**
     * 获取当前护甲值
     */
    int getArmorValue();

    /**
     * 获取背包总占用格数
     */
    int getUsedSlots();

    /**
     * 获取背包容量
     */
    int getCapacity();

    /**
     * 检查背包是否已满
     */
    boolean isFull();

    /**
     * 丢弃指定物品
     */
    void dropItem(Item item, int count);

    /**
     * 整理背包（合并相同物品）
     */
    void sortInventory();

    /**
     * 获取背包内容摘要（用于AI上下文）
     * 格式：{物品名: 数量, ...}
     */
    Map<String, Integer> getInventorySummary();
}
