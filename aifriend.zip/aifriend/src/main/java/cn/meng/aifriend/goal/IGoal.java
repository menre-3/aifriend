package com.aifriend.goal;

import com.aifriend.api.IPartnerBody;

/**
 * 目标接口（任务层）
 * 所有AI行为目标都实现此接口
 *
 * 目标驱动是本模组的核心行为模式：
 * - AI每轮判断当前优先级最高的目标
 * - 目标有开始、执行、结束三个阶段
 * - 目标可以被更高优先级的目标打断
 *
 * 优先级顺序（从高到低）：
 * 1. 玩家直接指令
 * 2. 避险（战斗/逃跑）
 * 3. 自我提升（装备/防御）
 * 4. 工作（挖矿/砍树/建造）
 * 5. 跟随玩家
 * 6. 互动/闲逛
 */
public interface IGoal {

    /**
     * 获取目标名称
     */
    String getName();

    /**
     * 获取目标优先级（数字越小优先级越高）
     */
    int getPriority();

    /**
     * 检查目标是否应该开始执行
     */
    boolean shouldStart(IPartnerBody body);

    /**
     * 目标开始时调用
     */
    void start(IPartnerBody body);

    /**
     * 每tick更新目标状态
     * @return true=继续执行，false=目标完成
     */
    boolean update(IPartnerBody body);

    /**
     * 目标结束时调用
     */
    void stop(IPartnerBody body);

    /**
     * 检查目标是否仍在执行
     */
    boolean isActive();

    /**
     * 获取目标描述（用于AI上下文）
     */
    String getDescription();
}
