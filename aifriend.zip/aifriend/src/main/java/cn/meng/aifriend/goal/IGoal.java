package cn.meng.aifriend.goal;

import cn.meng.aifriend.api.IPartnerBody;

/**
 * 目标接口
 */
public interface IGoal {
    String getName();
    int getPriority();
    boolean shouldStart(IPartnerBody body);
    void start(IPartnerBody body);
    boolean update(IPartnerBody body);
    void stop(IPartnerBody body);
    boolean isActive();
    String getDescription();
}
