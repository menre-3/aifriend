package com.aifriend.net;

import com.aifriend.AIFriendConfig;
import com.aifriend.info.MemoryManager;
import org.apache.logging.log4j.Logger;

import javax.net.ssl.HttpsURLConnection;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * AI API 客户端（网络层）
 * 调用 OpenAI 兼容的 Chat Completions API
 *
 * 纯 JDK 实现，不依赖第三方 HTTP 库，使用 HttpURLConnection
 * 支持：
 * - 自定义 API 端点（兼容本地部署的模型服务）
 * - 自定义模型名
 * - 超时和重试
 * - 对话历史传入
 *
 * API 格式（OpenAI 兼容）：
 * POST {endpoint}/chat/completions
 * {
 *   "model": "gpt-4o-mini",
 *   "messages": [
 *     {"role": "system", "content": "..."},
 *     {"role": "user", "content": "..."}
 *   ],
 *   "temperature": 0.7,
 *   "max_tokens": 1024
 * }
 */
public class AiApiClient {

    private final AIFriendConfig config;
    private Logger logger;

    // 统计
    private long totalRequests = 0;
    private long failedRequests = 0;
    private long totalTokensUsed = 0;

    public AiApiClient(AIFriendConfig config) {
        this.config = config;
    }

    public void setLogger(Logger logger) {
        this.logger = logger;
    }

    /**
     * 发送聊天请求
     * @param userMessage 当前用户消息（或系统提示+上下文）
     * @param history 对话历史
     * @return AI的回复文本
     */
    public String chat(String userMessage, List<MemoryManager.DialogueEntry> history) throws Exception {
        // 构建消息列表
        List<ChatMessage> messages = new ArrayList<>();

        // 对话历史
        if (history != null) {
            for (MemoryManager.DialogueEntry entry : history) {
                String role = entry.speaker == MemoryManager.Speaker.PLAYER ? "user" : "assistant";
                messages.add(new ChatMessage(role, entry.message));
            }
        }

        // 当前消息
        messages.add(new ChatMessage("user", userMessage));

        return doRequest(messages);
    }

    /**
     * 发送聊天请求（带系统提示）
     */
    public String chatWithSystem(String systemPrompt, String userMessage,
                                  List<MemoryManager.DialogueEntry> history) throws Exception {
        List<ChatMessage> messages = new ArrayList<>();
        if (systemPrompt != null && !systemPrompt.isEmpty()) {
            messages.add(new ChatMessage("system", systemPrompt));
        }
        if (history != null) {
            for (MemoryManager.DialogueEntry entry : history) {
                String role = entry.speaker == MemoryManager.Speaker.PLAYER ? "user" : "assistant";
                messages.add(new ChatMessage(role, entry.message));
            }
        }
        messages.add(new ChatMessage("user", userMessage));
        return doRequest(messages);
    }

    /**
     * 执行HTTP请求
     */
    private String doRequest(List<ChatMessage> messages) throws Exception {
        String endpoint = config.getApiEndpoint();
        // 确保端点以 /chat/completions 结尾
        if (!endpoint.endsWith("/chat/completions")) {
            endpoint = endpoint.replaceAll("/+$", "") + "/chat/completions";
        }

        // 构建请求体
        String requestBody = buildRequestBody(messages);

        int maxRetries = config.getApiMaxRetries();
        Exception lastException = null;

        for (int attempt = 0; attempt <= maxRetries; attempt++) {
            HttpURLConnection conn = null;
            try {
                URL url = new URL(endpoint);
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Authorization", "Bearer " + config.getApiKey());
                conn.setConnectTimeout(config.getApiTimeoutMs());
                conn.setReadTimeout(config.getApiTimeoutMs());
                conn.setDoOutput(true);
                conn.setDoInput(true);

                // 发送请求体
                try (OutputStream os = conn.getOutputStream()) {
                    os.write(requestBody.getBytes(StandardCharsets.UTF_8));
                    os.flush();
                }

                int responseCode = conn.getResponseCode();
                totalRequests++;

                if (responseCode == 200) {
                    String responseBody = readStream(conn.getInputStream());
                    String content = parseResponseContent(responseBody);
                    if (content != null) {
                        return content;
                    }
                    throw new RuntimeException("API返回格式异常，无法解析content字段");
                } else {
                    String errorBody = readStream(conn.getErrorStream() != null ? conn.getErrorStream() : conn.getInputStream());
                    failedRequests++;
                    throw new RuntimeException("API返回错误 " + responseCode + ": " + errorBody);
                }
            } catch (Exception e) {
                lastException = e;
                if (attempt < maxRetries) {
                    // 退避重试
                    long waitMs = (long) Math.pow(2, attempt) * 500;
                    if (logger != null) {
                        logger.warn("API请求失败(第{}次)，{}ms后重试: {}", attempt + 1, waitMs, e.getMessage());
                    }
                    Thread.sleep(waitMs);
                }
            } finally {
                if (conn != null) {
                    conn.disconnect();
                }
            }
        }

        failedRequests++;
        throw lastException != null ? lastException : new RuntimeException("API请求失败");
    }

    /**
     * 构建JSON请求体（手动拼接，避免依赖JSON库）
     */
    private String buildRequestBody(List<ChatMessage> messages) {
        StringBuilder sb = new StringBuilder();
        sb.append("{");
        sb.append("\"model\":\"").append(escapeJson(config.getModel())).append("\",");
        sb.append("\"temperature\":0.7,");
        sb.append("\"max_tokens\":1024,");
        sb.append("\"messages\":[");
        for (int i = 0; i < messages.size(); i++) {
            if (i > 0) sb.append(",");
            ChatMessage msg = messages.get(i);
            sb.append("{\"role\":\"").append(escapeJson(msg.role))
                    .append("\",\"content\":\"").append(escapeJson(msg.content)).append("\"}");
        }
        sb.append("]");
        sb.append("}");
        return sb.toString();
    }

    /**
     * 简单解析JSON响应中的 choices[0].message.content
     * 不使用完整JSON解析器，用字符串查找（足够应对标准OpenAI格式）
     */
    private String parseResponseContent(String json) {
        if (json == null || json.isEmpty()) return null;
        try {
            // 查找 "content":"..."
            int contentIdx = json.indexOf("\"content\"");
            if (contentIdx < 0) return null;
            int colonIdx = json.indexOf(':', contentIdx);
            if (colonIdx < 0) return null;
            // 跳过空白
            int i = colonIdx + 1;
            while (i < json.length() && Character.isWhitespace(json.charAt(i))) i++;
            if (i >= json.length() || json.charAt(i) != '"') return null;
            i++; // 跳过开头引号
            StringBuilder content = new StringBuilder();
            while (i < json.length()) {
                char c = json.charAt(i);
                if (c == '\\' && i + 1 < json.length()) {
                    char next = json.charAt(i + 1);
                    switch (next) {
                        case 'n': content.append('\n'); break;
                        case 't': content.append('\t'); break;
                        case 'r': content.append('\r'); break;
                        case '"': content.append('"'); break;
                        case '\\': content.append('\\'); break;
                        case '/': content.append('/'); break;
                        default: content.append(next);
                    }
                    i += 2;
                } else if (c == '"') {
                    break;
                } else {
                    content.append(c);
                    i++;
                }
            }
            return content.toString();
        } catch (Exception e) {
            if (logger != null) {
                logger.error("解析API响应失败: {}", e.getMessage());
            }
            return null;
        }
    }

    private String readStream(InputStream is) throws Exception {
        if (is == null) return "";
        BufferedReader reader = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            sb.append(line);
        }
        reader.close();
        return sb.toString();
    }

    private String escapeJson(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }

    /**
     * 测试API连接
     */
    public boolean testConnection() {
        try {
            List<ChatMessage> messages = new ArrayList<>();
            messages.add(new ChatMessage("user", "ping"));
            String result = doRequest(messages);
            return result != null && !result.isEmpty();
        } catch (Exception e) {
            if (logger != null) {
                logger.error("API连接测试失败: {}", e.getMessage());
            }
            return false;
        }
    }

    // ===== 统计 =====

    public long getTotalRequests() { return totalRequests; }
    public long getFailedRequests() { return failedRequests; }
    public long getTotalTokensUsed() { return totalTokensUsed; }

    public double getFailureRate() {
        if (totalRequests == 0) return 0;
        return (double) failedRequests / totalRequests;
    }

    // ===== 数据结构 =====

    private static class ChatMessage {
        final String role;
        final String content;

        ChatMessage(String role, String content) {
            this.role = role;
            this.content = content;
        }
    }
}
