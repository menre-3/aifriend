package cn.meng.aifriend.net;

import cn.meng.aifriend.AIFriendConfig;
import cn.meng.aifriend.info.MemoryManager;
import org.apache.logging.log4j.Logger;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * AI API客户端（纯JDK实现，OpenAI兼容）
 */
public class AiApiClient {

    private final AIFriendConfig config;
    private Logger logger;
    private long totalRequests = 0;
    private long failedRequests = 0;

    public AiApiClient(AIFriendConfig config) {
        this.config = config;
    }

    public void setLogger(Logger logger) {
        this.logger = logger;
    }

    public String chat(String userMessage, List<MemoryManager.DialogueEntry> history) throws Exception {
        List<ChatMessage> messages = new ArrayList<>();
        if (history != null) {
            for (MemoryManager.DialogueEntry entry : history) {
                String role = entry.speaker == MemoryManager.Speaker.PLAYER ? "user" : "assistant";
                messages.add(new ChatMessage(role, entry.message));
            }
        }
        messages.add(new ChatMessage("user", userMessage));
        return doRequest(messages);
    }

    public String chatWithSystem(String systemPrompt, String userMessage, List<MemoryManager.DialogueEntry> history) throws Exception {
        List<ChatMessage> messages = new ArrayList<>();
        if (systemPrompt != null && !systemPrompt.isEmpty()) messages.add(new ChatMessage("system", systemPrompt));
        if (history != null) {
            for (MemoryManager.DialogueEntry entry : history) {
                String role = entry.speaker == MemoryManager.Speaker.PLAYER ? "user" : "assistant";
                messages.add(new ChatMessage(role, entry.message));
            }
        }
        messages.add(new ChatMessage("user", userMessage));
        return doRequest(messages);
    }

    private String doRequest(List<ChatMessage> messages) throws Exception {
        String endpoint = config.apiEndpoint;
        if (!endpoint.endsWith("/chat/completions")) {
            endpoint = endpoint.replaceAll("/+$", "") + "/chat/completions";
        }
        String requestBody = buildRequestBody(messages);
        int maxRetries = config.apiMaxRetries;
        Exception lastException = null;

        for (int attempt = 0; attempt <= maxRetries; attempt++) {
            HttpURLConnection conn = null;
            try {
                URL url = new URL(endpoint);
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Authorization", "Bearer " + config.apiKey);
                conn.setConnectTimeout(config.apiTimeoutMs);
                conn.setReadTimeout(config.apiTimeoutMs);
                conn.setDoOutput(true);
                conn.setDoInput(true);

                try (OutputStream os = conn.getOutputStream()) {
                    os.write(requestBody.getBytes(StandardCharsets.UTF_8));
                    os.flush();
                }

                int code = conn.getResponseCode();
                totalRequests++;
                if (code == 200) {
                    String body = readStream(conn.getInputStream());
                    String content = parseContent(body);
                    if (content != null) return content;
                    throw new RuntimeException("API返回格式异常");
                } else {
                    String err = readStream(conn.getErrorStream() != null ? conn.getErrorStream() : conn.getInputStream());
                    failedRequests++;
                    throw new RuntimeException("API错误 " + code + ": " + err);
                }
            } catch (Exception e) {
                lastException = e;
                if (attempt < maxRetries) {
                    Thread.sleep((long) Math.pow(2, attempt) * 500);
                }
            } finally {
                if (conn != null) conn.disconnect();
            }
        }
        failedRequests++;
        throw lastException != null ? lastException : new RuntimeException("API请求失败");
    }

    private String buildRequestBody(List<ChatMessage> messages) {
        StringBuilder sb = new StringBuilder();
        sb.append("{\"model\":\"").append(escape(config.model)).append("\",");
        sb.append("\"temperature\":0.7,\"max_tokens\":1024,");
        sb.append("\"messages\":[");
        for (int i = 0; i < messages.size(); i++) {
            if (i > 0) sb.append(",");
            sb.append("{\"role\":\"").append(escape(messages.get(i).role))
                    .append("\",\"content\":\"").append(escape(messages.get(i).content)).append("\"}");
        }
        sb.append("]}");
        return sb.toString();
    }

    private String parseContent(String json) {
        if (json == null || json.isEmpty()) return null;
        int idx = json.indexOf("\"content\"");
        if (idx < 0) return null;
        int colon = json.indexOf(':', idx);
        if (colon < 0) return null;
        int i = colon + 1;
        while (i < json.length() && Character.isWhitespace(json.charAt(i))) i++;
        if (i >= json.length() || json.charAt(i) != '"') return null;
        i++;
        StringBuilder sb = new StringBuilder();
        while (i < json.length()) {
            char c = json.charAt(i);
            if (c == '\\' && i + 1 < json.length()) {
                char n = json.charAt(i + 1);
                switch (n) {
                    case 'n': sb.append('\n'); break;
                    case 't': sb.append('\t'); break;
                    case 'r': sb.append('\r'); break;
                    case '"': sb.append('"'); break;
                    case '\\': sb.append('\\'); break;
                    default: sb.append(n);
                }
                i += 2;
            } else if (c == '"') {
                break;
            } else {
                sb.append(c);
                i++;
            }
        }
        return sb.toString();
    }

    private String readStream(InputStream is) throws Exception {
        if (is == null) return "";
        BufferedReader reader = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) sb.append(line);
        reader.close();
        return sb.toString();
    }

    private String escape(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r").replace("\t", "\\t");
    }

    public boolean testConnection() {
        try {
            List<ChatMessage> messages = new ArrayList<>();
            messages.add(new ChatMessage("user", "ping"));
            String r = doRequest(messages);
            return r != null && !r.isEmpty();
        } catch (Exception e) {
            if (logger != null) logger.error("API连接测试失败: {}", e.getMessage());
            return false;
        }
    }

    public long getTotalRequests() { return totalRequests; }
    public long getFailedRequests() { return failedRequests; }

    private static class ChatMessage {
        final String role;
        final String content;
        ChatMessage(String role, String content) { this.role = role; this.content = content; }
    }
}
