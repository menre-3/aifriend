package cn.meng.aifriend.brain;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 意图解析器：解析 @@ACT@@ action(params) 标记
 */
public class ActionParser {

    private static final Pattern ACT_PATTERN = Pattern.compile(
            "@@ACT@@\\s*(\\w+)\\s*(?:\\(([^)]*)\\))?", Pattern.CASE_INSENSITIVE);

    public ParseResult parse(String rawResponse) {
        if (rawResponse == null || rawResponse.isEmpty()) {
            return new ParseResult("", new ArrayList<>());
        }
        List<ActionIntent> actions = new ArrayList<>();
        Matcher matcher = ACT_PATTERN.matcher(rawResponse);
        while (matcher.find()) {
            String actionName = matcher.group(1).toLowerCase();
            String paramsStr = matcher.group(2);
            actions.add(new ActionIntent(actionName, parseParams(paramsStr)));
        }
        String text = ACT_PATTERN.matcher(rawResponse).replaceAll("").trim();
        text = text.replaceAll("\\n{3,}", "\n\n").trim();
        return new ParseResult(text, actions);
    }

    private Map<String, String> parseParams(String paramsStr) {
        Map<String, String> params = new HashMap<>();
        if (paramsStr == null || paramsStr.isEmpty()) return params;
        String[] parts = paramsStr.split(",");
        int idx = 0;
        for (String part : parts) {
            part = part.trim();
            if (part.isEmpty()) continue;
            int eq = part.indexOf('=');
            if (eq > 0) {
                params.put(part.substring(0, eq).trim(), part.substring(eq + 1).trim());
            } else {
                params.put("_" + idx, part);
                idx++;
            }
        }
        return params;
    }

    public boolean hasAction(String text) {
        return text != null && ACT_PATTERN.matcher(text).find();
    }

    public static class ParseResult {
        public final String speechText;
        public final List<ActionIntent> actions;
        public ParseResult(String speechText, List<ActionIntent> actions) {
            this.speechText = speechText;
            this.actions = actions;
        }
        public boolean hasActions() { return !actions.isEmpty(); }
        public boolean hasSpeech() { return speechText != null && !speechText.isEmpty(); }
    }

    public static class ActionIntent {
        public final String action;
        public final Map<String, String> params;
        public ActionIntent(String action, Map<String, String> params) {
            this.action = action;
            this.params = params;
        }
        public String getParam(String key) { return params.get(key); }
        public int getIntParam(String key, int def) {
            String v = params.get(key);
            if (v == null) return def;
            try { return Integer.parseInt(v.trim()); } catch (NumberFormatException e) { return def; }
        }
        public double getDoubleParam(String key, double def) {
            String v = params.get(key);
            if (v == null) return def;
            try { return Double.parseDouble(v.trim()); } catch (NumberFormatException e) { return def; }
        }
    }
}
