package com.aifriend.brain;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 意图解析器
 * 解析AI返回的文本中的动作意图标记 @@ACT@@
 *
 * 意图格式：
 *   @@ACT@@ action_name(param1=value1,param2=value2)
 *
 * 支持的动作：
 *   mine(x,y,z)           - 挖掘指定位置方块
 *   attack(entity_id)     - 攻击指定实体
 *   follow(player)        - 跟随玩家
 *   move(x,y,z)           - 移动到指定位置
 *   place(x,y,z,item)     - 在指定位置放置方块
 *   equip(item)           - 装备指定物品
 *   use(item)             - 使用指定物品
 *   sneak()               - 蹲下
 *   jump()                - 跳跃
 *   sprint()              - 奔跑
 *   stop()                - 停止当前动作
 *   speak(text)           - 说话（通常直接输出文本即可，此标记用于强制说话）
 *   lookat(x,y,z)         - 看向指定位置
 *   wander()              - 随机闲逛
 *   pickup()              - 拾取附近物品
 *   defend(player)        - 保护玩家
 *   selfimprove()         - 自我提升（检查装备/物品）
 *
 * 解析结果分为：
 *   - 纯文本回复（要对玩家说的话）
 *   - 动作意图列表（要执行的动作）
 */
public class ActionParser {

    // 匹配 @@ACT@@ action(params) 模式
    private static final Pattern ACT_PATTERN = Pattern.compile(
            "@@ACT@@\\s*(\\w+)\\s*(?:\\(([^)]*)\\))?",
            Pattern.CASE_INSENSITIVE
    );

    /**
     * 解析AI返回的完整文本
     * @param rawResponse AI原始返回
     * @return 解析结果，包含纯文本和动作列表
     */
    public ParseResult parse(String rawResponse) {
        if (rawResponse == null || rawResponse.isEmpty()) {
            return new ParseResult("", new ArrayList<>());
        }

        List<ActionIntent> actions = new ArrayList<>();
        Matcher matcher = ACT_PATTERN.matcher(rawResponse);

        // 提取所有动作意图
        while (matcher.find()) {
            String actionName = matcher.group(1).toLowerCase();
            String paramsStr = matcher.group(2);
            ActionIntent intent = new ActionIntent(actionName, parseParams(paramsStr));
            actions.add(intent);
        }

        // 移除所有动作标记，剩下的就是纯文本回复
        String text = ACT_PATTERN.matcher(rawResponse).replaceAll("").trim();
        // 清理多余空行
        text = text.replaceAll("\\n{3,}", "\n\n").trim();

        return new ParseResult(text, actions);
    }

    /**
     * 解析参数字符串为 key=value 对
     * 支持格式：x=1,y=2,z=3 或 1,2,3（位置参数）
     */
    private java.util.Map<String, String> parseParams(String paramsStr) {
        java.util.Map<String, String> params = new java.util.HashMap<>();
        if (paramsStr == null || paramsStr.isEmpty()) return params;

        String[] parts = paramsStr.split(",");
        int positionalIndex = 0;
        for (String part : parts) {
            part = part.trim();
            if (part.isEmpty()) continue;
            int eq = part.indexOf('=');
            if (eq > 0) {
                String key = part.substring(0, eq).trim();
                String value = part.substring(eq + 1).trim();
                params.put(key, value);
            } else {
                // 位置参数
                params.put("_" + positionalIndex, part);
                positionalIndex++;
            }
        }
        return params;
    }

    /**
     * 检查文本中是否包含动作意图
     */
    public boolean hasAction(String text) {
        return text != null && ACT_PATTERN.matcher(text).find();
    }

    // ===== 数据结构 =====

    public static class ParseResult {
        public final String speechText;
        public final List<ActionIntent> actions;

        public ParseResult(String speechText, List<ActionIntent> actions) {
            this.speechText = speechText;
            this.actions = actions;
        }

        public boolean hasActions() {
            return !actions.isEmpty();
        }

        public boolean hasSpeech() {
            return speechText != null && !speechText.isEmpty();
        }
    }

    public static class ActionIntent {
        public final String action;
        public final java.util.Map<String, String> params;

        public ActionIntent(String action, java.util.Map<String, String> params) {
            this.action = action;
            this.params = params;
        }

        /**
         * 获取字符串参数
         */
        public String getParam(String key) {
            return params.get(key);
        }

        /**
         * 获取整数参数
         */
        public int getIntParam(String key, int defaultValue) {
            String v = params.get(key);
            if (v == null) {
                // 尝试位置参数
                v = params.get("_" + key);
            }
            if (v == null) return defaultValue;
            try {
                return Integer.parseInt(v.trim());
            } catch (NumberFormatException e) {
                return defaultValue;
            }
        }

        /**
         * 获取双精度参数
         */
        public double getDoubleParam(String key, double defaultValue) {
            String v = params.get(key);
            if (v == null) return defaultValue;
            try {
                return Double.parseDouble(v.trim());
            } catch (NumberFormatException e) {
                return defaultValue;
            }
        }

        /**
         * 获取位置参数（按索引）
         */
        public String getPositional(int index) {
            return params.get("_" + index);
        }

        @Override
        public String toString() {
            return action + params;
        }
    }
}
