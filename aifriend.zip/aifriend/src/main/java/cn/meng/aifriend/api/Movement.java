package com.aifriend.api;

import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

/**
 * 移动控制接口
 * 封装寻路、行走、奔跑、跳跃等移动能力
 * 大脑层只需要调用这些方法，不需要关心具体寻路算法
 */
public interface Movement {

    /**
     * 移动到指定位置（自动寻路）
     * @param target 目标位置
     * @param speed 速度倍率 1.0=正常
     * @return 是否成功开始移动
     */
    boolean moveTo(Vec3d target, double speed);

    /**
     * 移动到指定方块位置
     */
    boolean moveTo(BlockPos pos, double speed);

    /**
     * 跟随目标实体
     * @param distance 保持的距离
     */
    void follow(net.minecraft.entity.Entity target, double distance);

    /**
     * 停止移动
     */
    void stop();

    /**
     * 是否正在移动
     */
    boolean isMoving();

    /**
     * 朝目标方向看
     */
    void lookAt(Vec3d target);

    /**
     * 朝实体看
     */
    void lookAt(net.minecraft.entity.Entity entity);

    /**
     * 随机闲逛（用于空闲状态）
     */
    void wander();

    /**
     * 远离目标（逃跑/拉开距离）
     */
    void moveAwayFrom(Vec3d threat, double distance);
}
