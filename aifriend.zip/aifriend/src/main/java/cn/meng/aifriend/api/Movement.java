package cn.meng.aifriend.api;

import net.minecraft.entity.Entity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

/**
 * 移动控制接口
 */
public interface Movement {

    boolean moveTo(Vec3d target, double speed);
    boolean moveTo(BlockPos pos, double speed);
    void follow(Entity target, double distance);
    void stopMoving();
    boolean isMovingNow();
    void lookAt(Vec3d target);
    void lookAtEntity(Entity entity);
    void wander();
    void moveAwayFrom(Vec3d threat, double distance);
}
