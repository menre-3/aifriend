package cn.meng.aifriend;

import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.InventoryBasic;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.List;
import java.util.UUID;

public class AIPartnerEntity extends EntityCreature implements IPartnerBody {
    private final InventoryBasic inventory = new InventoryBasic("partner", false, 27);
    private int currentSlot = 0;              // 热栏 0-8
    private AIBrain brain;
    private final SpeakBudget speakBudget;
    private UUID ownerUUID = null;
    private double spawnX, spawnY, spawnZ;
    private boolean forceLookAtOwner = true;  // 任务执行时关闭

    public AIPartnerEntity(World worldIn) {
        super(worldIn);
        this.setSize(0.6F, 1.8F);
        this.speakBudget = new SpeakBudget(AIFriendMod.speakBudgetMax);
    }

    // ===== 运行时绑定 =====
    public void setBrain(AIBrain brain) { this.brain = brain; }
    public AIBrain getBrain() { return this.brain; }
    public SpeakBudget getSpeakBudget() { return this.speakBudget; }
    public void resetSpeakBudget() { this.speakBudget.reset(); }
    public void setOwnerUUID(UUID uuid) { this.ownerUUID = uuid; }
    public UUID getOwnerUUID() { return this.ownerUUID; }
    public void setForceLookAtOwner(boolean enable) { this.forceLookAtOwner = enable; }
    public void markSpawnPos() {
        this.spawnX = this.posX; this.spawnY = this.posY; this.spawnZ = this.posZ;
    }
    public double getSpawnX() { return this.spawnX; }
    public double getSpawnY() { return this.spawnY; }
    public double getSpawnZ() { return this.spawnZ; }

    public EntityPlayer getOwnerPlayer() {
        if (this.ownerUUID != null) {
            for (EntityPlayer p : this.world.playerEntities) {
                if (p.getUniqueID().equals(this.ownerUUID)) return p;
            }
        }
        return this.world.getClosestPlayer(this, 64.0D);
    }

    public void onRespawn() {
        if (this.brain != null) this.brain.forceThink();
    }

    // ===== 属性 =====
    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        this.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(20.0D);
        this.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(0.32D);
        this.getEntityAttribute(SharedMonsterAttributes.FOLLOW_RANGE).setBaseValue(32.0D);
    }

    // 关闭原版怪物AI，全部交给 AIBrain 驱动
    @Override
    protected void initEntityAI() {
        this.tasks.clear();
        this.targetTasks.clear();
    }

    // ===== Tick =====
    @Override
    public void onLivingUpdate() {
        super.onLivingUpdate();
        if (this.world.isRemote) return;
        pickupItems();
        EntityPlayer owner = getOwnerPlayer();
        if (owner != null && forceLookAtOwner) {
            lookAt(owner.posX, owner.posY + owner.getEyeHeight(), owner.posZ);
        }
        if (this.brain != null) this.brain.onTick();
    }

    private void pickupItems() {
        AxisAlignedBB bb = this.getEntityBoundingBox().grow(2.0D);
        List<EntityItem> items = this.world.getEntitiesWithinAABB(EntityItem.class, bb, e -> true);
        for (EntityItem it : items) {
            ItemStack stack = it.getItem();
            if (stack.isEmpty()) continue;
            ItemStack remain = this.inventory.addItemStack(stack);
            if (remain.isEmpty()) it.setDead();
        }
    }

    // ===== IPartnerBody =====
    @Override
    public EntityPlayer getOwner() { return getOwnerPlayer(); }

    @Override
    public boolean isAlive() { return !this.isDead; }

    @Override
    public void mineBlock(BlockPos pos) {
        if (this.world.isRemote) return;
        this.world.destroyBlock(pos, true);
    }

    @Override
    public void walk(double dirX, double dirZ, boolean jump) {
        double yawRad = Math.toRadians(this.rotationYaw);
        double worldX = -Math.sin(yawRad) * dirZ - Math.cos(yawRad) * dirX;
        double worldZ = Math.cos(yawRad) * dirZ - Math.sin(yawRad) * dirX;
        double len = Math.sqrt(worldX * worldX + worldZ * worldZ);
        if (len > 0.001) { worldX /= len; worldZ /= len; }
        this.motionX = worldX * 0.32D;
        this.motionZ = worldZ * 0.32D;
        if (jump && this.onGround) this.jump();
    }

    @Override
    public float getRotationYaw() { return this.rotationYaw; }

    @Override
    public void setRotationYaw(float yaw) {
        this.rotationYaw = yaw;
        this.prevRotationYaw = yaw;
        this.rotationYawHead = yaw;
    }

    @Override
    public void lookAt(double x, double y, double z) {
        this.getLookHelper().setLookPosition(x, y, z, 20.0F, 20.0F);
    }

    @Override
    public void leftClick() {
        if (this.world.isRemote) return;
        Vec3d start = this.getPositionEyes(1.0F);
        Vec3d end = start.add(this.getLookVec().scale(1.5D));
        RayTraceResult trace = this.world.rayTraceBlocks(start, end, false, false, true);

        if (trace == null || trace.typeOfHit != RayTraceResult.Type.BLOCK) {
            List<EntityLivingBase> list = world.getEntitiesWithinAABB(EntityLivingBase.class,
                    new AxisAlignedBB(start.x, start.y, start.z, end.x, end.y, end.z).expand(0.3D));
            for (EntityLivingBase e : list) {
                if (e != this) { this.attackEntityAsMob(e); return; }
            }
            return;
        }
        this.world.destroyBlock(trace.getBlockPos(), true);
    }

    @Override
    public void rightClick() {
        if (this.world.isRemote) return;
        ItemStack held = getHeldItem();
        if (held.isEmpty()) return;
        Vec3d look = this.getLookVec();
        BlockPos pos = new BlockPos(
                this.posX + look.x * 1.5D,
                this.posY + this.getEyeHeight() + look.y * 1.5D,
                this.posZ + look.z * 1.5D);
        net.minecraft.block.Block b = net.minecraft.block.Block.getBlockFromItem(held.getItem());
        if (b != null) this.world.setBlockState(pos, b.getDefaultState());
    }

    @Override
    public void selectSlot(int slot) {
        if (slot < 1 || slot > 9) return;
        this.currentSlot = slot - 1;
    }

    @Override
    public InventoryBasic getInventory() { return this.inventory; }

    @Override
    public ItemStack getHeldItem() { return this.inventory.getStackInSlot(this.currentSlot); }

    // ===== NBT =====
    @Override
    public void writeEntityToNBT(NBTTagCompound compound) {
        super.writeEntityToNBT(compound);
        if (this.ownerUUID != null) compound.setString("ownerUUID", this.ownerUUID.toString());
        compound.setDouble("spawnX", this.spawnX);
        compound.setDouble("spawnY", this.spawnY);
        compound.setDouble("spawnZ", this.spawnZ);
        compound.setInteger("currentSlot", this.currentSlot);
        NBTTagList list = new NBTTagList();
        for (int i = 0; i < this.inventory.getSizeInventory(); i++) {
            ItemStack s = this.inventory.getStackInSlot(i);
            if (!s.isEmpty()) {
                NBTTagCompound tag = new NBTTagCompound();
                tag.setInteger("slot", i);
                s.writeToNBT(tag);
                list.appendTag(tag);
            }
        }
        compound.setTag("partnerInventory", list);
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound compound) {
        super.readEntityFromNBT(compound);
        if (compound.hasKey("ownerUUID")) {
            try { this.ownerUUID = UUID.fromString(compound.getString("ownerUUID")); }
            catch (Exception ignored) {}
        }
        this.spawnX = compound.getDouble("spawnX");
        this.spawnY = compound.getDouble("spawnY");
        this.spawnZ = compound.getDouble("spawnZ");
        this.currentSlot = compound.getInteger("currentSlot");
        NBTTagList list = compound.getTagList("partnerInventory", 10);
        for (int i = 0; i < list.tagCount(); i++) {
            NBTTagCompound tag = list.getCompoundTagAt(i);
            int slot = tag.getInteger("slot");
            ItemStack s = new ItemStack(tag);
            if (slot >= 0 && slot < this.inventory.getSizeInventory()) {
                this.inventory.setInventorySlotContents(slot, s);
            }
        }
    }
}