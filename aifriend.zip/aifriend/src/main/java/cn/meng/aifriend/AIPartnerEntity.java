package cn.meng.aifriend;

import net.minecraft.block.Block;
import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class AIPartnerEntity extends EntityCreature {

    private BlockPos targetPos = null;
    private Block targetBlock = null;
    private int taskType = 0;

    public AIPartnerEntity(World worldIn) {
        super(worldIn);
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        this.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(40.0D);
        this.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(0.35D);
        this.getEntityAttribute(SharedMonsterAttributes.FOLLOW_RANGE).setBaseValue(32.0D);
    }

    public void setTask(int type, BlockPos pos, Block block) {
        this.taskType = type;
        this.targetPos = pos;
        this.targetBlock = block;
    }

    @Override
    public void onLivingUpdate() {
        super.onLivingUpdate();
        if (this.world.isRemote) return;
        if (this.targetPos == null) return;

        double dist = this.getDistanceSq(this.targetPos.getX(), this.targetPos.getY(), this.targetPos.getZ());

        if (dist > 2.0D) {
            moveLikeHuman();
        } else {
            if (this.taskType == 1) {
                this.world.destroyBlock(this.targetPos, true);
            } else if (this.taskType == 2 && this.targetBlock != null) {
                this.world.setBlockState(this.targetPos, this.targetBlock.getDefaultState());
            }
            this.targetPos = null;
            this.taskType = 0;
            this.targetBlock = null;
            this.getNavigator().clearPath();
        }
    }

    private void moveLikeHuman() {
        double tx = this.targetPos.getX() + 0.5D;
        double ty = this.targetPos.getY();
        double tz = this.targetPos.getZ() + 0.5D;

        if (this.isInWater()) {
            this.motionY += 0.04D;
            this.getNavigator().tryMoveToXYZ(tx, ty, tz, 0.8D);
            return;
        }
        if (this.isOnLadder() && this.posY < this.targetPos.getY() - 0.5D && this.getNavigator().getPath() == null) {
            this.motionY = 0.18D;
            return;
        }
        this.getNavigator().tryMoveToXYZ(tx, ty, tz, 1.0D);
        if (this.onGround && this.collidedHorizontally && this.hasNoPath()) {
            this.jump();
        }
    }
}