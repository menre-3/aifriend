package cn.meng.aifriend;

import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.InventoryBasic;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.List;
import java.util.UUID;

public class AIPartnerEntity extends EntityCreature implements IPartnerBody {
    private final InventoryBasic inventory = new InventoryBasic("partner", false, 27);
    private int currentSlot = 0;              // 热栏 0‑8
    private AIBrain brain;
    private final SpeakBudget speakBudget;
    private UUID ownerUUID = null;            // 召唤它的玩家
    private double spawnX, spawnY, spawnZ;    // 召唤位置
    private boolean forceLookAtOwner = true;  // 是否强制看向主人，任务执行时关闭

    public AIPartnerEntity(World worldIn) {
        super(worldIn);
        this.setSize(0.6F, 1.8F);
        this.speakBudget = new SpeakBudget(AIFriendMod.speakBudgetMax);
    }

    // ===== 运行时绑定Brain（Brain为运行时对象，不写入NBT，世界加载后外部重新setBrain） =====
    public void setBrain(AIBrain brain) {
        this.brain = brain;
    }

    public AIBrain getBrain() {
        return this.brain;
    }

    public SpeakBudget getSpeakBudget() {
        return this.speakBudget;
    }

    public void resetSpeakBudget() {
        this.speakBudget.reset();
    }

    public void setOwnerUUID(UUID uuid) {
        this.ownerUUID = uuid;
    }

    public UUID getOwnerUUID() {
        return this.ownerUUID;
    }

    public void setForceLookAtOwner(boolean enable) {
        this.forceLookAtOwner = enable;
    }

    public void markSpawnPos() {
        this.spawnX = this.posX;
        this.spawnY = this.posY;
        this.spawnZ = this.posZ;
    }

    public double getSpawnX() {
        return this.spawnX;
    }

    public double getSpawnY() {
        return this.spawnY;
    }

    public double getSpawnZ() {
        return this.spawnZ;
    }

    /**
     * 获取主人：优先ownerUUID匹配；离线/找不到则回退64格内最近玩家
     */
    public EntityPlayer getOwnerPlayer() {
        if (this.ownerUUID != null) {
            for (EntityPlayer p : this.world.playerEntities) {
                if (p.getUniqueID().equals(this.ownerUUID)) {
                    return p;
                }
            }
        }
        // Forge1.12.2正确API：x,y,z,距离,ignoreSpectator
        return this.world.getClosestPlayer(this.posX, this.posY, this.posZ, 64.0D, false);
    }

    /**
     * 伙伴重生后调用，恢复AI思考
     */
    public void onRespawn() {
        if (this.brain != null) {
            this.brain.forceThink();
        }
    }

    // ===== 属性初始化 =====
    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        this.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(20.0D); //10心
        this.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(0.32D);
        this.getEntityAttribute(SharedMonsterAttributes.FOLLOW_RANGE).setBaseValue(32.0D);
    }

    // 关闭原版怪物AI，全部交给AIBrain外部驱动（1.12.2正确写法）
    @Override
    protected void initEntityAI() {
        this.tasks.taskEntries.clear();
        this.targetTasks.taskEntries.clear();
    }

    // ===== Tick主循环 =====
    @Override
    public void onLivingUpdate() {
        super.onLivingUpdate();
        if (this.world.isRemote) {
            return;
        }
        pickupItems();
        EntityPlayer owner = getOwnerPlayer();
        if (owner != null && forceLookAtOwner) {
            lookAt(owner.posX, owner.posY + owner.getEyeHeight(), owner.posZ);
        }
        if (this.brain != null) {
            this.brain.onTick();
        }
    }

    /**
     * 将物品尝试存入背包，返回剩余未收纳物品
     */
    private ItemStack tryStoreItem(ItemStack stack) {
        if(stack.isEmpty()) return stack;
        ItemStack copy = stack.copy();
        for(int i = 0; i < inventory.getSizeInventory(); i++) {
            if(copy.isEmpty()) break;
            ItemStack slot = inventory.getStackInSlot(i);
            if(slot.isEmpty()) {
                inventory.setInventorySlotContents(i, copy);
                return ItemStack.EMPTY;
            }
            if(ItemStack.areItemsEqual(copy, slot) && slot.getCount() < slot.getMaxStackSize()) {
                int canAdd = slot.getMaxStackSize() - slot.getCount();
                int add = Math.min(canAdd, copy.getCount());
                slot.grow(add);
                copy.shrink(add);
            }
        }
        return copy;
    }

    /**
     * 自动拾取2格范围内掉落物；备注：多伙伴场景会发生抢夺，为本版已知局限
     */
    private void pickupItems() {
        AxisAlignedBB bb = this.getEntityBoundingBox().grow(2.0D,2.0D,2.0D);
        List<EntityItem> items = this.world.getEntitiesWithinAABB(EntityItem.class, bb, e -> true);
        for (EntityItem it : items) {
            ItemStack stack = it.getItem();
            if (stack.isEmpty()) {
                continue;
            }
            ItemStack remain = tryStoreItem(stack);
            if (remain.isEmpty()) {
                it.setDead();
            }
        }
    }

    // ===== IPartnerBody 接口实现 =====
    @Override
    public void walk(double dirX, double dirZ, boolean jump) {
        // dirX = 本体向右；dirZ = 本体向前；入参仅允许 -1,0,1 方向值
        double yawRad = Math.toRadians(this.rotationYaw);
        double worldX = -Math.sin(yawRad) * dirZ - Math.cos(yawRad) * dirX;
        double worldZ = Math.cos(yawRad) * dirZ - Math.sin(yawRad) * dirX;

        double len = Math.sqrt(worldX * worldX + worldZ * worldZ);
        if (len > 0.001) {
            worldX /= len;
            worldZ /= len;
        }
        this.motionX = worldX * 0.32D;
        this.motionZ = worldZ * 0.32D;
        if (jump && this.onGround) {
            this.jump();
        }
    }

    @Override
    public float getRotationYaw() {
        return this.rotationYaw;
    }

    @Override
    public void setRotationYaw(float yaw) {
        this.rotationYaw = yaw;
        this.prevRotationYaw = yaw;
        this.rotationYawHead = yaw;
    }

    /**
     * 看向指定世界坐标（支持看方块/实体）
     */
    @Override
    public void lookAt(double x, double y, double z) {
        this.getLookHelper().setLookPosition(x, y, z, 20.0F, 20.0F);
    }

    @Override
    public void leftClick() {
        if (this.world.isRemote) {
            return;
        }
        // 1.5米射线追踪，真实碰撞检测
        Vec3d start = this.getPositionEyes(1.0F);
        Vec3d end = start.add(this.getLookVec().scale(1.5D));
        RayTraceResult trace = this.world.rayTraceBlocks(start, end, false, false, true);

        // 没有击中方块，尝试检测实体
        if (trace == null || trace.typeOfHit != RayTraceResult.Type.BLOCK) {
            AxisAlignedBB aabb = new AxisAlignedBB(start.x, start.y, start.z, end.x, end.y, end.z).expand(0.3D,0.3D,0.3D);
            List<EntityLivingBase> list = world.getEntitiesWithinAABB(EntityLivingBase.class, aabb);
            for (EntityLivingBase e : list) {
                if (e != this) {
                    this.attackEntityAsMob(e);
                    return;
                }
            }
            return;
        }
        // 击中方块，执行破坏
        BlockPos hitPos = trace.getBlockPos();
        this.world.destroyBlock(hitPos, true);
    }

    @Override
    public void rightClick() {
        if (this.world.isRemote) {
            return;
        }
        Vec3d start = this.getPositionEyes(1.0F);
        Vec3d end = start.add(this.getLookVec().scale(1.5D));
        RayTraceResult trace = this.world.rayTraceBlocks(start, end, false, false, true);
        if (trace == null || trace.typeOfHit != RayTraceResult.Type.BLOCK) {
            return;
        }
        BlockPos hitPos = trace.getBlockPos();
        // 使用原版方块交互逻辑，打开箱子/熔炉/放置方块全部原生支持
        this.getHeldItem().useItemOnBlock(this, world, hitPos, EnumHand.MAIN_HAND);
    }

    @Override
    public void selectSlot(int slot) {
        if (slot < 1 || slot > 9) {
            return;
        }
        this.currentSlot = slot - 1;
    }

    @Override
    public InventoryBasic getInventory() {
        return this.inventory;
    }

    @Override
    public ItemStack getHeldItem() {
        return this.inventory.getStackInSlot(this.currentSlot);
    }

    // ===== NBT持久化（Brain运行时对象，不序列化） =====
    @Override
    public void writeEntityToNBT(NBTTagCompound compound) {
        super.writeEntityToNBT(compound);
        if (this.ownerUUID != null) {
            compound.setString("ownerUUID", this.ownerUUID.toString());
        }
        compound.setDouble("spawnX", this.spawnX);
        compound.setDouble("spawnY", this.spawnY);
        compound.setDouble("spawnZ", this.spawnZ);
        compound.setInteger("currentSlot", this.currentSlot);

        NBTTagList list = new NBTTagList();
        for (int i = 0; i < this.inventory.getSizeInventory(); i++) {
            ItemStack s = this.inventory.getStackInSlot(i);
            if (!s.isEmpty()) {
                NBTTagCompound tag = new NBTTagCompound();
                tag.setInteger("slot", i);
                s.writeToNBT(tag);
                list.appendTag(tag);
            }
        }
        compound.setTag("partnerInventory", list);
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound compound) {
        super.readEntityFromNBT(compound);
        if (compound.hasKey("ownerUUID")) {
            try {
                this.ownerUUID = UUID.fromString(compound.getString("ownerUUID"));
            } catch (Exception ignored) {
            }
        }
        this.spawnX = compound.getDouble("spawnX");
        this.spawnY = compound.getDouble("spawnY");
        this.spawnZ = compound.getDouble("spawnZ");
        this.currentSlot = compound.getInteger("currentSlot");

        NBTTagList list = compound.getTagList("partnerInventory", 10);
        for (int i = 0; i < list.tagCount(); i++) {
            NBTTagCompound tag = list.getCompoundTagAt(i);
            int slot = tag.getInteger("slot");
            ItemStack s = new ItemStack(tag);
            if (slot >= 0 && slot < this.inventory.getSizeInventory()) {
                this.inventory.setInventorySlotContents(slot, s);
            }
        }
    }
}
