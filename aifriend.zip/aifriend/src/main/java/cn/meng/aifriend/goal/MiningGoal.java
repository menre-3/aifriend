package cn.meng.aifriend.goal;

import cn.meng.aifriend.api.IPartnerBody;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

/**
 * 挖矿目标
 */
public class MiningGoal implements IGoal {

    private boolean active = false;
    private BlockPos targetOre;
    private int stuckTimer = 0;

    private static final List<Block> ORE_BLOCKS = new ArrayList<>();
    static {
        ORE_BLOCKS.add(Blocks.COAL_ORE);
        ORE_BLOCKS.add(Blocks.IRON_ORE);
        ORE_BLOCKS.add(Blocks.GOLD_ORE);
        ORE_BLOCKS.add(Blocks.DIAMOND_ORE);
        ORE_BLOCKS.add(Blocks.REDSTONE_ORE);
        ORE_BLOCKS.add(Blocks.LAPIS_ORE);
        ORE_BLOCKS.add(Blocks.EMERALD_ORE);
    }

    @Override public String getName() { return "挖矿"; }
    @Override public int getPriority() { return 40; }
    @Override public boolean isActive() { return active; }

    @Override
    public boolean shouldStart(IPartnerBody body) {
        if (active) return false;
        return findNearbyOre(body) != null;
    }

    @Override
    public void start(IPartnerBody body) {
        active = true;
        targetOre = findNearbyOre(body);
        stuckTimer = 0;
    }

    @Override
    public boolean update(IPartnerBody body) {
        if (targetOre == null || body.getWorldObject().isAirBlock(targetOre)) {
            targetOre = findNearbyOre(body);
            if (targetOre == null) return false;
        }
        double dist = body.getPositionVec().distanceTo(new Vec3d(targetOre.getX() + 0.5, targetOre.getY(), targetOre.getZ() + 0.5));
        if (dist > 4) {
            body.getMovement().moveTo(targetOre, 1.0);
            stuckTimer++;
            if (stuckTimer > 100) return false;
        } else {
            stuckTimer = 0;
            body.getInteraction().mineBlock(targetOre);
            if (!body.getInteraction().isMiningNow()) targetOre = null;
        }
        return true;
    }

    @Override
    public void stop(IPartnerBody body) {
        active = false;
        targetOre = null;
        body.getMovement().stopMoving();
    }

    @Override
    public String getDescription() {
        return targetOre != null ? "挖掘 (" + targetOre.getX() + "," + targetOre.getY() + "," + targetOre.getZ() + ")" : "寻找矿石";
    }

    private BlockPos findNearbyOre(IPartnerBody body) {
        Vec3d pos = body.getPositionVec();
        BlockPos center = new BlockPos(pos);
        BlockPos nearest = null;
        double nearestDist = Double.MAX_VALUE;
        for (int dx = -8; dx <= 8; dx++) {
            for (int dy = -8; dy <= 8; dy++) {
                for (int dz = -8; dz <= 8; dz++) {
                    BlockPos p = center.add(dx, dy, dz);
                    if (!body.getWorldObject().isBlockLoaded(p)) continue;
                    IBlockState state = body.getWorldObject().getBlockState(p);
                    if (ORE_BLOCKS.contains(state.getBlock())) {
                        double d = p.distanceSq(center);
                        if (d < nearestDist) { nearestDist = d; nearest = p; }
                    }
                }
            }
        }
        return nearest;
    }
}
