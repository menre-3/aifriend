package com.aifriend.goal;

import com.aifriend.api.IPartnerBody;
import com.aifriend.info.EnvironmentInfo;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

/**
 * 挖矿目标
 * 寻找附近的矿石并挖掘
 *
 * 行为：
 * 1. 扫描周围寻找矿石（煤矿、铁矿、金矿、钻石等）
 * 2. 移动到矿石旁边
 * 3. 挖掘矿石
 * 4. 拾取掉落物
 * 5. 继续寻找下一个
 */
public class MiningGoal implements IGoal {

    private final EnvironmentInfo environment;
    private boolean active = false;
    private BlockPos targetOre;
    private int searchCooldown = 0;
    private int stuckTimer = 0;

    // 可挖掘的矿石列表
    private static final List<Block> ORE_BLOCKS = new ArrayList<>();
    static {
        ORE_BLOCKS.add(Blocks.COAL_ORE);
        ORE_BLOCKS.add(Blocks.IRON_ORE);
        ORE_BLOCKS.add(Blocks.GOLD_ORE);
        ORE_BLOCKS.add(Blocks.DIAMOND_ORE);
        ORE_BLOCKS.add(Blocks.REDSTONE_ORE);
        ORE_BLOCKS.add(Blocks.LAPIS_ORE);
        ORE_BLOCKS.add(Blocks.EMERALD_ORE);
        ORE_BLOCKS.add(Blocks.QUARTZ_ORE);
    }

    public MiningGoal(EnvironmentInfo environment) {
        this.environment = environment;
    }

    @Override
    public String getName() { return "挖矿"; }

    @Override
    public int getPriority() { return 40; } // 工作级优先级

    @Override
    public boolean shouldStart(IPartnerBody body) {
        if (active) return false;
        // 有指令或战斗时不挖矿
        return findNearbyOre(body) != null;
    }

    @Override
    public void start(IPartnerBody body) {
        active = true;
        targetOre = findNearbyOre(body);
        stuckTimer = 0;
    }

    @Override
    public boolean update(IPartnerBody body) {
        if (targetOre == null || body.getWorld().isAirBlock(targetOre)) {
            // 目标消失，找下一个
            targetOre = findNearbyOre(body);
            if (targetOre == null) {
                return false; // 没有矿石了，目标结束
            }
        }

        double dist = body.getPositionVec().distanceTo(
                new Vec3d(targetOre.getX() + 0.5, targetOre.getY(), targetOre.getZ() + 0.5));

        if (dist > 4) {
            // 移动过去
            body.getMovement().moveTo(targetOre, 1.0);
            stuckTimer++;
            if (stuckTimer > 100) {
                // 卡住了，放弃这个目标
                return false;
            }
        } else {
            // 开始挖
            stuckTimer = 0;
            body.getInteraction().mineBlock(targetOre);
            // 挖掘需要时间，等待
            if (!body.getInteraction().isMining()) {
                // 挖完了，找下一个
                targetOre = null;
            }
        }
        return true;
    }

    @Override
    public void stop(IPartnerBody body) {
        active = false;
        targetOre = null;
        body.getMovement().stop();
    }

    @Override
    public boolean isActive() { return active; }

    @Override
    public String getDescription() {
        if (targetOre != null) {
            return "正在挖掘 (" + targetOre.getX() + "," + targetOre.getY() + "," + targetOre.getZ() + ") 的矿石";
        }
        return "寻找矿石中";
    }

    /**
     * 搜索附近的矿石
     */
    private BlockPos findNearbyOre(IPartnerBody body) {
        Vec3d pos = body.getPositionVec();
        int range = 8;
        BlockPos center = new BlockPos(pos);
        BlockPos nearest = null;
        double nearestDist = Double.MAX_VALUE;

        for (int dx = -range; dx <= range; dx++) {
            for (int dy = -range; dy <= range; dy++) {
                for (int dz = -range; dz <= range; dz++) {
                    BlockPos checkPos = center.add(dx, dy, dz);
                    if (!body.getWorld().isBlockLoaded(checkPos)) continue;
                    IBlockState state = body.getWorld().getBlockState(checkPos);
                    if (ORE_BLOCKS.contains(state.getBlock())) {
                        double dist = checkPos.distanceSq(center);
                        if (dist < nearestDist) {
                            nearestDist = dist;
                            nearest = checkPos;
                        }
                    }
                }
            }
        }
        return nearest;
    }
}
