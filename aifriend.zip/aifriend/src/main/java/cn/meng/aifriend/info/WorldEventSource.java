package com.aifriend.info;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.AchievementEvent;
import net.minecraftforge.event.entity.player.EntityItemPickupEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * 世界事件源（眼睛的一部分）
 * 监听"玩家可见"的世界事件：死亡、成就、拾取物品、玩家受伤等
 * 事件被缓存为文本描述，供AI大脑读取并做出反应
 */
public class WorldEventSource {

    // 事件队列（线程安全）
    private final ConcurrentLinkedQueue<WorldEvent> eventQueue = new ConcurrentLinkedQueue<>();
    // 最大缓存事件数
    private static final int MAX_CACHED = 50;

    /**
     * 取出并清空所有待处理事件
     */
    public List<WorldEvent> drainEvents() {
        if (eventQueue.isEmpty()) {
            return Collections.emptyList();
        }
        List<WorldEvent> events = new ArrayList<>();
        WorldEvent e;
        while ((e = eventQueue.poll()) != null) {
            events.add(e);
        }
        return events;
    }

    /**
     * 查看最近的事件（不清除）
     */
    public List<WorldEvent> peekRecent(int count) {
        List<WorldEvent> all = new ArrayList<>(eventQueue);
        if (all.size() <= count) return all;
        return all.subList(all.size() - count, all.size());
    }

    /**
     * 是否有待处理事件
     */
    public boolean hasEvents() {
        return !eventQueue.isEmpty();
    }

    private void addEvent(WorldEvent event) {
        eventQueue.offer(event);
        // 限制队列大小
        while (eventQueue.size() > MAX_CACHED) {
            eventQueue.poll();
        }
    }

    // ===== Forge 事件订阅 =====

    @SubscribeEvent
    public void onLivingDeath(LivingDeathEvent event) {
        if (event.getEntityLiving() instanceof EntityPlayer) {
            EntityPlayer player = (EntityPlayer) event.getEntityLiving();
            String cause = event.getSource().getDeathMessage(player).getUnformattedText();
            addEvent(new WorldEvent(WorldEventType.DEATH,
                    player.getName() + " 死亡了：" + cause,
                    System.currentTimeMillis()));
        } else {
            // 生物死亡（可能是被玩家杀死的）
            if (event.getSource().getTrueSource() instanceof EntityPlayer) {
                EntityPlayer killer = (EntityPlayer) event.getSource().getTrueSource();
                addEvent(new WorldEvent(WorldEventType.KILL,
                        killer.getName() + " 杀死了 " + event.getEntityLiving().getName(),
                        System.currentTimeMillis()));
            }
        }
    }

    @SubscribeEvent
    public void onAchievement(AchievementEvent event) {
        EntityPlayer player = event.getEntityPlayer();
        addEvent(new WorldEvent(WorldEventType.ACHIEVEMENT,
                player.getName() + " 获得了成就：" + event.getAchievement().getStatName().getUnformattedText(),
                System.currentTimeMillis()));
    }

    @SubscribeEvent
    public void onItemPickup(EntityItemPickupEvent event) {
        EntityPlayer player = event.getEntityPlayer();
        String itemName = event.getItem().getItem().getDisplayName();
        addEvent(new WorldEvent(WorldEventType.PICKUP,
                player.getName() + " 拾取了 " + itemName,
                System.currentTimeMillis()));
    }

    @SubscribeEvent
    public void onPlayerHurt(PlayerEvent event) {
        // PlayerEvent 基类不包含受伤信息，这里用 LivingHurtEvent 更合适
        // 但为了简化，我们在单独的方法中处理
    }

    /**
     * 玩家受伤事件（由外部调用或单独订阅）
     */
    public void onPlayerHurt(EntityPlayer player, float amount, String source) {
        addEvent(new WorldEvent(WorldEventType.HURT,
                player.getName() + " 受到了 " + amount + " 点伤害（来源：" + source + "）",
                System.currentTimeMillis()));
    }

    /**
     * 玩家蹲起事件（连续蹲起检测由 StateObserver 处理，这里只记录单次）
     */
    public void onPlayerSneak(EntityPlayer player) {
        addEvent(new WorldEvent(WorldEventType.SNEAK,
                player.getName() + " 蹲了一下",
                System.currentTimeMillis()));
    }

    /**
     * 生成事件摘要文本
     */
    public String buildSummary() {
        List<WorldEvent> events = peekRecent(5);
        if (events.isEmpty()) return "";
        StringBuilder sb = new StringBuilder("【近期事件】\n");
        for (WorldEvent e : events) {
            sb.append("- ").append(e.description).append("\n");
        }
        return sb.toString();
    }

    // ===== 数据结构 =====

    public enum WorldEventType {
        DEATH,        // 玩家死亡
        KILL,         // 玩家杀死生物
        ACHIEVEMENT,  // 获得成就
        PICKUP,       // 拾取物品
        HURT,         // 玩家受伤
        SNEAK,        // 玩家蹲起
        CHAT,         // 玩家聊天
        OTHER         // 其他
    }

    public static class WorldEvent {
        public final WorldEventType type;
        public final String description;
        public final long timestamp;

        public WorldEvent(WorldEventType type, String description, long timestamp) {
            this.type = type;
            this.description = description;
            this.timestamp = timestamp;
        }
    }
}
