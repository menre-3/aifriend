package cn.meng.aifriend.info;

import cn.meng.aifriend.AIFriendMod;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.event.entity.player.AdvancementEvent;
import net.minecraftforge.event.entity.player.PlayerDeathEvent;
import net.minecraftforge.event.entity.player.PlayerPickupXpEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * 世界事件源
 * 注意：1.12.2没有AchievementEvent，使用AdvancementEvent（进度系统）
 */
@Mod.EventBusSubscriber(modid = AIFriendMod.MOD_ID)
public class WorldEventSource {

    private static final ConcurrentLinkedQueue<WorldEvent> eventQueue = new ConcurrentLinkedQueue<>();
    private static final int MAX_CACHED = 50;

    public static List<WorldEvent> drainEvents() {
        if (eventQueue.isEmpty()) return Collections.emptyList();
        List<WorldEvent> events = new ArrayList<>();
        WorldEvent e;
        while ((e = eventQueue.poll()) != null) events.add(e);
        return events;
    }

    public static boolean hasEvents() {
        return !eventQueue.isEmpty();
    }

    private static void addEvent(WorldEvent event) {
        eventQueue.offer(event);
        while (eventQueue.size() > MAX_CACHED) eventQueue.poll();
    }

    @SubscribeEvent
    public static void onAdvancement(AdvancementEvent event) {
        EntityPlayer player = event.getEntityPlayer();
        if (player == null || player.world.isRemote) return;
        String advId = event.getAdvancement() != null ? event.getAdvancement().getId().toString() : "unknown";
        addEvent(new WorldEvent(WorldEventType.ACHIEVEMENT,
                player.getName() + " 解锁了进度：" + advId,
                System.currentTimeMillis()));
    }

    @SubscribeEvent
    public static void onPlayerDeath(PlayerDeathEvent event) {
        EntityPlayer player = event.getEntityPlayer();
        if (player == null || player.world.isRemote) return;
        String msg = event.getDeathMessage() != null ? event.getDeathMessage().getUnformattedText() : "死亡";
        addEvent(new WorldEvent(WorldEventType.DEATH,
                player.getName() + " 死亡了：" + msg,
                System.currentTimeMillis()));
    }

    @SubscribeEvent
    public static void onPickupXp(PlayerPickupXpEvent event) {
        EntityPlayer player = event.getEntityPlayer();
        if (player == null || player.world.isRemote) return;
        addEvent(new WorldEvent(WorldEventType.PICKUP,
                player.getName() + " 拾取了 " + event.getXp() + " 经验",
                System.currentTimeMillis()));
    }

    public static void onPlayerHurt(EntityPlayer player, float amount, String source) {
        addEvent(new WorldEvent(WorldEventType.HURT,
                player.getName() + " 受到 " + amount + " 点伤害（" + source + "）",
                System.currentTimeMillis()));
    }

    public static String buildSummary() {
        if (eventQueue.isEmpty()) return "";
        StringBuilder sb = new StringBuilder("【近期事件】\n");
        List<WorldEvent> all = new ArrayList<>(eventQueue);
        for (int i = Math.max(0, all.size() - 5); i < all.size(); i++) {
            sb.append("- ").append(all.get(i).description).append("\n");
        }
        return sb.toString();
    }

    public enum WorldEventType {
        DEATH, ACHIEVEMENT, PICKUP, HURT, SNEAK, CHAT, OTHER
    }

    public static class WorldEvent {
        public final WorldEventType type;
        public final String description;
        public final long timestamp;

        public WorldEvent(WorldEventType type, String description, long timestamp) {
            this.type = type;
            this.description = description;
            this.timestamp = timestamp;
        }
    }
}
