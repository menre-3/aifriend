package cn.meng.aifriend;

import net.minecraft.inventory.InventoryBasic;
import net.minecraft.item.ItemStack;

public interface IPartnerInventory {
    /**
     * 获取伙伴27格存储背包（不含原版玩家盔甲栏，仅物品存储）
     * 注意：0-8号槽同时作为热栏，由selectSlot()切换主手显示
     */
    InventoryBasic getInventory();

    /**
     * 获取伙伴当前主手手持物品（由热栏选中槽位决定）
     * @return 主手ItemStack，可为ItemStack.EMPTY
     */
    ItemStack getHeldItem();
}