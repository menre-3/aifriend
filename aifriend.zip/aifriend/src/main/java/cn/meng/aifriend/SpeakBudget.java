package cn.meng.aifriend;

/**
 * 主动发言预算：每个伙伴实例独立计数。
 * 只统计主动发言；玩家定向消息重置；API 失败不消耗。
 */
public class SpeakBudget {

    private int budget;
    private final int max;

    public SpeakBudget(int max) {
        this.max = Math.max(1, max); // 防护：<=0 钳到1
        this.budget = this.max;
    }

    /** 是否还能主动发言 */
    public synchronized boolean canSpeak() {
        return this.budget > 0;
    }

    /** 消耗一次发言额度；成功返回 true（额度不足返回 false，不消耗） */
    public synchronized boolean consume() {
        if (this.budget <= 0) return false;
        this.budget--;
        return true;
    }

    /** 玩家定向消息触发，重置预算 */
    public synchronized void reset() {
        this.budget = this.max;
    }
}