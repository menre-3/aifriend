package cn.meng.aifriend;

import net.minecraftforge.common.config.Configuration;
import org.apache.logging.log4j.Logger;

import java.io.File;

/**
 * AI Friend 配置类
 * 探测范围 detectRange 默认24格，可配置4-128
 * 注意：Minecraft AABB查询即使设12格也常返回20+实体
 */
public class AIFriendConfig {

    private final File configFile;
    private Configuration configuration;
    private Logger logger;

    // API
    public String apiEndpoint = "http://127.0.0.1:8080/v1";
    public String apiKey = "sk-placeholder";
    public String model = "gpt-4o-mini";
    public int apiTimeoutMs = 30000;
    public int apiMaxRetries = 2;

    // 人设
    public String partnerName = "小伴";
    public String partnerPersona = "性格活泼开朗，是玩家在Minecraft里的好朋友";
    public String partnerSkin = "";

    // 环境探测
    public int detectRange = 24;
    public int maxEntitiesPerScan = 30;
    public int scanIntervalTicks = 20;

    // 对话记忆
    public int memoryMaxTurns = 16;
    public int speakBudgetMax = 8;
    public int dialogueHistorySize = 50;

    // 行为
    public double followDistance = 3.0;
    public int combatDetectRange = 16;
    public int decisionIntervalTicks = 40;

    // 自我成长
    public boolean enableSelfImprove = true;
    public int selfImproveIntervalTicks = 600;

    public AIFriendConfig(File configFile) {
        this.configFile = configFile;
    }

    public void setLogger(Logger logger) {
        this.logger = logger;
    }

    public void load() {
        configuration = new Configuration(configFile);
        configuration.load();
        syncFromConfig();
        if (configuration.hasChanged()) {
            configuration.save();
        }
    }

    private void syncFromConfig() {
        apiEndpoint = configuration.getString("apiEndpoint", "api", apiEndpoint, "OpenAI兼容API地址");
        apiKey = configuration.getString("apiKey", "api", apiKey, "API密钥");
        model = configuration.getString("model", "api", model, "模型名称");
        apiTimeoutMs = configuration.getInt("apiTimeoutMs", "api", apiTimeoutMs, 1000, 120000, "超时(毫秒)");
        apiMaxRetries = configuration.getInt("apiMaxRetries", "api", apiMaxRetries, 0, 10, "重试次数");

        partnerName = configuration.getString("partnerName", "persona", partnerName, "伙伴名字");
        partnerPersona = configuration.getString("partnerPersona", "persona", partnerPersona, "性格人设");
        partnerSkin = configuration.getString("partnerSkin", "persona", partnerSkin, "皮肤资源路径");

        detectRange = configuration.getInt("detectRange", "detection", detectRange, 4, 128,
                "探测范围(格)。注意AABB查询返回实体数常远超此值，默认24");
        maxEntitiesPerScan = configuration.getInt("maxEntitiesPerScan", "detection", maxEntitiesPerScan, 5, 200,
                "单次扫描最大实体数");
        scanIntervalTicks = configuration.getInt("scanIntervalTicks", "detection", scanIntervalTicks, 5, 200,
                "扫描间隔(tick)");

        memoryMaxTurns = configuration.getInt("memoryMaxTurns", "memory", memoryMaxTurns, 2, 100, "记忆轮数");
        speakBudgetMax = configuration.getInt("speakBudgetMax", "memory", speakBudgetMax, 0, 50, "每日发言预算");
        dialogueHistorySize = configuration.getInt("dialogueHistorySize", "memory", dialogueHistorySize, 10, 500, "对话历史条数");

        followDistance = configuration.getFloat("followDistance", "behavior", (float) followDistance, 1.0f, 20.0f, "跟随距离");
        combatDetectRange = configuration.getInt("combatDetectRange", "behavior", combatDetectRange, 4, 64, "战斗检测范围");
        decisionIntervalTicks = configuration.getInt("decisionIntervalTicks", "behavior", decisionIntervalTicks, 10, 200, "决策间隔(tick)");

        enableSelfImprove = configuration.getBoolean("enableSelfImprove", "growth", enableSelfImprove, "启用自我提升");
        selfImproveIntervalTicks = configuration.getInt("selfImproveIntervalTicks", "growth", selfImproveIntervalTicks, 100, 6000, "自我提升间隔(tick)");
    }

    public void save() {
        if (configuration != null && configuration.hasChanged()) {
            configuration.save();
        }
    }

    public void setDetectRange(int range) {
        this.detectRange = Math.max(4, Math.min(128, range));
    }
}
