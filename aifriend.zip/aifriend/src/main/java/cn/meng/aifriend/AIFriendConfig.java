package com.aifriend;

import net.minecraftforge.common.config.Configuration;
import org.apache.logging.log4j.Logger;

import java.io.File;

/**
 * AI Friend 模组配置类
 * 所有可调参数集中在此，通过 config/aifriend.cfg 配置文件修改
 *
 * 特别说明：环境探测范围 detectRange
 *   原版 Minecraft 中实体的跟踪范围(trackingRange)虽设为12，
 *   但实际 getEntitiesWithinAABB 等查询在12格内往往返回20+个实体，
 *   因为范围是立方体/球体且包含各种生物、掉落物、方块实体等。
 *   因此本模组将探测范围独立配置，默认24格，可按需调大或调小。
 */
public class AIFriendConfig {

    private final File configFile;
    private Configuration configuration;

    // ===== API 配置 =====
    private String apiEndpoint = "http://127.0.0.1:8080/v1";
    private String apiKey = "sk-placeholder";
    private String model = "gpt-4o-mini";
    private int apiTimeoutMs = 30000;
    private int apiMaxRetries = 2;

    // ===== 伙伴人设 =====
    private String partnerName = "小伴";
    private String partnerPersona = "性格活泼开朗，是玩家在Minecraft里的好朋友，会关心玩家、会开玩笑、会主动帮忙";
    private String partnerSkin = "default"; // 玩家皮肤用户名或URL

    // ===== 环境探测 =====
    // 探测范围（格），默认24，可配置。注意：实际返回实体数可能远超范围数值
    private int detectRange = 24;
    // 单次感知返回的最大实体数（防止上下文爆炸）
    private int maxEntitiesPerScan = 30;
    // 扫描间隔（tick），20tick=1秒
    private int scanIntervalTicks = 20;

    // ===== 对话/记忆 =====
    private int memoryMaxTurns = 16;
    // 主动发言预算（每游戏日最多几句）
    private int speakBudgetMax = 8;
    // 对话历史保留条数
    private int dialogueHistorySize = 50;

    // ===== 行为 =====
    // 默认跟随距离
    private double followDistance = 3.0;
    // 战斗检测范围
    private int combatDetectRange = 16;
    // AI决策间隔（tick）
    private int decisionIntervalTicks = 40;

    // ===== 自我成长 =====
    private boolean enableSelfImprove = true;
    // 自我提升检查间隔（tick）
    private int selfImproveIntervalTicks = 600;

    public AIFriendConfig(File configFile) {
        this.configFile = configFile;
    }

    public void load() {
        configuration = new Configuration(configFile);
        configuration.load();
        syncFromConfig();
        if (configuration.hasChanged()) {
            configuration.save();
        }
    }

    private void syncFromConfig() {
        // API
        apiEndpoint = configuration.getString("apiEndpoint", "api", apiEndpoint,
                "OpenAI兼容API地址，例如 http://127.0.0.1:8080/v1");
        apiKey = configuration.getString("apiKey", "api", apiKey, "API密钥");
        model = configuration.getString("model", "api", model, "使用的模型名称");
        apiTimeoutMs = configuration.getInt("apiTimeoutMs", "api", apiTimeoutMs, 1000, 120000, "API请求超时(毫秒)");
        apiMaxRetries = configuration.getInt("apiMaxRetries", "api", apiMaxRetries, 0, 10, "API请求失败最大重试次数");

        // 人设
        partnerName = configuration.getString("partnerName", "persona", partnerName, "AI伙伴的名字");
        partnerPersona = configuration.getString("partnerPersona", "persona", partnerPersona, "AI伙伴的性格人设描述");
        partnerSkin = configuration.getString("partnerSkin", "persona", partnerSkin, "皮肤(玩家名或URL)");

        // 环境探测
        detectRange = configuration.getInt("detectRange", "detection", detectRange, 4, 128,
                "环境探测范围(格)。注意：实际查询返回的实体数通常远超此数值，因为范围内包含生物/掉落物/方块实体等。默认24，可按需调整。");
        maxEntitiesPerScan = configuration.getInt("maxEntitiesPerScan", "detection", maxEntitiesPerScan, 5, 200,
                "单次感知最多返回的实体数量，防止上下文过长");
        scanIntervalTicks = configuration.getInt("scanIntervalTicks", "detection", scanIntervalTicks, 5, 200,
                "环境扫描间隔(tick)，20=1秒");

        // 对话记忆
        memoryMaxTurns = configuration.getInt("memoryMaxTurns", "memory", memoryMaxTurns, 2, 100,
                "对话记忆保留的最大轮数");
        speakBudgetMax = configuration.getInt("speakBudgetMax", "memory", speakBudgetMax, 0, 50,
                "每游戏日主动发言预算上限");
        dialogueHistorySize = configuration.getInt("dialogueHistorySize", "memory", dialogueHistorySize, 10, 500,
                "对话历史保留条数");

        // 行为
        followDistance = configuration.getFloat("followDistance", "behavior", (float) followDistance, 1.0f, 20.0f,
                "默认跟随距离(格)");
        combatDetectRange = configuration.getInt("combatDetectRange", "behavior", combatDetectRange, 4, 64,
                "战斗敌对生物检测范围(格)");
        decisionIntervalTicks = configuration.getInt("decisionIntervalTicks", "behavior", decisionIntervalTicks, 10, 200,
                "AI决策间隔(tick)");

        // 自我成长
        enableSelfImprove = configuration.getBoolean("enableSelfImprove", "growth", enableSelfImprove,
                "是否启用自我提升(收集/装备/防御)");
        selfImproveIntervalTicks = configuration.getInt("selfImproveIntervalTicks", "growth", selfImproveIntervalTicks, 100, 6000,
                "自我提升检查间隔(tick)");
    }

    public void save() {
        if (configuration != null && configuration.hasChanged()) {
            configuration.save();
        }
    }

    // ===== Getters =====

    public String getApiEndpoint() { return apiEndpoint; }
    public String getApiKey() { return apiKey; }
    public String getModel() { return model; }
    public int getApiTimeoutMs() { return apiTimeoutMs; }
    public int getApiMaxRetries() { return apiMaxRetries; }

    public String getPartnerName() { return partnerName; }
    public String getPartnerPersona() { return partnerPersona; }
    public String getPartnerSkin() { return partnerSkin; }

    public int getDetectRange() { return detectRange; }
    public int getMaxEntitiesPerScan() { return maxEntitiesPerScan; }
    public int getScanIntervalTicks() { return scanIntervalTicks; }

    public int getMemoryMaxTurns() { return memoryMaxTurns; }
    public int getSpeakBudgetMax() { return speakBudgetMax; }
    public int getDialogueHistorySize() { return dialogueHistorySize; }

    public double getFollowDistance() { return followDistance; }
    public int getCombatDetectRange() { return combatDetectRange; }
    public int getDecisionIntervalTicks() { return decisionIntervalTicks; }

    public boolean isEnableSelfImprove() { return enableSelfImprove; }
    public int getSelfImproveIntervalTicks() { return selfImproveIntervalTicks; }

    // ===== Setters（运行时动态调整，供 ConfigGuard 使用）=====

    public void setDetectRange(int range) {
        this.detectRange = Math.max(4, Math.min(128, range));
        if (configuration != null) {
            configuration.getCategory("detection").get("detectRange").set(detectRange);
        }
    }

    public void setDecisionIntervalTicks(int ticks) {
        this.decisionIntervalTicks = Math.max(10, Math.min(200, ticks));
    }

    public void setSpeakBudgetMax(int budget) {
        this.speakBudgetMax = Math.max(0, Math.min(50, budget));
    }
}
