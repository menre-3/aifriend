package cn.meng.aifriend;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.BlockPos;

public interface IPartnerBody
        extends IPartnerMovement, IPartnerInteraction, IPartnerInventory {
    /** AIBrain 拿主人调 API */
    EntityPlayer getOwner();
    /** AIBrain 判断存活 */
    boolean isAlive();
    /** 任务精确挖矿（破坏指定坐标方块） */
    void mineBlock(BlockPos pos);
    /** 看向世界坐标 */
    void lookAt(double x, double y, double z);
}