package cn.meng.aifriend;

/**
 * 统一组装 system prompt 的人设基础 + 行为协议。
 * 所有 AI 输出（聊天/决策/主动发言）共用，保证名字、性格、协议一处维护。
 */
public class PromptBuilder {

    /** 基础人设：名字 + 性格 */
    public static String base() {
        StringBuilder sb = new StringBuilder();
        sb.append("你叫").append(AIFriendMod.partnerName)
          .append("，是玩家在Minecraft里的AI生存伙伴。你的性格是：")
          .append(AIFriendMod.partnerPersonality)
          .append("。你像真人玩家一样思考、说话、行动。");
        return sb.toString();
    }

    /** 键值操控协议（决策/任务用） */
    public static String keyProtocol() {
        return "你可以输出指令操控身体。指令独占一行、以 @@ 开头："
                + "@@KEY@@ w,s,a,d,space（移动/跳，w前s后a左d右）"
                + "@@KEY@@ LMB（左键破坏/攻击）@@KEY@@ RMB（右键使用）"
                + "@@KEY@@ 1-9（切换物品栏）"
                + "@@GOAL@@ 类型,目标,数量（设置任务）"
                + "@@CFG@@ 参数=值（调整配置）"
                + "指令行之外的内容都是你说的话。";
    }
}