package cn.meng.aifriend;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.BlockPos;

public class MiningGoal implements IGoal {

    private final String oreName;
    private final int target;
    private int mined = 0;

    public MiningGoal(String oreName, int target) {
        this.oreName = oreName;
        this.target = target;
    }

    @Override public String getName() { return "mine"; }
    @Override public boolean isDone() { return this.mined >= this.target; }

    @Override
    public String getDecisionPrompt() {
        return "挖" + this.target + "个" + this.oreName + "（已挖" + this.mined + "个）。"
                + "看到近处目标矿就用 @@MINE@@ dx,dy,dz；只见方向就 @@KEY@@ 朝它走。";
    }

    @Override
    public void applyResult(AIBrain brain, EntityPlayer owner, String text) {
        // 挖矿用 @@MINE@@ 精确指定偏移（由任务自己计数）
        int idx = text.indexOf("@@MINE@@");
        if (idx >= 0) {
            try {
                String[] p = text.substring(idx + "@@MINE@@".length()).trim().split(",");
                int dx = Integer.parseInt(p[0].trim());
                int dy = Integer.parseInt(p[1].trim());
                int dz = Integer.parseInt(p[2].trim());
                BlockPos pos = owner.getPosition().add(dx, dy, dz);
                brain.getBody().mineBlock(pos);
                this.mined++;
            } catch (Exception ignored) {}
        }
        // 移动等其他指令交给 ActionParser
        ActionParser.execute(brain, text);
    }
}