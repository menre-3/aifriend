package cn.meng.aifriend;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class KnowledgeStore {

    public static class ModKnowledge {
        public String name = "";
        public List<String> keywords = new ArrayList<>();
        public List<String> lines = new ArrayList<>();
    }

    private static final List<ModKnowledge> mods = new ArrayList<>(); // 玩家手写(只读)
    private static final List<String> learned = new ArrayList<>();    // AI自动学(learned.txt)
    private static boolean dirty = false;

    // ===== 加载 =====

    public static void load() {
        loadMods();
        loadLearned();
    }

    private static void loadMods() {
        synchronized (mods) { mods.clear(); }
        Path dir = Paths.get("config", "aifriend", "knowledge");
        if (!Files.exists(dir)) return;
        try (java.util.stream.Stream<Path> stream = Files.list(dir)) {
            stream.filter(p -> p.toString().endsWith(".txt"))
                  .forEach(KnowledgeStore::loadFile);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void loadFile(Path p) {
        ModKnowledge mk = new ModKnowledge();
        try {
            List<String> lines = Files.readAllLines(p);
            for (String raw : lines) {
                String line = raw.trim();
                if (line.isEmpty()) continue;
                if (line.startsWith("#名称:")) {
                    mk.name = line.substring(4).trim();
                } else if (line.startsWith("#关键词:")) {
                    for (String k : line.substring(4).trim().split(",")) {
                        if (!k.trim().isEmpty()) mk.keywords.add(k.trim());
                    }
                } else {
                    mk.lines.add(line);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            return;
        }
        if (mk.name.isEmpty() && mk.lines.isEmpty()) return;
        synchronized (mods) { mods.add(mk); }
    }

    // ===== AI 自动学习（只写 learned.txt，绝不碰玩家文件） =====

    public static void learn(String rule) {
        if (rule == null || rule.trim().isEmpty()) return;
        String r = rule.trim();
        synchronized (learned) {
            if (!learned.contains(r)) {
                learned.add(r);
                int max = Math.max(1, AIFriendMod.knowledgeMax); // 防护：<=0 钳到1
                while (learned.size() > max) learned.remove(0);
                dirty = true;
            }
        }
    }

    private static void loadLearned() {
        Path p = Paths.get("config", "aifriend", "learned.txt");
        if (!Files.exists(p)) return;
        try {
            List<String> lines = Files.readAllLines(p);
            synchronized (learned) {
                learned.clear();
                for (String s : lines) if (!s.trim().isEmpty()) learned.add(s.trim());
            }
            dirty = false;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 保存约束：请勿直接调用本方法！
     * learned.txt 持久化统一由 AutoSaveHandler
     * （ServerTickEvent 定时 + FMLServerStoppingEvent 关服强制）触发。
     */
    public static void save() {
        if (!dirty) return;
        Path p = Paths.get("config", "aifriend", "learned.txt");
        try {
            Files.createDirectories(p.getParent());
            synchronized (learned) {
                Files.write(p, learned);
                dirty = false;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ===== 输出 =====

    public static String getModuleList() {
        synchronized (mods) {
            if (mods.isEmpty()) return "";
            StringBuilder sb = new StringBuilder("【已会模组】");
            for (ModKnowledge mk : mods) sb.append(" / ").append(mk.name);
            return sb.toString();
        }
    }

    public static String getContext(String... keywords) {
        StringBuilder sb = new StringBuilder(getModuleList());
        boolean emptyKw = (keywords == null || keywords.length == 0);

        List<ModKnowledge> hit = new ArrayList<>();
        synchronized (mods) {
            if (emptyKw) {
                // 空关键词：仅加载"基础"模组（优先），不追加第二个
                for (ModKnowledge mk : mods) {
                    if (mk.name.contains("基础") && !hit.contains(mk)) { hit.add(mk); break; }
                }
            } else {
                // 有关键词：文件级粗筛，命中1~2个
                for (ModKnowledge mk : mods) {
                    boolean matched = false;
                    for (String kw : keywords) {
                        for (String k : mk.keywords) {
                            if (k.contains(kw) || kw.contains(k)) { matched = true; break; }
                        }
                        if (matched) break;
                    }
                    if (matched && !hit.contains(mk)) hit.add(mk);
                    if (hit.size() >= 2) break;
                }
            }
        }
        for (ModKnowledge mk : hit) {
            sb.append("\n【").append(mk.name).append("】");
            for (String l : mk.lines) sb.append("\n- ").append(l);
        }
        // learned 独立追加，不占 2 个模组名额
        synchronized (learned) {
            if (!learned.isEmpty()) {
                sb.append("\n【你学习到的经验】");
                for (String l : learned) sb.append("\n- ").append(l);
            }
        }
        return sb.toString();
    }
}