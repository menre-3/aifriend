package cn.meng.aifriend.entity;

import cn.meng.aifriend.AIFriendConfig;
import cn.meng.aifriend.AIFriendMod;
import cn.meng.aifriend.api.IPartnerBody;
import cn.meng.aifriend.api.Interaction;
import cn.meng.aifriend.api.Inventory;
import cn.meng.aifriend.api.Movement;
import cn.meng.aifriend.brain.AIBrain;
import cn.meng.aifriend.brain.ConfigGuard;
import cn.meng.aifriend.info.EnvironmentInfo;
import cn.meng.aifriend.info.MemoryManager;
import cn.meng.aifriend.info.WorldEventSource;
import cn.meng.aifriend.lang.EventSpeaker;
import cn.meng.aifriend.lang.SpeakBudget;
import cn.meng.aifriend.learn.StateObserver;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.inventory.InventoryBasic;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.item.ItemTool;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * AI伙伴实体（身体层）
 * 继承EntityCreature，实现IPartnerBody，方法名特意避开父类方法防止递归
 * setSize(0.6F,1.8F)匹配玩家尺寸，配合RenderPlayer解决白模
 */
public class AIPartnerEntity extends EntityCreature implements IPartnerBody {

    private static final DataParameter<String> PARTNER_NAME = EntityDataManager.createKey(
            AIPartnerEntity.class, DataSerializers.STRING);
    private static final DataParameter<String> PARTNER_SKIN = EntityDataManager.createKey(
            AIPartnerEntity.class, DataSerializers.STRING);

    private UUID partnerUUID;
    private UUID ownerUUID;
    private EntityPlayer owner;

    private AIBrain brain;
    private EnvironmentInfo environment;
    private MemoryManager memory;
    private StateObserver stateObserver;
    private EventSpeaker eventSpeaker;
    private ConfigGuard configGuard;
    private AIFriendConfig config;

    private final PartnerMovement movementImpl;
    private final PartnerInteraction interactionImpl;
    private final PartnerInventory inventoryImpl;
    private final InventoryBasic partnerInventory = new InventoryBasic("AI伙伴背包", true, 27);

    private boolean isInitialized = false;
    private BlockPos miningTarget;
    private boolean isMining = false;
    private int miningProgress = 0;

    public AIPartnerEntity(World worldIn) {
        super(worldIn);
        this.movementImpl = new PartnerMovement(this);
        this.interactionImpl = new PartnerInteraction(this);
        this.inventoryImpl = new PartnerInventory(this);
        this.setSize(0.6F, 1.8F);
        this.stepHeight = 1.0F;
    }

    @Override
    protected void entityInit() {
        super.entityInit();
        this.dataManager.register(PARTNER_NAME, "小伴");
        this.dataManager.register(PARTNER_SKIN, "");
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        this.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(20.0D);
        this.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(0.3D);
        this.getEntityAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).setBaseValue(3.0D);
        this.getEntityAttribute(SharedMonsterAttributes.FOLLOW_RANGE).setBaseValue(48.0D);
    }

    public void initialize(EntityPlayer owner) {
        if (isInitialized) return;
        this.owner = owner;
        this.ownerUUID = owner.getUniqueID();
        this.partnerUUID = UUID.nameUUIDFromBytes(("aifriend:" + owner.getName()).getBytes());
        this.config = AIFriendMod.INSTANCE.config;

        String name = config.partnerName;
        this.dataManager.set(PARTNER_NAME, name);
        this.dataManager.set(PARTNER_SKIN, config.partnerSkin);
        this.setCustomNameTag(name);

        this.environment = new EnvironmentInfo(config, world, this);
        this.memory = new MemoryManager(config.memoryMaxTurns, AIFriendMod.getLogger());
        this.stateObserver = new StateObserver(AIFriendMod.INSTANCE.getKnowledgeStore(), memory, AIFriendMod.getLogger());
        this.eventSpeaker = new EventSpeaker(config, AIFriendMod.INSTANCE.getApiClient(), memory,
                new SpeakBudget(config.speakBudgetMax), AIFriendMod.getLogger());
        this.configGuard = new ConfigGuard(config, AIFriendMod.getLogger());
        this.brain = new AIBrain(config, this, AIFriendMod.INSTANCE.getApiClient(),
                environment, AIFriendMod.INSTANCE.getKnowledgeStore(), memory, AIFriendMod.getLogger());

        isInitialized = true;
        AIFriendMod.getLogger().info("AI伙伴 {} 已初始化，主人={}", name, owner.getName());
    }

    @Override
    public void onLivingUpdate() {
        super.onLivingUpdate();
        if (!world.isRemote && isInitialized && owner != null) {
            long tick = world.getTotalWorldTime();
            if (tick % config.scanIntervalTicks == 0) environment.scan();
            stateObserver.observe(owner, tick);
            if (WorldEventSource.hasEvents()) {
                eventSpeaker.processEvents(WorldEventSource.drainEvents(), tick, this);
            }
            eventSpeaker.onPlayerSneakChange(owner.isSneaking(), tick, this);
            eventSpeaker.checkSunset(tick, stateObserver.isPlayerIdle(), this);
            brain.tick(tick);
            if (isMining && miningTarget != null) updateMining();
        }
    }

    private void updateMining() {
        if (world.isAirBlock(miningTarget)) {
            isMining = false;
            miningTarget = null;
            miningProgress = 0;
            return;
        }
        miningProgress++;
        if (miningProgress >= 40) {
            world.destroyBlock(miningTarget, true);
            isMining = false;
            miningTarget = null;
            miningProgress = 0;
        }
    }

    // ===== IPartnerBody 实现 =====
    @Override public Movement getMovement() { return movementImpl; }
    @Override public Interaction getInteraction() { return interactionImpl; }
    @Override public Inventory getInventory() { return inventoryImpl; }
    @Override public Vec3d getPositionVec() { return new Vec3d(posX, posY, posZ); }
    @Override public BlockPos getBlockPosition() { return new BlockPos(posX, posY, posZ); }
    @Override public float getHealthValue() { return super.getHealth(); }
    @Override public float getMaxHealthValue() { return super.getMaxHealth(); }
    @Override public boolean isBodySneaking() { return super.isSneaking(); }
    @Override public boolean isBodySprinting() { return super.isSprinting(); }
    @Override public boolean isEntityAlive() { return super.isEntityAlive(); }
    @Override public void setBodySneaking(boolean sneaking) { super.setSneaking(sneaking); }
    @Override public void setBodySprinting(boolean sprinting) { super.setSprinting(sprinting); }
    @Override public void doJump() { super.jump(); }
    @Override public void doSwingArm() { super.swingArm(EnumHand.MAIN_HAND); }

    @Override
    public void speak(String message) {
        if (owner != null && !world.isRemote) {
            owner.sendMessage(new net.minecraft.util.text.TextComponentString("<" + getName() + "> " + message));
        }
    }

    @Override public Entity getOwnerEntity() { return owner; }

    @Override
    public void setAttackTargetEntity(Entity target) {
        super.setAttackTarget(target instanceof net.minecraft.entity.EntityLiving ? (net.minecraft.entity.EntityLiving) target : null);
    }

    @Override public Entity getAttackTargetEntity() { return super.getAttackTarget(); }
    @Override public World getWorldObject() { return world; }

    @Override
    public String getName() {
        return dataManager.get(PARTNER_NAME);
    }

    public String getPartnerSkin() {
        return dataManager.get(PARTNER_SKIN);
    }

    public void setPartnerSkin(String skin) {
        dataManager.set(PARTNER_SKIN, skin != null ? skin : "");
    }

    // ===== NBT =====
    @Override
    public void writeEntityToNBT(NBTTagCompound compound) {
        super.writeEntityToNBT(compound);
        if (partnerUUID != null) compound.setString("PartnerUUID", partnerUUID.toString());
        if (ownerUUID != null) compound.setString("OwnerUUID", ownerUUID.toString());
        compound.setString("PartnerName", dataManager.get(PARTNER_NAME));
        compound.setString("PartnerSkin", dataManager.get(PARTNER_SKIN));
        net.minecraft.nbt.NBTTagList list = new net.minecraft.nbt.NBTTagList();
        for (int i = 0; i < partnerInventory.getSizeInventory(); i++) {
            ItemStack stack = partnerInventory.getStackInSlot(i);
            if (!stack.isEmpty()) {
                NBTTagCompound tag = new NBTTagCompound();
                tag.setByte("Slot", (byte) i);
                stack.writeToNBT(tag);
                list.appendTag(tag);
            }
        }
        compound.setTag("PartnerInventory", list);
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound compound) {
        super.readEntityFromNBT(compound);
        if (compound.hasKey("PartnerUUID")) partnerUUID = UUID.fromString(compound.getString("PartnerUUID"));
        if (compound.hasKey("OwnerUUID")) ownerUUID = UUID.fromString(compound.getString("OwnerUUID"));
        if (compound.hasKey("PartnerName")) dataManager.set(PARTNER_NAME, compound.getString("PartnerName"));
        if (compound.hasKey("PartnerSkin")) dataManager.set(PARTNER_SKIN, compound.getString("PartnerSkin"));
        net.minecraft.nbt.NBTTagList list = compound.getTagList("PartnerInventory", 10);
        for (int i = 0; i < list.tagCount(); i++) {
            NBTTagCompound tag = list.getCompoundTagAt(i);
            int slot = tag.getByte("Slot") & 255;
            if (slot < partnerInventory.getSizeInventory()) {
                partnerInventory.setInventorySlotContents(slot, new ItemStack(tag));
            }
        }
    }

    @Override
    protected boolean canDespawn() { return false; }

    @Override
    public boolean attackEntityFrom(DamageSource source, float amount) {
        boolean result = super.attackEntityFrom(source, amount);
        if (result && brain != null) {
            brain.onUrgentEvent("AI伙伴受到 " + amount + " 点伤害，来源：" + source.getDamageType());
        }
        return result;
    }

    public void setMiningTarget(BlockPos pos) {
        this.miningTarget = pos;
        this.isMining = pos != null;
        this.miningProgress = 0;
    }

    public AIBrain getBrain() { return brain; }
    public EnvironmentInfo getEnvironment() { return environment; }
    public StateObserver getStateObserver() { return stateObserver; }
    public ConfigGuard getConfigGuard() { return configGuard; }
    public InventoryBasic getPartnerInventory() { return partnerInventory; }
    public boolean isInitialized() { return isInitialized; }
    public UUID getPartnerUUID() { return partnerUUID; }
    public UUID getOwnerUUID() { return ownerUUID; }
    public EntityPlayer getOwnerPlayer() { return owner; }

    public void setOwner(EntityPlayer owner) {
        this.owner = owner;
        if (owner != null) this.ownerUUID = owner.getUniqueID();
    }

    // ===== Movement 内部实现 =====
    private static class PartnerMovement implements Movement {
        private final AIPartnerEntity e;
        PartnerMovement(AIPartnerEntity e) { this.e = e; }

        @Override public boolean moveTo(Vec3d target, double speed) {
            return e.getNavigator().tryMoveToXYZ(target.x, target.y, target.z, speed);
        }
        @Override public boolean moveTo(BlockPos pos, double speed) {
            return e.getNavigator().tryMoveToXYZ(pos.getX(), pos.getY(), pos.getZ(), speed);
        }
        @Override
        public void follow(Entity target, double distance) {
            if (target == null) return;
            double dist = e.getDistance(target);
            if (dist > distance + 1) e.getNavigator().tryMoveToEntityLiving(target, 1.0);
            else if (dist < distance - 1) e.getNavigator().clearPath();
            e.getLookHelper().setLookPositionWithEntity(target, 10, 10);
        }
        @Override public void stopMoving() { e.getNavigator().clearPath(); }
        @Override public boolean isMovingNow() { return !e.getNavigator().noPath(); }
        @Override public void lookAt(Vec3d target) { e.getLookHelper().setLookPosition(target.x, target.y, target.z, 10, 10); }
        @Override public void lookAtEntity(Entity entity) { e.getLookHelper().setLookPositionWithEntity(entity, 10, 10); }
        @Override
        public void wander() {
            double x = e.posX + (e.rand.nextDouble() - 0.5) * 10;
            double z = e.posZ + (e.rand.nextDouble() - 0.5) * 10;
            e.getNavigator().tryMoveToXYZ(x, e.posY, z, 0.5);
        }
        @Override
        public void moveAwayFrom(Vec3d threat, double distance) {
            double dx = e.posX - threat.x;
            double dz = e.posZ - threat.z;
            double len = Math.sqrt(dx * dx + dz * dz);
            if (len > 0) {
                e.getNavigator().tryMoveToXYZ(e.posX + (dx / len) * distance, e.posY, e.posZ + (dz / len) * distance, 1.2);
            }
        }
    }

    // ===== Interaction 内部实现 =====
    private class PartnerInteraction implements Interaction {
        private final AIPartnerEntity e;
        PartnerInteraction(AIPartnerEntity e) { this.e = e; }

        @Override
        public boolean mineBlock(BlockPos pos) {
            if (e.getDistance(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5) > 5) {
                e.getNavigator().tryMoveToXYZ(pos.getX(), pos.getY(), pos.getZ(), 1.0);
                return false;
            }
            e.setMiningTarget(pos);
            e.doSwingArm();
            return true;
        }

        @Override
        public boolean placeBlock(BlockPos pos, ItemStack stack) {
            if (stack == null || stack.isEmpty()) return false;
            net.minecraft.block.Block block = net.minecraft.block.Block.getBlockFromItem(stack.getItem());
            if (block != null) {
                IBlockState state = block.getStateForPlacement(e.world, pos, net.minecraft.util.EnumFacing.UP, 0, 0, 0, stack.getMetadata(), e, EnumHand.MAIN_HAND);
                e.world.setBlockState(pos, state, 3);
                stack.shrink(1);
                return true;
            }
            return false;
        }

        @Override
        public RayTraceResult rayTraceBlock(double range) {
            Vec3d eye = new Vec3d(e.posX, e.posY + e.getEyeHeight(), e.posZ);
            Vec3d look = e.getLookVec();
            Vec3d end = eye.add(look.x * range, look.y * range, look.z * range);
            return e.world.rayTraceBlocks(eye, end, false, true, false);
        }

        @Override public IBlockState getBlockStateAt(BlockPos pos) { return e.world.getBlockState(pos); }
        @Override public boolean canHarvestBlockAt(BlockPos pos) { return e.world.getBlockState(pos).getBlockHardness(e.world, pos) >= 0; }

        @Override
        public boolean attackEntity(Entity target) {
            if (target == null) return false;
            if (e.getDistance(target) > 3) {
                e.getNavigator().tryMoveToEntityLiving(target, 1.2);
                return false;
            }
            e.doSwingArm();
            float damage = (float) e.getEntityAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).getAttributeValue();
            ItemStack weapon = e.getHeldItemMainhand();
            if (weapon.getItem() instanceof ItemSword) damage += ((ItemSword) weapon.getItem()).getAttackDamage();
            target.attackEntityFrom(DamageSource.causeMobDamage(e), damage);
            return true;
        }

        @Override public boolean interactWith(Entity target, EnumHand hand) { return target.processInitialInteract(e, hand); }

        @Override
        public boolean useItemRightClick(EnumHand hand) {
            ItemStack stack = e.getHeldItem(hand);
            if (stack.isEmpty()) return false;
            if (stack.getItem() instanceof net.minecraft.item.ItemFood) {
                e.setHeldItem(hand, stack.getItem().onItemUseFinish(stack, e.world, e));
                return true;
            }
            return false;
        }

        @Override public void setHeldItemSlot(EnumHand hand, ItemStack stack) { e.setHeldItem(hand, stack); }
        @Override public ItemStack getHeldItemMainhandNow() { return e.getHeldItemMainhand(); }

        @Override
        public boolean eatFoodNow() {
            ItemStack held = e.getHeldItemMainhand();
            if (held.getItem() instanceof net.minecraft.item.ItemFood) return useItemRightClick(EnumHand.MAIN_HAND);
            for (int i = 0; i < partnerInventory.getSizeInventory(); i++) {
                ItemStack stack = partnerInventory.getStackInSlot(i);
                if (stack.getItem() instanceof net.minecraft.item.ItemFood) {
                    e.setHeldItem(EnumHand.MAIN_HAND, stack.copy());
                    return useItemRightClick(EnumHand.MAIN_HAND);
                }
            }
            return false;
        }

        @Override public boolean isMiningNow() { return e.isMining; }
        @Override public boolean isAttackingNow() { return e.getAttackTarget() != null; }
        @Override public BlockPos getMiningTargetPos() { return e.miningTarget; }
    }

    // ===== Inventory 内部实现 =====
    private class PartnerInventory implements Inventory {
        private final AIPartnerEntity e;
        PartnerInventory(AIPartnerEntity e) { this.e = e; }

        @Override
        public List<ItemStack> getAllItems() {
            List<ItemStack> items = new ArrayList<>();
            for (int i = 0; i < partnerInventory.getSizeInventory(); i++) {
                ItemStack stack = partnerInventory.getStackInSlot(i);
                if (!stack.isEmpty()) items.add(stack);
            }
            for (EntityEquipmentSlot slot : EntityEquipmentSlot.values()) {
                ItemStack equip = e.getItemStackFromSlot(slot);
                if (!equip.isEmpty()) items.add(equip);
            }
            return items;
        }

        @Override
        public int countItem(Item item) {
            int count = 0;
            for (int i = 0; i < partnerInventory.getSizeInventory(); i++) {
                ItemStack stack = partnerInventory.getStackInSlot(i);
                if (!stack.isEmpty() && stack.getItem() == item) count += stack.getCount();
            }
            return count;
        }

        @Override
        public int countItemByName(String registryName) {
            int count = 0;
            for (ItemStack stack : getAllItems()) {
                if (stack.getItem().getRegistryName().toString().contains(registryName)) count += stack.getCount();
            }
            return count;
        }

        @Override public boolean hasItem(Item item) { return countItem(item) > 0; }
        @Override public boolean hasItemWithCount(Item item, int minCount) { return countItem(item) >= minCount; }

        @Override
        public ItemStack takeItem(Item item, int count) {
            int remaining = count;
            ItemStack result = ItemStack.EMPTY;
            for (int i = 0; i < partnerInventory.getSizeInventory() && remaining > 0; i++) {
                ItemStack stack = partnerInventory.getStackInSlot(i);
                if (!stack.isEmpty() && stack.getItem() == item) {
                    int take = Math.min(remaining, stack.getCount());
                    if (result.isEmpty()) result = stack.splitStack(take);
                    else { result.grow(take); stack.shrink(take); }
                    remaining -= take;
                    if (stack.isEmpty()) partnerInventory.setInventorySlotContents(i, ItemStack.EMPTY);
                }
            }
            return result;
        }

        @Override
        public ItemStack addItem(ItemStack stack) {
            for (int i = 0; i < partnerInventory.getSizeInventory(); i++) {
                ItemStack slot = partnerInventory.getStackInSlot(i);
                if (slot.isEmpty()) {
                    partnerInventory.setInventorySlotContents(i, stack.copy());
                    return ItemStack.EMPTY;
                } else if (slot.isItemEqual(stack) && ItemStack.areItemStackTagsEqual(slot, stack)) {
                    int space = slot.getMaxStackSize() - slot.getCount();
                    if (space > 0) {
                        int add = Math.min(space, stack.getCount());
                        slot.grow(add);
                        stack.shrink(add);
                        if (stack.isEmpty()) return ItemStack.EMPTY;
                    }
                }
            }
            return stack;
        }

        @Override
        public boolean equipBetterArmor() {
            boolean equipped = false;
            for (EntityEquipmentSlot slot : new EntityEquipmentSlot[]{
                    EntityEquipmentSlot.HEAD, EntityEquipmentSlot.CHEST,
                    EntityEquipmentSlot.LEGS, EntityEquipmentSlot.FEET}) {
                ItemStack current = e.getItemStackFromSlot(slot);
                int currentArmor = current.getItem() instanceof ItemArmor ? ((ItemArmor) current.getItem()).damageReduceAmount : 0;
                for (int i = 0; i < partnerInventory.getSizeInventory(); i++) {
                    ItemStack stack = partnerInventory.getStackInSlot(i);
                    if (stack.getItem() instanceof ItemArmor) {
                        ItemArmor armor = (ItemArmor) stack.getItem();
                        if (armor.armorType == slot && armor.damageReduceAmount > currentArmor) {
                            e.setItemStackToSlot(slot, stack.copy());
                            partnerInventory.setInventorySlotContents(i, current.isEmpty() ? ItemStack.EMPTY : current);
                            equipped = true;
                            break;
                        }
                    }
                }
            }
            return equipped;
        }

        @Override
        public boolean equipBetterWeapon() {
            ItemStack current = e.getHeldItemMainhand();
            double currentDamage = current.getItem() instanceof ItemSword
                    ? ((ItemSword) current.getItem()).getAttackDamage()
                    : (current.getItem() instanceof ItemTool ? ((ItemTool) current.getItem()).attackDamage : 1.0);
            for (int i = 0; i < partnerInventory.getSizeInventory(); i++) {
                ItemStack stack = partnerInventory.getStackInSlot(i);
                if (stack.getItem() instanceof ItemSword) {
                    double damage = ((ItemSword) stack.getItem()).getAttackDamage();
                    if (damage > currentDamage) {
                        e.setHeldItem(EnumHand.MAIN_HAND, stack.copy());
                        partnerInventory.setInventorySlotContents(i, current.isEmpty() ? ItemStack.EMPTY : current);
                        return true;
                    }
                }
            }
            return false;
        }

        @Override public boolean equipBetterTool(String toolType) { return false; }
        @Override public int getArmorValueNow() { return e.getTotalArmorValue(); }

        @Override
        public int getUsedSlotsCount() {
            int count = 0;
            for (int i = 0; i < partnerInventory.getSizeInventory(); i++) {
                if (!partnerInventory.getStackInSlot(i).isEmpty()) count++;
            }
            return count;
        }

        @Override public int getCapacitySlots() { return partnerInventory.getSizeInventory(); }
        @Override public boolean isInventoryFull() { return getUsedSlotsCount() >= getCapacitySlots(); }

        @Override
        public void dropItemNow(Item item, int count) {
            ItemStack dropped = takeItem(item, count);
            if (!dropped.isEmpty()) {
                EntityItem entityItem = new EntityItem(e.world, e.posX, e.posY, e.posZ, dropped);
                e.world.spawnEntity(entityItem);
            }
        }

        @Override
        public void sortInventoryNow() {
            List<ItemStack> items = new ArrayList<>();
            for (int i = 0; i < partnerInventory.getSizeInventory(); i++) {
                ItemStack stack = partnerInventory.getStackInSlot(i);
                if (!stack.isEmpty()) { items.add(stack); partnerInventory.setInventorySlotContents(i, ItemStack.EMPTY); }
            }
            for (int i = 0; i < items.size(); i++) {
                for (int j = i + 1; j < items.size(); j++) {
                    ItemStack a = items.get(i);
                    ItemStack b = items.get(j);
                    if (!a.isEmpty() && !b.isEmpty() && a.isItemEqual(b) && ItemStack.areItemStackTagsEqual(a, b)) {
                        int space = a.getMaxStackSize() - a.getCount();
                        int move = Math.min(space, b.getCount());
                        a.grow(move);
                        b.shrink(move);
                    }
                }
            }
            int slot = 0;
            for (ItemStack stack : items) {
                if (!stack.isEmpty() && slot < partnerInventory.getSizeInventory()) {
                    partnerInventory.setInventorySlotContents(slot++, stack);
                }
            }
        }

        @Override
        public Map<String, Integer> getInventorySummaryMap() {
            Map<String, Integer> summary = new HashMap<>();
            for (ItemStack stack : getAllItems()) {
                summary.merge(stack.getDisplayName(), stack.getCount(), Integer::sum);
            }
            return summary;
        }
    }
}
