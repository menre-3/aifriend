package com.aifriend.entity;

import com.aifriend.AIFriendConfig;
import com.aifriend.AIFriendMod;
import com.aifriend.api.IPartnerBody;
import com.aifriend.api.Interaction;
import com.aifriend.api.Inventory;
import com.aifriend.api.Movement;
import com.aifriend.brain.AIBrain;
import com.aifriend.brain.ConfigGuard;
import com.aifriend.info.EnvironmentInfo;
import com.aifriend.info.MemoryManager;
import com.aifriend.info.WorldEventSource;
import com.aifriend.lang.EventSpeaker;
import com.aifriend.learn.StateObserver;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.IEntityLivingData;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.InventoryBasic;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.item.ItemTool;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.World;

import javax.annotation.Nullable;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * AI伙伴实体（身体层）
 *
 * 这是AI在Minecraft中的物理身体，继承 EntityCreature，
 * 实现 IPartnerBody 接口，提供移动、交互、背包能力。
 *
 * 设计要点：
 * - 大脑(AIBrain)通过接口控制身体，身体不知道大脑的存在
 * - 使用离线账号档案：固定名字+UUID，外观像玩家
 * - 目标驱动行为：通过AI任务系统执行
 * - 背包使用 InventoryBasic，支持装备护甲和武器
 * - 无法被 instanceof EntityPlayer 识别（引擎限制），靠行为兼容弥补
 */
public class AIPartnerEntity extends EntityCreature implements IPartnerBody {

    // ===== 数据同步参数 =====
    private static final DataParameter<String> PARTNER_NAME = EntityDataManager.createKey(
            AIPartnerEntity.class, DataSerializers.STRING);
    private static final DataParameter<Boolean> IS_SNEAKING = EntityDataManager.createKey(
            AIPartnerEntity.class, DataSerializers.BOOLEAN);
    private static final DataParameter<Boolean> IS_SPRINTING = EntityDataManager.createKey(
            AIPartnerEntity.class, DataSerializers.BOOLEAN);
    private static final DataParameter<Integer> OWNER_UNIQUE_ID = EntityDataManager.createKey(
            AIPartnerEntity.class, DataSerializers.VARINT);

    // ===== 身份档案 =====
    private UUID partnerUUID;
    private UUID ownerUUID;
    private EntityPlayer owner;

    // ===== 模块引用 =====
    private AIBrain brain;
    private EnvironmentInfo environment;
    private WorldEventSource eventSource;
    private MemoryManager memory;
    private StateObserver stateObserver;
    private EventSpeaker eventSpeaker;
    private ConfigGuard configGuard;
    private AIFriendConfig config;

    // ===== 子模块实现 =====
    private final PartnerMovement movementImpl;
    private final PartnerInteraction interactionImpl;
    private final PartnerInventory inventoryImpl;

    // ===== 背包 =====
    private final InventoryBasic partnerInventory = new InventoryBasic("AI伙伴背包", true, 27);

    // ===== 状态 =====
    private boolean isInitialized = false;
    private BlockPos miningTarget;
    private boolean isMining = false;
    private int miningProgress = 0;

    // 构造函数
    public AIPartnerEntity(World worldIn) {
        super(worldIn);
        this.movementImpl = new PartnerMovement(this);
        this.interactionImpl = new PartnerInteraction(this);
        this.inventoryImpl = new PartnerInventory(this);
        this.setSize(0.6F, 1.8F); // 玩家尺寸
        this.stepHeight = 1.0F;
    }

    @Override
    protected void entityInit() {
        super.entityInit();
        this.dataManager.register(PARTNER_NAME, "小伴");
        this.dataManager.register(IS_SNEAKING, false);
        this.dataManager.register(IS_SPRINTING, false);
        this.dataManager.register(OWNER_UNIQUE_ID, -1);
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        this.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(20.0D);
        this.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(0.3D);
        this.getEntityAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).setBaseValue(3.0D);
        this.getEntityAttribute(SharedMonsterAttributes.FOLLOW_RANGE).setBaseValue(48.0D);
    }

    /**
     * 初始化AI伙伴（生成后调用）
     */
    public void initialize(EntityPlayer owner) {
        if (isInitialized) return;
        this.owner = owner;
        this.ownerUUID = owner.getUniqueID();
        this.partnerUUID = UUID.nameUUIDFromBytes(("aifriend:" + owner.getName()).getBytes());
        this.config = AIFriendMod.INSTANCE.getConfig();

        // 设置名字
        String name = config.getPartnerName();
        this.dataManager.set(PARTNER_NAME, name);
        this.setCustomNameTag(name);

        // 初始化各模块
        this.environment = new EnvironmentInfo(config, world, this);
        this.eventSource = new WorldEventSource();
        this.memory = AIFriendMod.INSTANCE.getMemoryManager();
        this.stateObserver = new StateObserver(AIFriendMod.INSTANCE.getKnowledgeStore(), memory, AIFriendMod.getLogger());
        this.eventSpeaker = new EventSpeaker(config, AIFriendMod.INSTANCE.getApiClient(), memory,
                new com.aifriend.lang.SpeakBudget(config.getSpeakBudgetMax()), AIFriendMod.getLogger());
        this.configGuard = new ConfigGuard(config, AIFriendMod.getLogger());

        // 初始化大脑
        this.brain = new AIBrain(config, this, AIFriendMod.INSTANCE.getApiClient(),
                environment, eventSource, AIFriendMod.INSTANCE.getKnowledgeStore(),
                memory, AIFriendMod.getLogger());

        // 注册AI任务
        this.tasks.addTask(1, new AIPartnerAITick(this));

        isInitialized = true;
        AIFriendMod.getLogger().info("AI伙伴 {} 已初始化，主人={}", name, owner.getName());
    }

    @Override
    public void onLivingUpdate() {
        super.onLivingUpdate();

        if (!world.isRemote && isInitialized && owner != null) {
            long tick = world.getTotalWorldTime();

            // 环境扫描（按间隔）
            if (tick % config.getScanIntervalTicks() == 0) {
                environment.scan();
            }

            // 观察玩家
            stateObserver.observe(owner, tick);

            // 处理世界事件
            if (eventSource.hasEvents()) {
                List<WorldEventSource.WorldEvent> events = eventSource.drainEvents();
                eventSpeaker.processEvents(events, tick, this);
            }

            // 蹲起检测
            eventSpeaker.onPlayerSneakChange(owner.isSneaking(), tick, this);

            // 看夕阳检测
            eventSpeaker.checkSunset(tick, stateObserver.isPlayerIdle(), this);

            // 大脑思考
            brain.tick(tick);

            // 挖掘进度
            if (isMining && miningTarget != null) {
                updateMining();
            }
        }
    }

    // ===== 挖掘逻辑 =====
    private void updateMining() {
        if (world.isAirBlock(miningTarget)) {
            isMining = false;
            miningTarget = null;
            miningProgress = 0;
            return;
        }
        miningProgress++;
        // 简化：每40tick（2秒）挖掉一个方块
        if (miningProgress >= 40) {
            IBlockState state = world.getBlockState(miningTarget);
            world.destroyBlock(miningTarget, true);
            isMining = false;
            miningTarget = null;
            miningProgress = 0;
        }
    }

    // ===== IPartnerBody 接口实现 =====

    @Override
    public Movement getMovement() { return movementImpl; }

    @Override
    public Interaction getInteraction() { return interactionImpl; }

    @Override
    public Inventory getInventory() { return inventoryImpl; }

    @Override
    public Vec3d getPositionVec() {
        return new Vec3d(posX, posY, posZ);
    }

    @Override
    public BlockPos getPosition() {
        return new BlockPos(posX, posY, posZ);
    }

    @Override
    public float getHealth() { return super.getHealth(); }

    @Override
    public float getMaxHealth() { return super.getMaxHealth(); }

    @Override
    public boolean isSneaking() {
        return dataManager.get(IS_SNEAKING);
    }

    @Override
    public boolean isSprinting() {
        return dataManager.get(IS_SPRINTING);
    }

    @Override
    public boolean isAlive() { return isEntityAlive(); }

    @Override
    public void setSneaking(boolean sneaking) {
        dataManager.set(IS_SNEAKING, sneaking);
        super.setSneaking(sneaking);
    }

    @Override
    public void setSprinting(boolean sprinting) {
        dataManager.set(IS_SPRINTING, sprinting);
        super.setSprinting(sprinting);
    }

    @Override
    public void jump() {
        super.jump();
    }

    @Override
    public void swingArm() {
        this.swingArm(EnumHand.MAIN_HAND);
    }

    @Override
    public void speak(String message) {
        // 在聊天栏显示消息
        if (owner != null && !world.isRemote) {
            net.minecraft.util.text.TextComponentString msg =
                    new net.minecraft.util.text.TextComponentString("<" + getName() + "> " + message);
            owner.sendMessage(msg);
        }
    }

    @Override
    public Entity getOwner() { return owner; }

    @Override
    public void setAttackTarget(Entity target) {
        super.setAttackTarget(target instanceof net.minecraft.entity.EntityLiving
                ? (net.minecraft.entity.EntityLiving) target : null);
    }

    @Override
    public Entity getAttackTarget() {
        return super.getAttackTarget();
    }

    @Override
    public World getWorld() { return world; }

    // ===== 名字显示 =====
    @Override
    public String getName() {
        return dataManager.get(PARTNER_NAME);
    }

    // ===== NBT 保存/加载 =====
    @Override
    public void writeEntityToNBT(NBTTagCompound compound) {
        super.writeEntityToNBT(compound);
        if (partnerUUID != null) {
            compound.setString("PartnerUUID", partnerUUID.toString());
        }
        if (ownerUUID != null) {
            compound.setString("OwnerUUID", ownerUUID.toString());
        }
        compound.setString("PartnerName", dataManager.get(PARTNER_NAME));
        // 保存背包
        net.minecraft.nbt.NBTTagList inventoryList = new net.minecraft.nbt.NBTTagList();
        for (int i = 0; i < partnerInventory.getSizeInventory(); i++) {
            ItemStack stack = partnerInventory.getStackInSlot(i);
            if (!stack.isEmpty()) {
                NBTTagCompound itemTag = new NBTTagCompound();
                itemTag.setByte("Slot", (byte) i);
                stack.writeToNBT(itemTag);
                inventoryList.appendTag(itemTag);
            }
        }
        compound.setTag("PartnerInventory", inventoryList);
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound compound) {
        super.readEntityFromNBT(compound);
        if (compound.hasKey("PartnerUUID")) {
            this.partnerUUID = UUID.fromString(compound.getString("PartnerUUID"));
        }
        if (compound.hasKey("OwnerUUID")) {
            this.ownerUUID = UUID.fromString(compound.getString("OwnerUUID"));
        }
        if (compound.hasKey("PartnerName")) {
            dataManager.set(PARTNER_NAME, compound.getString("PartnerName"));
        }
        // 读取背包
        net.minecraft.nbt.NBTTagList inventoryList = compound.getTagList("PartnerInventory", 10);
        for (int i = 0; i < inventoryList.tagCount(); i++) {
            NBTTagCompound itemTag = inventoryList.getCompoundTagAt(i);
            int slot = itemTag.getByte("Slot") & 255;
            if (slot < partnerInventory.getSizeInventory()) {
                partnerInventory.setInventorySlotContents(slot, new ItemStack(itemTag));
            }
        }
    }

    @Override
    public IEntityLivingData onInitialSpawn(DifficultyInstance difficulty,
                                            @Nullable IEntityLivingData livingdata) {
        return livingdata;
    }

    // 防止被自然清除
    @Override
    protected boolean canDespawn() { return false; }

    // 防止被推挤
    @Override
    public boolean canBePushed() { return true; }

    // 受伤时通知大脑
    @Override
    public boolean attackEntityFrom(DamageSource source, float amount) {
        boolean result = super.attackEntityFrom(source, amount);
        if (result && brain != null) {
            brain.onUrgentEvent("AI伙伴受到了 " + amount + " 点伤害，来源：" + source.getDamageType());
        }
        return result;
    }

    // ===== Getters =====
    public AIBrain getBrain() { return brain; }
    public EnvironmentInfo getEnvironment() { return environment; }
    public WorldEventSource getEventSource() { return eventSource; }
    public StateObserver getStateObserver() { return stateObserver; }
    public ConfigGuard getConfigGuard() { return configGuard; }
    public InventoryBasic getPartnerInventory() { return partnerInventory; }
    public boolean isInitialized() { return isInitialized; }
    public UUID getPartnerUUID() { return partnerUUID; }
    public UUID getOwnerUUID() { return ownerUUID; }

    public void setMiningTarget(BlockPos pos) {
        this.miningTarget = pos;
        this.isMining = pos != null;
        this.miningProgress = 0;
    }

    // ===== 移动实现（内部类）=====
    private static class PartnerMovement implements Movement {
        private final AIPartnerEntity entity;

        PartnerMovement(AIPartnerEntity entity) { this.entity = entity; }

        @Override
        public boolean moveTo(Vec3d target, double speed) {
            return entity.getNavigator().tryMoveToXYZ(target.x, target.y, target.z, speed);
        }

        @Override
        public boolean moveTo(BlockPos pos, double speed) {
            return entity.getNavigator().tryMoveToXYZ(pos.getX(), pos.getY(), pos.getZ(), speed);
        }

        @Override
        public void follow(Entity target, double distance) {
            if (target == null) return;
            double dist = entity.getDistance(target);
            if (dist > distance + 1) {
                entity.getNavigator().tryMoveToEntityLiving(target, 1.0);
            } else if (dist < distance - 1) {
                entity.getNavigator().clearPath();
            }
            // 面朝目标
            entity.getLookHelper().setLookPositionWithEntity(target, 10, 10);
        }

        @Override
        public void stop() {
            entity.getNavigator().clearPath();
        }

        @Override
        public boolean isMoving() {
            return !entity.getNavigator().noPath();
        }

        @Override
        public void lookAt(Vec3d target) {
            entity.getLookHelper().setLookPosition(target.x, target.y, target.z, 10, 10);
        }

        @Override
        public void lookAt(Entity entity) {
            this.entity.getLookHelper().setLookPositionWithEntity(entity, 10, 10);
        }

        @Override
        public void wander() {
            // 随机闲逛
            double x = entity.posX + (entity.rand.nextDouble() - 0.5) * 10;
            double z = entity.posZ + (entity.rand.nextDouble() - 0.5) * 10;
            entity.getNavigator().tryMoveToXYZ(x, entity.posY, z, 0.5);
        }

        @Override
        public void moveAwayFrom(Vec3d threat, double distance) {
            double dx = entity.posX - threat.x;
            double dz = entity.posZ - threat.z;
            double len = Math.sqrt(dx * dx + dz * dz);
            if (len > 0) {
                double tx = entity.posX + (dx / len) * distance;
                double tz = entity.posZ + (dz / len) * distance;
                entity.getNavigator().tryMoveToXYZ(tx, entity.posY, tz, 1.2);
            }
        }
    }

    // ===== 交互实现（内部类）=====
    private class PartnerInteraction implements Interaction {
        private final AIPartnerEntity entity;

        PartnerInteraction(AIPartnerEntity entity) { this.entity = entity; }

        @Override
        public boolean mineBlock(BlockPos pos) {
            if (entity.getDistance(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5) > 5) {
                // 太远，先走过去
                entity.getNavigator().tryMoveToXYZ(pos.getX(), pos.getY(), pos.getZ(), 1.0);
                return false;
            }
            entity.setMiningTarget(pos);
            entity.swingArm();
            return true;
        }

        @Override
        public boolean placeBlock(BlockPos pos, ItemStack stack) {
            if (stack == null || stack.isEmpty()) return false;
            if (!entity.world.mayPlace(stack.getItem(), pos, false, net.minecraft.util.EnumFacing.UP, entity)) {
                return false;
            }
            // 简化放置
            net.minecraft.block.Block block = net.minecraft.block.Block.getBlockFromItem(stack.getItem());
            if (block != null) {
                IBlockState state = block.getStateForPlacement(entity.world, pos,
                        net.minecraft.util.EnumFacing.UP, 0, 0, 0, stack.getMetadata(), entity, EnumHand.MAIN_HAND);
                entity.world.setBlockState(pos, state, 3);
                stack.shrink(1);
                return true;
            }
            return false;
        }

        @Override
        public RayTraceResult rayTraceBlock(double range) {
            Vec3d eyePos = new Vec3d(entity.posX, entity.posY + entity.getEyeHeight(), entity.posZ);
            Vec3d look = entity.getLookVec();
            Vec3d end = eyePos.add(look.x * range, look.y * range, look.z * range);
            return entity.world.rayTraceBlocks(eyePos, end, false, true, false);
        }

        @Override
        public IBlockState getBlockState(BlockPos pos) {
            return entity.world.getBlockState(pos);
        }

        @Override
        public boolean canHarvestBlock(BlockPos pos) {
            IBlockState state = entity.world.getBlockState(pos);
            return state.getBlockHardness(entity.world, pos) >= 0;
        }

        @Override
        public boolean attackEntity(Entity target) {
            if (target == null) return false;
            double dist = entity.getDistance(target);
            if (dist > 3) {
                entity.getNavigator().tryMoveToEntityLiving(target, 1.2);
                return false;
            }
            entity.swingArm();
            float damage = (float) entity.getEntityAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).getAttributeValue();
            // 加上武器伤害
            ItemStack weapon = entity.getHeldItemMainhand();
            if (weapon.getItem() instanceof ItemSword) {
                damage += ((ItemSword) weapon.getItem()).getAttackDamage();
            }
            target.attackEntityFrom(DamageSource.causeMobDamage(entity), damage);
            return true;
        }

        @Override
        public boolean interact(Entity target, EnumHand hand) {
            return target.processInitialInteract(entity, hand);
        }

        @Override
        public boolean useItemRightClick(EnumHand hand) {
            ItemStack stack = entity.getHeldItem(hand);
            if (stack.isEmpty()) return false;
            // 简化：食物使用
            if (stack.getItem() instanceof net.minecraft.item.ItemFood) {
                entity.setHeldItem(hand, stack.getItem().onItemUseFinish(stack, entity.world, entity));
                return true;
            }
            return false;
        }

        @Override
        public void setHeldItem(EnumHand hand, ItemStack stack) {
            entity.setHeldItem(hand, stack);
        }

        @Override
        public ItemStack getHeldItemMainhand() {
            return entity.getHeldItemMainhand();
        }

        @Override
        public boolean eatFood() {
            ItemStack held = entity.getHeldItemMainhand();
            if (held.getItem() instanceof net.minecraft.item.ItemFood) {
                return useItemRightClick(EnumHand.MAIN_HAND);
            }
            // 从背包找食物
            for (int i = 0; i < partnerInventory.getSizeInventory(); i++) {
                ItemStack stack = partnerInventory.getStackInSlot(i);
                if (stack.getItem() instanceof net.minecraft.item.ItemFood) {
                    entity.setHeldItem(EnumHand.MAIN_HAND, stack.copy());
                    return useItemRightClick(EnumHand.MAIN_HAND);
                }
            }
            return false;
        }

        @Override
        public boolean isMining() { return entity.isMining; }

        @Override
        public boolean isAttacking() {
            return entity.getAttackTarget() != null;
        }

        @Override
        public BlockPos getMiningTarget() { return entity.miningTarget; }
    }

    // ===== 背包实现（内部类）=====
    private class PartnerInventory implements Inventory {
        private final AIPartnerEntity entity;

        PartnerInventory(AIPartnerEntity entity) { this.entity = entity; }

        @Override
        public List<ItemStack> getAllItems() {
            java.util.List<ItemStack> items = new java.util.ArrayList<>();
            for (int i = 0; i < partnerInventory.getSizeInventory(); i++) {
                ItemStack stack = partnerInventory.getStackInSlot(i);
                if (!stack.isEmpty()) {
                    items.add(stack);
                }
            }
            // 加上装备栏
            for (EntityEquipmentSlot slot : EntityEquipmentSlot.values()) {
                ItemStack equip = entity.getItemStackFromSlot(slot);
                if (!equip.isEmpty()) {
                    items.add(equip);
                }
            }
            return items;
        }

        @Override
        public int countItem(Item item) {
            int count = 0;
            for (int i = 0; i < partnerInventory.getSizeInventory(); i++) {
                ItemStack stack = partnerInventory.getStackInSlot(i);
                if (!stack.isEmpty() && stack.getItem() == item) {
                    count += stack.getCount();
                }
            }
            return count;
        }

        @Override
        public int countItem(String registryName) {
            int count = 0;
            for (ItemStack stack : getAllItems()) {
                if (stack.getItem().getRegistryName().toString().contains(registryName)) {
                    count += stack.getCount();
                }
            }
            return count;
        }

        @Override
        public boolean hasItem(Item item) {
            return countItem(item) > 0;
        }

        @Override
        public boolean hasItem(Item item, int minCount) {
            return countItem(item) >= minCount;
        }

        @Override
        public ItemStack takeItem(Item item, int count) {
            int remaining = count;
            ItemStack result = ItemStack.EMPTY;
            for (int i = 0; i < partnerInventory.getSizeInventory() && remaining > 0; i++) {
                ItemStack stack = partnerInventory.getStackInSlot(i);
                if (!stack.isEmpty() && stack.getItem() == item) {
                    int take = Math.min(remaining, stack.getCount());
                    if (result.isEmpty()) {
                        result = stack.splitStack(take);
                    } else {
                        result.grow(take);
                        stack.shrink(take);
                    }
                    remaining -= take;
                    if (stack.isEmpty()) {
                        partnerInventory.setInventorySlotContents(i, ItemStack.EMPTY);
                    }
                }
            }
            return result;
        }

        @Override
        public ItemStack addItem(ItemStack stack) {
            // 尝试放入背包
            for (int i = 0; i < partnerInventory.getSizeInventory(); i++) {
                ItemStack slot = partnerInventory.getStackInSlot(i);
                if (slot.isEmpty()) {
                    partnerInventory.setInventorySlotContents(i, stack.copy());
                    return ItemStack.EMPTY;
                } else if (slot.isItemEqual(stack) && ItemStack.areItemStackTagsEqual(slot, stack)) {
                    int space = slot.getMaxStackSize() - slot.getCount();
                    if (space > 0) {
                        int add = Math.min(space, stack.getCount());
                        slot.grow(add);
                        stack.shrink(add);
                        if (stack.isEmpty()) return ItemStack.EMPTY;
                    }
                }
            }
            return stack;
        }

        @Override
        public boolean equipBetterArmor() {
            boolean equipped = false;
            for (EntityEquipmentSlot slot : new EntityEquipmentSlot[]{
                    EntityEquipmentSlot.HEAD, EntityEquipmentSlot.CHEST,
                    EntityEquipmentSlot.LEGS, EntityEquipmentSlot.FEET}) {
                ItemStack current = entity.getItemStackFromSlot(slot);
                int currentArmor = current.getItem() instanceof ItemArmor
                        ? ((ItemArmor) current.getItem()).damageReduceAmount : 0;

                for (int i = 0; i < partnerInventory.getSizeInventory(); i++) {
                    ItemStack stack = partnerInventory.getStackInSlot(i);
                    if (stack.getItem() instanceof ItemArmor) {
                        ItemArmor armor = (ItemArmor) stack.getItem();
                        if (armor.armorType == slot && armor.damageReduceAmount > currentArmor) {
                            entity.setItemStackToSlot(slot, stack.copy());
                            partnerInventory.setInventorySlotContents(i, current.isEmpty() ? ItemStack.EMPTY : current);
                            equipped = true;
                            break;
                        }
                    }
                }
            }
            return equipped;
        }

        @Override
        public boolean equipBetterWeapon() {
            ItemStack current = entity.getHeldItemMainhand();
            double currentDamage = current.getItem() instanceof ItemSword
                    ? ((ItemSword) current.getItem()).getAttackDamage()
                    : (current.getItem() instanceof ItemTool
                    ? ((ItemTool) current.getItem()).attackDamage : 1.0);

            for (int i = 0; i < partnerInventory.getSizeInventory(); i++) {
                ItemStack stack = partnerInventory.getStackInSlot(i);
                if (stack.getItem() instanceof ItemSword) {
                    double damage = ((ItemSword) stack.getItem()).getAttackDamage();
                    if (damage > currentDamage) {
                        entity.setHeldItem(EnumHand.MAIN_HAND, stack.copy());
                        partnerInventory.setInventorySlotContents(i, current.isEmpty() ? ItemStack.EMPTY : current);
                        return true;
                    }
                }
            }
            return false;
        }

        @Override
        public boolean equipBetterTool(String toolType) {
            // 简化：找最好的工具
            return false;
        }

        @Override
        public int getArmorValue() {
            return entity.getTotalArmorValue();
        }

        @Override
        public int getUsedSlots() {
            int count = 0;
            for (int i = 0; i < partnerInventory.getSizeInventory(); i++) {
                if (!partnerInventory.getStackInSlot(i).isEmpty()) count++;
            }
            return count;
        }

        @Override
        public int getCapacity() {
            return partnerInventory.getSizeInventory();
        }

        @Override
        public boolean isFull() {
            return getUsedSlots() >= getCapacity();
        }

        @Override
        public void dropItem(Item item, int count) {
            ItemStack dropped = takeItem(item, count);
            if (!dropped.isEmpty()) {
                EntityItem entityItem = new EntityItem(entity.world, entity.posX, entity.posY, entity.posZ, dropped);
                entity.world.spawnEntity(entityItem);
            }
        }

        @Override
        public void sortInventory() {
            // 简单合并相同物品
            java.util.List<ItemStack> items = new java.util.ArrayList<>();
            for (int i = 0; i < partnerInventory.getSizeInventory(); i++) {
                ItemStack stack = partnerInventory.getStackInSlot(i);
                if (!stack.isEmpty()) {
                    items.add(stack);
                    partnerInventory.setInventorySlotContents(i, ItemStack.EMPTY);
                }
            }
            // 合并
            for (int i = 0; i < items.size(); i++) {
                for (int j = i + 1; j < items.size(); j++) {
                    ItemStack a = items.get(i);
                    ItemStack b = items.get(j);
                    if (!a.isEmpty() && !b.isEmpty() && a.isItemEqual(b) && ItemStack.areItemStackTagsEqual(a, b)) {
                        int space = a.getMaxStackSize() - a.getCount();
                        int move = Math.min(space, b.getCount());
                        a.grow(move);
                        b.shrink(move);
                    }
                }
            }
            // 放回
            int slot = 0;
            for (ItemStack stack : items) {
                if (!stack.isEmpty() && slot < partnerInventory.getSizeInventory()) {
                    partnerInventory.setInventorySlotContents(slot++, stack);
                }
            }
        }

        @Override
        public Map<String, Integer> getInventorySummary() {
            Map<String, Integer> summary = new java.util.HashMap<>();
            for (ItemStack stack : getAllItems()) {
                String name = stack.getDisplayName();
                summary.merge(name, stack.getCount(), Integer::sum);
            }
            return summary;
        }
    }

    // ===== AI任务：驱动大脑思考 =====
    private static class AIPartnerAITick extends EntityAIBase {
        private final AIPartnerEntity entity;

        AIPartnerAITick(AIPartnerEntity entity) {
            this.entity = entity;
            this.setMutexBits(0); // 不阻塞其他任务
        }

        @Override
        public boolean shouldExecute() {
            return entity.isInitialized;
        }

        @Override
        public void updateTask() {
            // 实际逻辑在 onLivingUpdate 中处理
        }
    }
}
