package cn.meng.aifriend;

import cn.meng.aifriend.client.RenderAIPartner;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.config.Configuration;
import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.fml.client.registry.RenderingRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.event.FMLServerStartingEvent;
import net.minecraftforge.fml.common.event.FMLServerStoppingEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.registry.EntityRegistry;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

@Mod(modid = AIFriendMod.MODID, name = AIFriendMod.NAME, version = AIFriendMod.VERSION, acceptedMinecraftVersions = "[1.12.2]")
public class AIFriendMod {

    public static final String MODID = "aifriend";
    public static final String NAME = "AI Friend";
    public static final String VERSION = "3.4.0";

    @Mod.Instance(MODID)
    public static AIFriendMod instance;

    public static String apiUrl = "https://api.deepseek.com/v1/chat/completions";
    public static String apiKey = "";
    public static String model = "deepseek-chat";
    public static int apiTimeout = 30;
    public static int replyMaxTokens = 512;
    public static String partnerName = "The_Future";
    public static String partnerPersonality = "暖心可爱，句尾爱带'啦''呀''哦'，会用(・ω・)颜文字，是玩家最好的朋友";
    public static double personalityTalkative = 1.0;
    public static int thinkInterval = 300;
    public static int taskInterval = 40;
    public static int knowledgeMax = 200;
    public static int memoryMax = 100;
    public static int contextMax = 4000;
    public static int speakBudgetMax = 8;
    public static boolean autoSpeak = true;
    public static boolean autoThink = true;
    public static String cfgWhitelist = "";

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        loadConfig(event);
        createSkinFolder(event);
        GoalRegistry.registerDefaults();
        KnowledgeStore.load();
        MemoryManager.load();
        EntityRegistry.registerModEntity(new ResourceLocation(MODID, "ai_partner"),
                AIPartnerEntity.class, "ai_partner", 0, instance, 64, 1, true);
    }

    private void loadConfig(FMLPreInitializationEvent event) {
        try {
            Configuration cfg = new Configuration(new File(event.getModConfigurationDirectory(), "aifriend.cfg"));
            cfg.load();
            String url = cfg.get("general", "api_url", apiUrl).getString();
            String key = cfg.get("general", "api_key", apiKey).getString();
            String mdl = cfg.get("general", "model", model).getString();
            int timeout = cfg.get("general", "api_timeout", apiTimeout).getInt();
            int maxTok = cfg.get("general", "reply_max_tokens", replyMaxTokens).getInt();
            String name = cfg.get("general", "partner_name", partnerName).getString();
            String pers = cfg.get("general", "partner_personality", partnerPersonality).getString();
            double talk = cfg.get("general", "personality_talkative", personalityTalkative).getDouble();
            int think = cfg.get("general", "think_interval", thinkInterval).getInt();
            int task = cfg.get("general", "task_interval", taskInterval).getInt();
            int kmax = cfg.get("general", "knowledge_max", knowledgeMax).getInt();
            int mmax = cfg.get("general", "memory_max", memoryMax).getInt();
            int cmax = cfg.get("general", "context_max", contextMax).getInt();
            int sbmax = cfg.get("general", "speak_budget_max", speakBudgetMax).getInt();
            boolean as = cfg.get("general", "auto_speak", autoSpeak).getBoolean();
            boolean at = cfg.get("general", "auto_think", autoThink).getBoolean();
            String wl = cfg.get("general", "cfg_whitelist", cfgWhitelist).getString();
            cfg.save();
            apiUrl = url; apiKey = key; model = mdl; apiTimeout = timeout;
            replyMaxTokens = maxTok; partnerName = name; partnerPersonality = pers;
            personalityTalkative = talk; thinkInterval = think; taskInterval = task;
            knowledgeMax = kmax; memoryMax = mmax; contextMax = cmax;
            speakBudgetMax = sbmax; autoSpeak = as; autoThink = at; cfgWhitelist = wl;
        } catch (Exception e) {
            e.printStackTrace(); // 加载失败保留静态默认值
        }
    }

    private void createSkinFolder(FMLPreInitializationEvent event) {
        try {
            File cfgDir = event.getModConfigurationDirectory();
            Path skinDir = Paths.get(cfgDir.getPath(), "aifriend", "skin");
            Files.createDirectories(skinDir);
            Path readme = skinDir.resolve("README.txt");
            if (!Files.exists(readme)) {
                Files.write(readme, ("把 The_Future 的皮肤命名为 partner.png 放到这里（64x64 玩家皮肤 PNG），重启生效。").getBytes("UTF-8"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        if (event.getSide().isClient())
            RenderingRegistry.registerEntityRenderingHandler(AIPartnerEntity.class, RenderAIPartner::new);
    }

    @Mod.EventHandler
    public void serverStarting(FMLServerStartingEvent event) {
        event.registerServerCommand(new CommandSpawnPartner());
        event.registerServerCommand(new CommandKillPartner());
        MinecraftForge.EVENT_BUS.register(this); // 仅服务端注册
    }

    @Mod.EventHandler
    public void serverStopping(FMLServerStoppingEvent event) {
        KnowledgeStore.save(); // 关服强制特例
        MemoryManager.save();
    }

    @SubscribeEvent
    public void onServerChat(ServerChatEvent event) {
        String msg = event.getMessage();
        String prefix = "@" + partnerName;
        if (!msg.startsWith(prefix)) return;
        event.setCanceled(true);
        String question = msg.substring(prefix.length()).trim();
        final EntityPlayerMP player = event.getPlayer();

        AIPartnerEntity partner = findPartner(player.world);
        if (partner != null) partner.resetSpeakBudget();

        if (question.isEmpty()) {
            player.sendMessage(new TextComponentString(partnerName + ": 想问我什么呀？(・ω・)"));
            return;
        }
        final String q = question;
        new Thread(() -> {
            try {
                String reply = AiApiClient.ask(q, player);
                player.getServer().addScheduledTask(() ->
                        player.sendMessage(new TextComponentString(partnerName + ": " + reply)));
            } catch (Exception e) {
                e.printStackTrace();
                player.getServer().addScheduledTask(() ->
                        player.sendMessage(new TextComponentString(partnerName + ": 呜呜连不上API…检查 config 哦")));
            }
        }).start();
    }

    @SubscribeEvent
    public void onPartnerDeath(LivingDeathEvent event) {
        if (!(event.getEntityLiving() instanceof AIPartnerEntity)) return;
        event.setCanceled(true);
        AIPartnerEntity partner = (AIPartnerEntity) event.getEntityLiving();
        partner.setHealth(partner.getMaxHealth());
        // 传送到世界出生点
        BlockPos spawn = partner.world.getSpawnPoint();
        partner.setPosition(spawn.getX() + 0.5D, spawn.getY() + 0.5D, spawn.getZ() + 0.5D);
        // 重生后触发思考，根据判断继续做事
        partner.onRespawn();
    }

    private AIPartnerEntity findPartner(World world) {
        List<AIPartnerEntity> list = world.getEntities(AIPartnerEntity.class, e -> true);
        return list.isEmpty() ? null : list.get(0);
    }
}