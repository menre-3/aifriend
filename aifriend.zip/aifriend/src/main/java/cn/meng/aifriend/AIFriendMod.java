package cn.meng.aifriend;

import cn.meng.aifriend.command.CommandKillPartner;
import cn.meng.aifriend.command.CommandSpawnPartner;
import cn.meng.aifriend.entity.AIPartnerEntity;
import cn.meng.aifriend.info.KnowledgeStore;
import cn.meng.aifriend.info.MemoryManager;
import cn.meng.aifriend.net.AiApiClient;
import cn.meng.aifriend.render.RenderAIPartner;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.registry.RenderingRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.event.FMLServerStartingEvent;
import net.minecraftforge.fml.common.registry.EntityRegistry;
import org.apache.logging.log4j.Logger;

import java.io.File;

/**
 * AI Friend 模组入口
 * 包名：cn.meng.aifriend
 */
@Mod(
        modid = AIFriendMod.MOD_ID,
        name = "AI Friend",
        version = "0.1.0-dev",
        acceptedMinecraftVersions = "[1.12.2]",
        dependencies = "required-after:forge@[14.23.5.2860,)"
)
public class AIFriendMod {

    public static final String MOD_ID = "aifriend";
    public static final String MOD_NAME = "AI Friend";
    public static final String VERSION = "0.1.0-dev";

    @Mod.Instance(MOD_ID)
    public static AIFriendMod INSTANCE;

    private static Logger logger;

    public AIFriendConfig config;
    private AiApiClient apiClient;
    private KnowledgeStore knowledgeStore;
    private MemoryManager memoryManager;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        logger = event.getModLog();
        logger.info("AI Friend 预初始化...");

        // 配置
        config = new AIFriendConfig(event.getSuggestedConfigurationFile());
        config.setLogger(logger);
        config.load();

        // 网络客户端
        apiClient = new AiApiClient(config);
        apiClient.setLogger(logger);

        // 知识库
        knowledgeStore = new KnowledgeStore(event.getModConfigurationDirectory(), logger);
        knowledgeStore.loadAll();

        // 记忆
        memoryManager = new MemoryManager(config.memoryMaxTurns, logger);

        // 注册实体
        EntityRegistry.registerModEntity(
                AIPartnerEntity.class,
                "ai_partner",
                1,
                this,
                80,
                3,
                true
        );

        // 客户端注册渲染（必须在ModelRegistryEvent中，否则白模）
        if (event.getSide().isClient()) {
            MinecraftForge.EVENT_BUS.register(new Object() {
                @net.minecraftforge.fml.common.eventhandler.SubscribeEvent
                public void onModelRegister(ModelRegistryEvent evt) {
                    RenderingRegistry.registerEntityRenderingHandler(
                            AIPartnerEntity.class, new RenderAIPartner.Factory());
                    logger.info("AI伙伴渲染器已注册（玩家人形模型，非白模）");
                }
            });
        }

        logger.info("AI Friend 预初始化完成，探测范围={}格", config.detectRange);
    }

    @Mod.EventHandler
    public void init(net.minecraftforge.fml.common.event.FMLInitializationEvent event) {
        logger.info("AI Friend 初始化完成");
    }

    @Mod.EventHandler
    public void serverStarting(FMLServerStartingEvent event) {
        event.registerServerCommand(new CommandSpawnPartner());
        event.registerServerCommand(new CommandKillPartner());
        logger.info("AI Friend 命令已注册");
    }

    public static Logger getLogger() {
        return logger;
    }

    public AiApiClient getApiClient() {
        return apiClient;
    }

    public KnowledgeStore getKnowledgeStore() {
        return knowledgeStore;
    }

    public MemoryManager getMemoryManager() {
        return memoryManager;
    }

    public AIFriendConfig getConfig() {
        return config;
    }
}
