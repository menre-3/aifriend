package cn.meng.aifriend;

import cn.meng.aifriend.client.RenderAIPartner;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.block.Block;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.config.Config;
import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.fml.client.registry.RenderingRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.event.FMLServerStartingEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.registry.EntityRegistry;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

@Mod(modid = AIFriendMod.MODID, name = AIFriendMod.NAME, version = AIFriendMod.VERSION, acceptedMinecraftVersions = "[1.12.2]")
public class AIFriendMod {

    public static final String MODID = "aifriend";
    public static final String NAME = "AI Friend";
    public static final String VERSION = "1.0.0";

    @Mod.Instance(MODID)
    public static AIFriendMod instance;

    @Config(modid = MODID, name = "aifriend")
    public static class Config {
        @Config.Name("api_url")
        @Config.Comment("OpenAI-compatible endpoint, e.g. https://api.deepseek.com/v1/chat/completions")
        public static String apiUrl = "https://api.deepseek.com/v1/chat/completions";
        @Config.Name("api_key")
        @Config.Comment("Your API key")
        public static String apiKey = "";
        @Config.Name("model")
        @Config.Comment("Model name, e.g. deepseek-chat")
        public static String model = "deepseek-chat";
        @Config.Name("partner_name")
        @Config.Comment("The partner's name shown in chat")
        public static String partnerName = "小火";
    }

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        try {
            Files.createDirectories(Paths.get("config", "aifriend", "skin"));
            if (!Files.exists(Paths.get("config", "aifriend", "skin", "README.txt"))) {
                Files.write(Paths.get("config", "aifriend", "skin", "README.txt"),
                        ("把小火的皮肤命名为 partner.png 放到这里（64x64 的 Minecraft 玩家皮肤 PNG）。\n" +
                         "放好重启游戏，小火就穿上啦！不放则用默认 Steve。").getBytes("UTF-8"));
            }
        } catch (Exception ignored) {}

        MemoryManager.load();
        EntityRegistry.registerModEntity(
                new ResourceLocation(MODID, "ai_partner"),
                AIPartnerEntity.class,
                "ai_partner",
                0,
                instance,
                64,
                1,
                true);
        MinecraftForge.EVENT_BUS.register(this);
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        if (event.getSide().isClient()) {
            RenderingRegistry.registerEntityRenderingHandler(AIPartnerEntity.class, RenderAIPartner::new);
        }
    }

    @Mod.EventHandler
    public void serverStarting(FMLServerStartingEvent event) {
        event.registerServerCommand(new CommandSpawnPartner());
    }

    @SubscribeEvent
    public void onServerChat(ServerChatEvent event) {
        String msg = event.getMessage();
        String prefix = "@" + Config.partnerName;
        if (!msg.startsWith(prefix)) return;
        event.setCanceled(true);
        String question = msg.substring(prefix.length()).trim();
        final EntityPlayerMP player = event.getPlayer();
        if (question.isEmpty()) {
            player.sendMessage(new TextComponentString("\u00A7a" + Config.partnerName + ": 想问我什么呀？(・ω・)"));
            return;
        }
        final String q = question;
        new Thread(() -> {
            try {
                String text = AiApiClient.ask(q, player);
                player.getServer().addScheduledTask(() -> handleReply(player, text));
            } catch (Exception e) {
                player.getServer().addScheduledTask(() ->
                        player.sendMessage(new TextComponentString(Config.partnerName + ": 呜呜我连不上API啦…检查 config 哦(｡•́︿•̀｡)")));
            }
        }).start();
    }

    private void handleReply(EntityPlayerMP player, String text) {
        int idx = text.indexOf("@@ACTION@@");
        String reply = text;
        String actionJson = null;
        if (idx >= 0) {
            reply = text.substring(0, idx).trim();
            actionJson = text.substring(idx + "@@ACTION@@".length()).trim();
        }
        player.sendMessage(new TextComponentString("\u00A7a" + Config.partnerName + ": " + reply));
        if (actionJson == null || actionJson.isEmpty()) return;

        try {
            JsonObject act = JsonParser.parseString(actionJson).getAsJsonObject();
            String type = act.get("type").getAsString();
            int dx = act.get("dx").getAsInt();
            int dy = act.get("dy").getAsInt();
            int dz = act.get("dz").getAsInt();
            BlockPos pos = player.getPosition().add(dx, dy, dz);
            Block block = null;
            if (type.equals("place")) {
                block = Block.REGISTRY.getObject(new ResourceLocation(act.get("block").getAsString()));
            }
            AIPartnerEntity partner = findNearest(player);
            if (partner == null) {
                player.sendMessage(new TextComponentString(Config.partnerName + ": 我得先在你身边呀，用 /spawnpartner 把我叫出来嘛(｡•́︿•̀｡)"));
                return;
            }
            if (type.equals("mine")) {
                partner.setTask(1, pos, null);
            } else if (type.equals("place")) {
                partner.setTask(2, pos, block);
            }
        } catch (Exception e) {
            player.sendMessage(new TextComponentString(Config.partnerName + ": 呜这次指令我不太懂，下次说清楚点呀(´•̥ ω •̥`)"));
        }
    }

    private AIPartnerEntity findNearest(EntityPlayerMP player) {
        List<AIPartnerEntity> list = player.world.getEntitiesWithinAABB(AIPartnerEntity.class,
                player.getEntityBoundingBox().grow(32), e -> true);
        AIPartnerEntity nearest = null;
        double min = Double.MAX_VALUE;
        for (AIPartnerEntity e : list) {
            double d = e.getDistanceSq(player.posX, player.posY, player.posZ);
            if (d < min) { min = d; nearest = e; }
        }
        return nearest;
    }
}