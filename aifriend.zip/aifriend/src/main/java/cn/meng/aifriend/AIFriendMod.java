package com.aifriend;

import com.aifriend.command.CommandKillPartner;
import com.aifriend.command.CommandSpawnPartner;
import com.aifriend.entity.AIPartnerEntity;
import com.aifriend.info.KnowledgeStore;
import com.aifriend.info.MemoryManager;
import com.aifriend.net.AiApiClient;
import com.aifriend.render.RenderAIPartner;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.event.FMLServerStartingEvent;
import net.minecraftforge.fml.common.registry.EntityRegistry;
import net.minecraftforge.fml.relauncher.Side;
import org.apache.logging.log4j.Logger;

/**
 * AI Friend 模组入口类
 * 负责：配置加载、实体注册、事件注册、命令注册、各模块初始化
 */
@Mod(
        modid = AIFriendMod.MOD_ID,
        name = AIFriendMod.MOD_NAME,
        version = AIFriendMod.VERSION,
        acceptedMinecraftVersions = "[1.12.2]",
        dependencies = "required-after:forge@[14.23.5.2860,)"
)
public class AIFriendMod {

    public static final String MOD_ID = "aifriend";
    public static final String MOD_NAME = "AI Friend";
    public static final String VERSION = "0.1.0-dev";

    @Mod.Instance(MOD_ID)
    public static AIFriendMod INSTANCE;

    private static Logger logger;

    // 全局模块引用
    private AiApiClient apiClient;
    private KnowledgeStore knowledgeStore;
    private MemoryManager memoryManager;
    private AIFriendConfig config;

    @EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        logger = event.getModLog();
        logger.info("AI Friend 模组正在预初始化...");

        // 加载配置
        config = new AIFriendConfig(event.getSuggestedConfigurationFile());
        config.load();

        // 初始化网络客户端
        apiClient = new AiApiClient(config);

        // 初始化知识库（从配置目录加载外置说明书）
        knowledgeStore = new KnowledgeStore(event.getModConfigurationDirectory(), logger);
        knowledgeStore.loadAll();

        // 初始化记忆管理器
        memoryManager = new MemoryManager(config.getMemoryMaxTurns(), logger);

        // 注册实体
        int entityId = 1;
        EntityRegistry.registerModEntity(
                AIPartnerEntity.class,
                "ai_partner",
                entityId,
                this,
                80,
                3,
                true
        );

        // 客户端注册渲染
        if (event.getSide() == Side.CLIENT) {
            RenderAIPartner.register();
        }

        logger.info("AI Friend 预初始化完成，探测范围={}格", config.getDetectRange());
    }

    @EventHandler
    public void init(FMLInitializationEvent event) {
        logger.info("AI Friend 模组初始化完成");
    }

    @EventHandler
    public void serverStarting(FMLServerStartingEvent event) {
        event.registerServerCommand(new CommandSpawnPartner());
        event.registerServerCommand(new CommandKillPartner());
        logger.info("AI Friend 命令已注册");
    }

    // ===== 全局模块访问器 =====

    public static Logger getLogger() {
        return logger;
    }

    public AiApiClient getApiClient() {
        return apiClient;
    }

    public KnowledgeStore getKnowledgeStore() {
        return knowledgeStore;
    }

    public MemoryManager getMemoryManager() {
        return memoryManager;
    }

    public AIFriendConfig getConfig() {
        return config;
    }
}
