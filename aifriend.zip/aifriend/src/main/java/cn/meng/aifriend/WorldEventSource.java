package cn.meng.aifriend;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.EntityItemPickupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import java.util.ArrayList;
import java.util.List;

/**
 * 可见消息层：把世界事件转成"玩家屏幕可见消息"，供 AI 感知。
 * AI 不直读内部数据，只通过"对话框/成就框"这类可见信息判断。
 */
@Mod.EventBusSubscriber(modid = AIFriendMod.MODID)
public class WorldEventSource {

    private static class Event {
        final String text;
        final long time; // System.currentTimeMillis
        Event(String text) { this.text = text; this.time = System.currentTimeMillis(); }
    }

    private static final List<Event> events = new ArrayList<>();
    private static final int MAX_EVENTS = 5;       // 最多5条
    private static final long TTL_MS = 60_000L;    // 60秒

    /** 记录一条可见事件 */
    public static synchronized void record(String message) {
        if (message == null || message.trim().isEmpty()) return;
        events.add(new Event(message.trim()));
        prune();
    }

    /** 双重强制过期：最多5条 + 超60秒淘汰 */
    private static void prune() {
        long now = System.currentTimeMillis();
        events.removeIf(e -> now - e.time > TTL_MS);
        while (events.size() > MAX_EVENTS) events.remove(0);
    }

    /** 取近期事件文本（拼进上下文环境段） */
    public static synchronized String getRecentEvents() {
        prune();
        if (events.isEmpty()) return "";
        StringBuilder sb = new StringBuilder("\n【近期事件】");
        for (Event e : events) sb.append("\n- ").append(e.text);
        return sb.toString();
    }

    // ===== 事件源监听（服务端） =====

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent event) {
        if (event.getEntityLiving() instanceof EntityPlayer) {
            record("[对话框] " + event.getEntityLiving().getName() + " 死了");
        }
    }

    @SubscribeEvent
    public static void onPickup(EntityItemPickupEvent event) {
        if (event.getEntity() instanceof EntityPlayer) {
            ItemStack stack = event.getItem().getItem();
            if (stack.getItem() == Items.DIAMOND) {
                record("[成就] " + event.getEntity().getName() + " 获得了钻石！");
            }
        }
    }
}