package cn.meng.aifriend.lang;

/**
 * 发言预算管理器
 */
public class SpeakBudget {

    private final int maxPerDay;
    private int usedToday = 0;
    private long lastDayResetTick = 0;
    private long lastSpeakTick = 0;
    private static final long MIN_INTERVAL_TICKS = 100;

    public SpeakBudget(int maxPerDay) {
        this.maxPerDay = maxPerDay;
    }

    public boolean canSpeak(long currentTick) {
        checkDayReset(currentTick);
        if (usedToday >= maxPerDay) return false;
        if (currentTick > 0 && currentTick - lastSpeakTick < MIN_INTERVAL_TICKS) return false;
        return true;
    }

    public void consume(long currentTick) {
        usedToday++;
        lastSpeakTick = currentTick;
    }

    public int getRemaining() {
        return Math.max(0, maxPerDay - usedToday);
    }

    public int getUsedToday() {
        return usedToday;
    }

    public int getMaxPerDay() {
        return maxPerDay;
    }

    private void checkDayReset(long currentTick) {
        if (currentTick == 0) return;
        long currentDay = currentTick / 24000;
        long lastDay = lastDayResetTick / 24000;
        if (currentDay > lastDay) {
            usedToday = 0;
            lastDayResetTick = currentTick;
        }
    }

    public void reset() {
        usedToday = 0;
    }
}
