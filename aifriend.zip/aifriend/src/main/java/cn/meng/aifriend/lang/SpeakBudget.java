package com.aifriend.lang;

/**
 * 发言预算管理器（语言层）
 * 控制AI每天主动发言的次数上限，避免话太多
 *
 * 预算规则：
 * - 每个Minecraft游戏日（24000 tick = 20分钟）有固定预算
 * - 玩家主动对话不消耗预算（玩家找你聊天当然要回）
 * - 主动发言（事件触发、周期发言）消耗预算
 * - 预算用完后，当天不再主动说话，但仍可回复玩家
 */
public class SpeakBudget {

    private final int maxPerDay;
    private int usedToday = 0;
    private long lastDayResetTick = 0;

    // 主动发言的最小间隔（tick），防止连续说话
    private static final long MIN_INTERVAL_TICKS = 100; // 5秒
    private long lastSpeakTick = 0;

    public SpeakBudget(int maxPerDay) {
        this.maxPerDay = maxPerDay;
    }

    /**
     * 检查是否可以主动发言
     */
    public boolean canSpeak() {
        return canSpeak(0);
    }

    /**
     * 检查是否可以主动发言（带当前tick）
     */
    public boolean canSpeak(long currentTick) {
        // 检查是否跨天
        checkDayReset(currentTick);
        // 预算检查
        if (usedToday >= maxPerDay) return false;
        // 间隔检查
        if (currentTick > 0 && currentTick - lastSpeakTick < MIN_INTERVAL_TICKS) return false;
        return true;
    }

    /**
     * 消耗一次发言预算
     */
    public void consume() {
        usedToday++;
    }

    /**
     * 消耗一次发言预算（记录时间）
     */
    public void consume(long currentTick) {
        usedToday++;
        lastSpeakTick = currentTick;
    }

    /**
     * 获取今日剩余预算
     */
    public int getRemaining() {
        return Math.max(0, maxPerDay - usedToday);
    }

    /**
     * 获取今日已用预算
     */
    public int getUsedToday() {
        return usedToday;
    }

    /**
     * 获取每日上限
     */
    public int getMaxPerDay() {
        return maxPerDay;
    }

    /**
     * 检查是否需要跨天重置
     * Minecraft一天 = 24000 tick
     */
    private void checkDayReset(long currentTick) {
        if (currentTick == 0) return;
        long currentDay = currentTick / 24000;
        long lastDay = lastDayResetTick / 24000;
        if (currentDay > lastDay) {
            usedToday = 0;
            lastDayResetTick = currentTick;
        }
    }

    /**
     * 手动重置（如新的一天开始）
     */
    public void reset() {
        usedToday = 0;
    }

    /**
     * 动态调整每日上限
     */
    public void setMaxPerDay(int max) {
        // 不直接修改final字段，通过新建方式或外部配置
        // 这里只提供接口，实际调整由ConfigGuard处理
    }
}
