package cn.meng.aifriend;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class MemoryManager {

    private static final int MAX = 100;
    private static final List<String> memory = new ArrayList<>();

    public static void record(String action) {
        synchronized (memory) {
            memory.add(action);
            if (memory.size() > MAX) memory.remove(0);
        }
        save();
    }

    public static String getContext() {
        StringBuilder sb = new StringBuilder();
        if (memory.isEmpty()) return "";
        sb.append("【你主人的近期生存记录，回答时贴合这些习惯】");
        synchronized (memory) {
            for (String m : memory) sb.append("\n- ").append(m);
        }
        return sb.toString();
    }

    public static void load() {
        Path path = getPath();
        if (!Files.exists(path)) return;
        try (BufferedReader br = Files.newBufferedReader(path)) {
            JsonArray arr = JsonParser.parseReader(br).getAsJsonArray();
            synchronized (memory) {
                memory.clear();
                for (JsonElement e : arr) memory.add(e.getAsString());
            }
        } catch (Exception ignored) {}
    }

    public static void save() {
        Path path = getPath();
        try {
            Files.createDirectories(path.getParent());
            JsonArray arr = new JsonArray();
            synchronized (memory) {
                for (String m : memory) arr.add(m);
            }
            try (BufferedWriter bw = Files.newBufferedWriter(path)) {
                bw.write(arr.toString());
            }
        } catch (Exception ignored) {}
    }

    private static Path getPath() {
        return Paths.get("config", "aifriend", "memory.json");
    }
}