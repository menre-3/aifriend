package cn.meng.aifriend;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class MemoryManager {

    private static final int MAX = 100;
    private static final List<String> memory = new ArrayList<>();

    public static void record(String action) {
        synchronized (memory) {
            memory.add(action);
            if (memory.size() > MAX) memory.remove(0);
        }
        save();
    }

    public static String getContext() {
        StringBuilder sb = new StringBuilder();
        if (memory.isEmpty()) return "";
        sb.append("【你主人的近期生存记录，回答时贴合这些习惯】");
        synchronized (memory) {
            for (String m : memory) sb.append("\n- ").append(m);
        }
        return sb.toString();
    }

    public static void load() {
        Path path = getPath();
        if (!Files.exists(path)) return;
        try {
            List<String> lines = Files.readAllLines(path);
            synchronized (memory) {
                memory.clear();
                memory.addAll(lines);
            }
        } catch (Exception ignored) {}
    }

    public static void save() {
        Path path = getPath();
        try {
            Files.createDirectories(path.getParent());
            Files.write(path, memory);
        } catch (Exception ignored) {}
    }

    private static Path getPath() {
        return Paths.get("config", "aifriend", "memory.txt");
    }
}