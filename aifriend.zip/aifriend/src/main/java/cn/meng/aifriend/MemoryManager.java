package cn.meng.aifriend;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class MemoryManager {

    private static final List<String> memory = new ArrayList<>();
    private static boolean dirty = false;

    /** 记录一条行为（主线程调用） */
    public static void record(String action) {
        if (action == null || action.trim().isEmpty()) return;
        synchronized (memory) {
            memory.add(action.trim());
            int max = Math.max(1, AIFriendMod.memoryMax); // 防护：<=0 钳到1
            while (memory.size() > max) memory.remove(0); // 裁剪最早
            dirty = true;
        }
    }

    /** 拼近期行为摘要 */
    public static String getContext() {
        synchronized (memory) {
            if (memory.isEmpty()) return "";
            StringBuilder sb = new StringBuilder("【你主人的近期生存记录】");
            for (String m : memory) sb.append("\n- ").append(m);
            return sb.toString();
        }
    }

    public static void load() {
        Path p = getPath();
        if (!Files.exists(p)) return;
        try {
            List<String> lines = Files.readAllLines(p);
            synchronized (memory) {
                memory.clear();
                for (String line : lines) if (!line.trim().isEmpty()) memory.add(line.trim());
            }
            dirty = false;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 保存约束：请勿直接调用本方法！
     * memory.txt 持久化统一由 AutoSaveHandler 触发。
     */
    public static void save() {
        if (!dirty) return;
        Path p = getPath();
        try {
            Files.createDirectories(p.getParent());
            synchronized (memory) {
                Files.write(p, memory);
                dirty = false;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static Path getPath() {
        return Paths.get("config", "aifriend", "memory.txt");
    }
}