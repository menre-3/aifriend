package com.aifriend.command;

import com.aifriend.entity.AIPartnerEntity;
import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;

import javax.annotation.Nullable;
import java.util.List;

/**
 * 生成AI伙伴命令
 * 用法：/spawnpartner
 * 在玩家当前位置生成一个AI伙伴，绑定该玩家为主人
 */
public class CommandSpawnPartner extends CommandBase {

    @Override
    public String getName() {
        return "spawnpartner";
    }

    @Override
    public String getUsage(ICommandSender sender) {
        return "/spawnpartner - 在你身边生成一个AI伙伴";
    }

    @Override
    public int getRequiredPermissionLevel() {
        return 2; // 需要OP权限
    }

    @Override
    public void execute(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {
        if (!(sender instanceof EntityPlayer)) {
            throw new CommandException("此命令只能由玩家执行");
        }

        EntityPlayer player = (EntityPlayer) sender;
        World world = player.world;

        // 检查是否已经有伙伴
        List<AIPartnerEntity> existing = world.getEntitiesWithinAABB(
                AIPartnerEntity.class,
                player.getEntityBoundingBox().grow(64));
        for (AIPartnerEntity existingPartner : existing) {
            if (existingPartner.getOwnerUUID() != null
                    && existingPartner.getOwnerUUID().equals(player.getUniqueID())) {
                player.sendMessage(new TextComponentString("你已经有一个AI伙伴了！"));
                return;
            }
        }

        // 生成AI伙伴
        AIPartnerEntity partner = new AIPartnerEntity(world);
        partner.setPosition(player.posX, player.posY, player.posZ);
        partner.initialize(player);
        world.spawnEntity(partner);

        player.sendMessage(new TextComponentString("AI伙伴已生成！名字：" + partner.getName()));
    }

    @Override
    public List<String> getTabCompletions(MinecraftServer server, ICommandSender sender,
                                          String[] args, @Nullable BlockPos targetPos) {
        return java.util.Collections.emptyList();
    }
}
