package cn.meng.aifriend.command;

import cn.meng.aifriend.entity.AIPartnerEntity;
import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;

import javax.annotation.Nullable;
import java.util.Collections;
import java.util.List;

/**
 * 生成AI伙伴命令
 */
public class CommandSpawnPartner extends CommandBase {

    @Override public String getName() { return "spawnpartner"; }

    @Override
    public String getUsage(ICommandSender sender) { return "/spawnpartner - 生成AI伙伴"; }

    @Override public int getRequiredPermissionLevel() { return 2; }

    @Override
    public void execute(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {
        if (!(sender instanceof EntityPlayer)) throw new CommandException("此命令只能由玩家执行");
        EntityPlayer player = (EntityPlayer) sender;
        World world = player.world;

        List<AIPartnerEntity> existing = world.getEntitiesWithinAABB(AIPartnerEntity.class, player.getEntityBoundingBox().grow(64));
        for (AIPartnerEntity p : existing) {
            if (p.getOwnerUUID() != null && p.getOwnerUUID().equals(player.getUniqueID())) {
                player.sendMessage(new TextComponentString("你已经有一个AI伙伴了！"));
                return;
            }
        }

        AIPartnerEntity partner = new AIPartnerEntity(world);
        partner.setPosition(player.posX, player.posY, player.posZ);
        partner.initialize(player);
        world.spawnEntity(partner);
        player.sendMessage(new TextComponentString("AI伙伴已生成：" + partner.getName()));
    }

    @Override
    public List<String> getTabCompletions(MinecraftServer server, ICommandSender sender, String[] args, @Nullable BlockPos targetPos) {
        return Collections.emptyList();
    }
}
