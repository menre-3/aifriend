package cn.meng.aifriend;

import net.minecraft.entity.player.EntityPlayer;

public class ContextBuilder {

    private static final int MIN_SEG = 60; // 分段最小下限

    public static String build(EntityPlayer player, float partnerYaw, String... keywords) {
        int max = AIFriendMod.contextMax;

        // 环境段（45%）：环境滤网 + 事件流（事件流归属环境预算）
        String env = cut(
                EnvironmentInfo.getInfo(player, partnerYaw) + WorldEventSource.getRecentEvents(),
                (int) (max * 0.45));

        // 知识段（40%）
        String knowledge = cut(KnowledgeStore.getContext(keywords), (int) (max * 0.40));

        // 记忆段（15%）
        String memory = cut(MemoryManager.getContext(), (int) (max * 0.15));

        StringBuilder sb = new StringBuilder();
        if (!env.isEmpty()) sb.append(env);
        if (!knowledge.isEmpty()) sb.append("\n").append(knowledge);
        if (!memory.isEmpty()) sb.append("\n").append(memory);
        return sb.toString();
    }

    private static String cut(String s, int max) {
        if (s == null || s.isEmpty()) return "";
        if (max < MIN_SEG) max = MIN_SEG; // 下限保护
        if (s.length() <= max) return s;
        int end = max;
        int nl = s.lastIndexOf('\n', max);
        // 换行位置 >=20% 对齐换行（保质量）；太靠前硬切（保数量）
        if (nl >= max * 0.2) end = nl;
        return s.substring(0, end);
    }
}