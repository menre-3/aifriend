package cn.meng.aifriend.lang;

import cn.meng.aifriend.AIFriendConfig;
import cn.meng.aifriend.AIFriendMod;
import cn.meng.aifriend.api.IPartnerBody;
import cn.meng.aifriend.brain.ActionParser;
import cn.meng.aifriend.info.MemoryManager;
import cn.meng.aifriend.info.WorldEventSource;
import cn.meng.aifriend.net.AiApiClient;
import net.minecraftforge.fml.common.Mod;
import org.apache.logging.log4j.Logger;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 事件发言器
 */
@Mod.EventBusSubscriber(modid = AIFriendMod.MOD_ID)
public class EventSpeaker {

    private final AIFriendConfig config;
    private final AiApiClient apiClient;
    private final MemoryManager memory;
    private final SpeakBudget speakBudget;
    private final PromptBuilder promptBuilder;
    private final ActionParser actionParser;
    private final Logger logger;
    private final ExecutorService executor;

    private long lastEventSpeakTick = 0;
    private int playerSneakCount = 0;
    private long lastSneakTick = 0;
    private static final int SNEAK_THRESHOLD = 3;
    private static final long SNEAK_WINDOW = 100;

    public EventSpeaker(AIFriendConfig config, AiApiClient apiClient, MemoryManager memory,
                        SpeakBudget speakBudget, Logger logger) {
        this.config = config;
        this.apiClient = apiClient;
        this.memory = memory;
        this.speakBudget = speakBudget;
        this.logger = logger;
        this.promptBuilder = new PromptBuilder(config);
        this.actionParser = new ActionParser();
        this.executor = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "AI-EventSpeaker");
            t.setDaemon(true);
            return t;
        });
    }

    public void processEvents(List<WorldEventSource.WorldEvent> events, long currentTick, IPartnerBody body) {
        if (events == null || events.isEmpty()) return;
        for (WorldEventSource.WorldEvent event : events) {
            if (!shouldRespond(event, currentTick)) continue;
            if (!speakBudget.canSpeak(currentTick)) continue;
            triggerEventResponse(event, body, currentTick);
            lastEventSpeakTick = currentTick;
            break;
        }
    }

    private boolean shouldRespond(WorldEventSource.WorldEvent event, long currentTick) {
        if (currentTick - lastEventSpeakTick < 200) return false;
        switch (event.type) {
            case DEATH:
            case ACHIEVEMENT:
            case HURT:
                return true;
            case PICKUP:
                return Math.random() < 0.1;
            default:
                return false;
        }
    }

    private void triggerEventResponse(WorldEventSource.WorldEvent event, IPartnerBody body, long tick) {
        CompletableFuture.supplyAsync(() -> {
            try {
                String prompt = promptBuilder.buildEventPrompt(event.description);
                return apiClient.chat(prompt, memory.getRecentDialogue(config.memoryMaxTurns));
            } catch (Exception e) {
                logger.error("事件发言失败: {}", e.getMessage());
                return null;
            }
        }, executor).thenAccept(response -> {
            if (response == null || response.isEmpty()) return;
            ActionParser.ParseResult result = actionParser.parse(response);
            if (result.hasSpeech()) {
                body.speak(result.speechText);
                memory.addAiMessage(result.speechText);
                speakBudget.consume(tick);
            }
        });
    }

    public void onPlayerSneakChange(boolean isSneaking, long currentTick, IPartnerBody body) {
        if (!isSneaking) {
            if (currentTick - lastSneakTick < SNEAK_WINDOW) playerSneakCount++;
            else playerSneakCount = 1;
            lastSneakTick = currentTick;
            if (playerSneakCount >= SNEAK_THRESHOLD && speakBudget.canSpeak(currentTick)) {
                playerSneakCount = 0;
                triggerSneakGreeting(body, currentTick);
            }
        }
    }

    private void triggerSneakGreeting(IPartnerBody body, long tick) {
        CompletableFuture.supplyAsync(() -> {
            try {
                String prompt = promptBuilder.buildEventPrompt("玩家连续蹲起打招呼，你也蹲起回应并说一句话。");
                return apiClient.chat(prompt, memory.getRecentDialogue(config.memoryMaxTurns));
            } catch (Exception e) {
                return null;
            }
        }, executor).thenAccept(response -> {
            if (response == null) return;
            ActionParser.ParseResult result = actionParser.parse(response);
            if (result.hasSpeech()) {
                body.speak(result.speechText);
                memory.addAiMessage(result.speechText);
                speakBudget.consume(tick);
            }
            body.setBodySneaking(true);
            CompletableFuture.runAsync(() -> {
                try {
                    Thread.sleep(400);
                    body.setBodySneaking(false);
                } catch (InterruptedException ignored) {
                }
            }, executor);
        });
    }

    public void checkSunset(long currentTick, boolean playerIdle, IPartnerBody body) {
        long timeOfDay = currentTick % 24000;
        if (timeOfDay >= 12000 && timeOfDay <= 13000 && playerIdle) {
            if (currentTick - lastEventSpeakTick > 6000 && speakBudget.canSpeak(currentTick)) {
                triggerSunsetComment(body, currentTick);
                lastEventSpeakTick = currentTick;
            }
        }
    }

    private void triggerSunsetComment(IPartnerBody body, long tick) {
        CompletableFuture.supplyAsync(() -> {
            try {
                String prompt = promptBuilder.buildEventPrompt("太阳正在落山，玩家停下来看夕阳，你也一起看并感慨一句。");
                return apiClient.chat(prompt, memory.getRecentDialogue(config.memoryMaxTurns));
            } catch (Exception e) {
                return null;
            }
        }, executor).thenAccept(response -> {
            if (response == null) return;
            ActionParser.ParseResult result = actionParser.parse(response);
            if (result.hasSpeech()) {
                body.speak(result.speechText);
                memory.addAiMessage(result.speechText);
                speakBudget.consume(tick);
            }
            body.getMovement().stopMoving();
        });
    }

    public void shutdown() {
        executor.shutdownNow();
    }
}
