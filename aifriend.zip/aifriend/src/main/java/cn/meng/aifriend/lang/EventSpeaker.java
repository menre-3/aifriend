package com.aifriend.lang;

import com.aifriend.AIFriendConfig;
import com.aifriend.brain.ActionParser;
import com.aifriend.info.MemoryManager;
import com.aifriend.info.WorldEventSource;
import com.aifriend.net.AiApiClient;
import org.apache.logging.log4j.Logger;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 事件发言器（语言层）
 * 监听世界事件，在合适的时机让AI主动发言
 *
 * 触发场景：
 * - 玩家死亡（安慰/惊讶）
 * - 玩家获得成就（祝贺）
 * - 玩家受伤（关心）
 * - 玩家连续蹲起（回应蹲起打招呼）
 * - 傍晚/看夕阳（感慨）
 * - 遇到危险（警告）
 *
 * 所有主动发言都受 SpeakBudget 控制
 */
public class EventSpeaker {

    private final AIFriendConfig config;
    private final AiApiClient apiClient;
    private final MemoryManager memory;
    private final SpeakBudget speakBudget;
    private final PromptBuilder promptBuilder;
    private final ActionParser actionParser;
    private final Logger logger;

    private final ExecutorService executor = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "AI-EventSpeaker");
        t.setDaemon(true);
        return t;
    });

    // 蹲起检测
    private int playerSneakCount = 0;
    private long lastSneakTick = 0;
    private static final int SNEAK_THRESHOLD = 3; // 连续蹲起3次触发回应
    private static final long SNEAK_WINDOW = 100; // 5秒内的蹲起算连续

    // 上次发言时间
    private long lastEventSpeakTick = 0;

    public EventSpeaker(AIFriendConfig config, AiApiClient apiClient,
                        MemoryManager memory, SpeakBudget speakBudget, Logger logger) {
        this.config = config;
        this.apiClient = apiClient;
        this.memory = memory;
        this.speakBudget = speakBudget;
        this.promptBuilder = new PromptBuilder(config);
        this.actionParser = new ActionParser();
        this.logger = logger;
    }

    /**
     * 处理世界事件
     * @param events 事件列表
     * @param currentTick 当前tick
     * @param body 身体接口（用于执行动作）
     */
    public void processEvents(List<WorldEventSource.WorldEvent> events, long currentTick,
                              com.aifriend.api.IPartnerBody body) {
        if (events == null || events.isEmpty()) return;

        for (WorldEventSource.WorldEvent event : events) {
            // 检查是否应该回应此事件
            if (!shouldRespond(event, currentTick)) continue;

            // 检查发言预算
            if (!speakBudget.canSpeak(currentTick)) continue;

            // 异步生成回复
            triggerEventResponse(event, body);
            lastEventSpeakTick = currentTick;
            break; // 每次只处理一个事件，避免连续说话
        }
    }

    /**
     * 判断是否应该回应此事件
     */
    private boolean shouldRespond(WorldEventSource.WorldEvent event, long currentTick) {
        // 事件冷却：两次主动发言至少间隔一段时间
        if (currentTick - lastEventSpeakTick < 200) return false; // 10秒

        switch (event.type) {
            case DEATH:
            case ACHIEVEMENT:
            case HURT:
                return true; // 这些事件总是回应
            case KILL:
                return Math.random() < 0.3; // 30%概率评论击杀
            case PICKUP:
                return Math.random() < 0.1; // 10%概率评论拾取
            case SNEAK:
                return false; // 蹲起由专门的检测处理
            default:
                return false;
        }
    }

    /**
     * 触发事件回复
     */
    private void triggerEventResponse(WorldEventSource.WorldEvent event,
                                      com.aifriend.api.IPartnerBody body) {
        CompletableFuture.supplyAsync(() -> {
            try {
                String prompt = promptBuilder.buildEventPrompt(event.description);
                return apiClient.chat(prompt, memory.getRecentDialogue(config.getMemoryMaxTurns()));
            } catch (Exception e) {
                logger.error("事件发言失败: {}", e.getMessage());
                return null;
            }
        }, executor).thenAccept(response -> {
            if (response == null || response.isEmpty()) return;

            ActionParser.ParseResult result = actionParser.parse(response);
            if (result.hasSpeech()) {
                body.speak(result.speechText);
                memory.addAiMessage(result.speechText);
                speakBudget.consume();
            }
            // 事件触发的动作可以执行（如蹲起回应）
            if (result.hasActions()) {
                for (ActionParser.ActionIntent intent : result.actions) {
                    try {
                        executeEventAction(intent, body);
                    } catch (Exception e) {
                        logger.error("事件动作执行失败: {}", e.getMessage());
                    }
                }
            }
        });
    }

    private void executeEventAction(ActionParser.ActionIntent intent,
                                    com.aifriend.api.IPartnerBody body) {
        switch (intent.action) {
            case "sneak":
                // 连续蹲起回应
                body.setSneaking(true);
                CompletableFuture.runAsync(() -> {
                    try {
                        Thread.sleep(300);
                        body.setSneaking(false);
                        Thread.sleep(200);
                        body.setSneaking(true);
                        Thread.sleep(300);
                        body.setSneaking(false);
                    } catch (InterruptedException ignored) {
                    }
                }, executor);
                break;
            case "jump":
                body.jump();
                break;
            default:
                // 其他动作不执行（事件触发只做简单反应）
                break;
        }
    }

    /**
     * 玩家蹲起检测（连续蹲起触发打招呼）
     * @param isSneaking 玩家当前是否蹲着
     * @param currentTick 当前tick
     * @param body 身体接口
     */
    public void onPlayerSneakChange(boolean isSneaking, long currentTick,
                                    com.aifriend.api.IPartnerBody body) {
        // 检测蹲下起立的边沿
        if (!isSneaking) {
            // 刚站起来
            if (currentTick - lastSneakTick < SNEAK_WINDOW) {
                playerSneakCount++;
            } else {
                playerSneakCount = 1;
            }
            lastSneakTick = currentTick;

            if (playerSneakCount >= SNEAK_THRESHOLD && speakBudget.canSpeak(currentTick)) {
                playerSneakCount = 0;
                triggerSneakGreeting(body);
            }
        }
    }

    private void triggerSneakGreeting(com.aifriend.api.IPartnerBody body) {
        CompletableFuture.supplyAsync(() -> {
            try {
                String prompt = promptBuilder.buildEventPrompt("玩家连续蹲起向你打招呼，你也蹲起回应，并说一句打招呼的话。");
                return apiClient.chat(prompt, memory.getRecentDialogue(config.getMemoryMaxTurns()));
            } catch (Exception e) {
                logger.error("蹲起打招呼失败: {}", e.getMessage());
                return null;
            }
        }, executor).thenAccept(response -> {
            if (response == null) return;
            ActionParser.ParseResult result = actionParser.parse(response);
            if (result.hasSpeech()) {
                body.speak(result.speechText);
                memory.addAiMessage(result.speechText);
                speakBudget.consume();
            }
            // 蹲起回应
            body.setSneaking(true);
            CompletableFuture.runAsync(() -> {
                try {
                    Thread.sleep(400);
                    body.setSneaking(false);
                } catch (InterruptedException ignored) {
                }
            }, executor);
        });
    }

    /**
     * 看夕阳检测（傍晚+玩家静止）
     */
    public void checkSunset(long currentTick, boolean playerIsIdle,
                            com.aifriend.api.IPartnerBody body) {
        long timeOfDay = currentTick % 24000;
        // 傍晚：12000-13000（日落开始）
        if (timeOfDay >= 12000 && timeOfDay <= 13000 && playerIsIdle) {
            if (currentTick - lastEventSpeakTick > 6000) { // 至少5分钟间隔
                if (speakBudget.canSpeak(currentTick)) {
                    triggerSunsetComment(body);
                    lastEventSpeakTick = currentTick;
                }
            }
        }
    }

    private void triggerSunsetComment(com.aifriend.api.IPartnerBody body) {
        CompletableFuture.supplyAsync(() -> {
            try {
                String prompt = promptBuilder.buildEventPrompt("太阳正在落山，夕阳很美。玩家停下来看夕阳，你也停下来一起看，并感慨一句。");
                return apiClient.chat(prompt, memory.getRecentDialogue(config.getMemoryMaxTurns()));
            } catch (Exception e) {
                return null;
            }
        }, executor).thenAccept(response -> {
            if (response == null) return;
            ActionParser.ParseResult result = actionParser.parse(response);
            if (result.hasSpeech()) {
                body.speak(result.speechText);
                memory.addAiMessage(result.speechText);
                speakBudget.consume();
            }
            body.getMovement().stop();
        });
    }

    public void shutdown() {
        executor.shutdownNow();
    }
}
