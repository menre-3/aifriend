package cn.meng.aifriend;

import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.server.MinecraftServer;

public class CommandSpawnPartner extends CommandBase {

    @Override
    public String getName() { return "spawnpartner"; }

    @Override
    public String getUsage(ICommandSender sender) { return "/spawnpartner"; }

    @Override
    public void execute(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {
        EntityPlayer player = getCommandSenderAsPlayer(sender);
        AIPartnerEntity partner = new AIPartnerEntity(player.world);
        partner.setPosition(player.posX, player.posY, player.posZ);
        player.world.spawnEntity(partner);
    }
}