package cn.meng.aifriend;

import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.text.TextComponentString;

import java.util.List;

public class CommandSpawnPartner extends CommandBase {

    @Override
    public String getName() { return "spawnpartner"; }

    @Override
    public String getUsage(ICommandSender sender) { return "/spawnpartner"; }

    @Override
    public void execute(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {
        EntityPlayer player = getCommandSenderAsPlayer(sender);

        // 全局单伙伴：已有则提示，不重复生成
        List<AIPartnerEntity> existing = player.world.getEntities(AIPartnerEntity.class, e -> true);
        if (!existing.isEmpty()) {
            player.sendMessage(new TextComponentString("已有伙伴存在，无需重复召唤"));
            return;
        }

        AIPartnerEntity partner = new AIPartnerEntity(player.world);
        partner.setOwnerUUID(player.getUniqueID());
        partner.setBrain(new AIBrain(partner));
        partner.setPosition(player.posX, player.posY, player.posZ);
        partner.markSpawnPos();

        // 头顶显示名字（像玩家）
        partner.setCustomNameTag(AIFriendMod.partnerName);
        partner.setAlwaysRenderNameTag(true);

        player.world.spawnEntity(partner);

        // 广播加入游戏（黄色）
        if (server != null) {
            server.getPlayerList().sendMessage(
                    new TextComponentString("\u00A7e" + AIFriendMod.partnerName + " 加入了游戏"));
        }
    }
}