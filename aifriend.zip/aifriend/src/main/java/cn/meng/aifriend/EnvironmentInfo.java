package cn.meng.aifriend;

import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.List;

public class EnvironmentInfo {

    public static String getInfo(EntityPlayer player, float partnerYaw) {
        World world = player.world;
        StringBuilder sb = new StringBuilder();
        sb.append("【环境】").append(player.getName())
          .append(" 血量").append((int) player.getHealth()).append("/").append((int) player.getMaxHealth())
          .append(" 饥饿").append((int) player.getFoodStats().getFoodLevel()).append("/20")
          .append(" 手持").append(player.getHeldItemMainhand().getDisplayName())
          .append(" 高度").append((int) player.posY)
          .append(" ").append(world.provider.getDimensionType().getName())
          .append(" ").append(world.isDaytime() ? "白天" : "夜晚")
          .append(" ").append(world.isRaining() ? (world.isThundering() ? "雷雨" : "下雨") : "晴")
          .append("。\n");

        EnumFacing facing = player.getHorizontalFacing();
        sb.append("玩家面向:").append(facing.getName())
          .append("；伙伴面向:").append(yawToFacing(partnerYaw))
          .append("（坐标: 北=-Z, 南=+Z, 西=-X, 东=+X）\n");

        List<Entity> entities = world.getEntitiesWithinAABB(Entity.class,
                player.getEntityBoundingBox().grow(12), e -> e != player);
        List<String> hostile = new ArrayList<>();
        List<String> animals = new ArrayList<>();
        for (Entity e : entities) {
            if (e instanceof EntityPlayer) continue;
            if (e instanceof EntityMob) hostile.add(e.getName() + "(" + (int) e.getDistance(player) + "格)");
            else if (e instanceof EntityAnimal) animals.add(e.getName());
        }
        if (!hostile.isEmpty()) sb.append("危险生物: ").append(String.join(",", hostile)).append("\n");
        if (!animals.isEmpty()) sb.append("动物: ").append(String.join(",", animals)).append("\n");

        sb.append("重要方块(滤网后): ");
        List<String> blocks = scanBlocks(world, player.getPosition(), 12);
        sb.append(blocks.isEmpty() ? "无" : String.join(";", blocks)).append("\n");
        return sb.toString();
    }

    private static String yawToFacing(float yaw) {
        float y = ((yaw % 360) + 360) % 360;
        if (y < 45 || y >= 315) return "南";
        if (y < 135) return "西";
        if (y < 225) return "北";
        return "东";
    }

    private static List<String> scanBlocks(World world, BlockPos center, int radius) {
        List<String> found = new ArrayList<>();
        for (int dx = -radius; dx <= radius; dx++)
            for (int dy = -2; dy <= 2; dy++)
                for (int dz = -radius; dz <= radius; dz++) {
                    Block b = world.getBlockState(center.add(dx, dy, dz)).getBlock();
                    String name = classify(b);
                    if (name != null) {
                        int dist = Math.max(Math.abs(dx), Math.abs(dz));
                        if (dist <= 6) {
                            found.add(name + "(近," + dx + "," + dy + "," + dz + ")");
                        } else if (dist <= 12) {
                            found.add(name + "(" + dirName(dx, dz) + "约" + dist + "格)");
                        }
                        // 超过12格：拦截，不告诉 AI
                    }
                }
        return found;
    }

    private static String dirName(int dx, int dz) {
        StringBuilder dir = new StringBuilder();
        if (dz < 0) dir.append("北");
        if (dz > 0) dir.append("南");
        if (dx < 0) dir.append("西");
        if (dx > 0) dir.append("东");
        return dir.length() == 0 ? "附近" : dir.toString();
    }

    private static String classify(Block b) {
        if (b == Blocks.DIAMOND_ORE || b == Blocks.LAPIS_ORE) return "钻石矿";
        if (b == Blocks.GOLD_ORE) return "金矿";
        if (b == Blocks.IRON_ORE) return "铁矿";
        if (b == Blocks.COAL_ORE) return "煤矿";
        if (b == Blocks.LAVA || b == Blocks.FLOWING_LAVA) return "岩浆";
        if (b == Blocks.WATER || b == Blocks.FLOWING_WATER) return "水";
        if (b == Blocks.TNT) return "TNT";
        if (b == Blocks.MOB_SPAWNER) return "刷怪笼";
        return null;
    }
}