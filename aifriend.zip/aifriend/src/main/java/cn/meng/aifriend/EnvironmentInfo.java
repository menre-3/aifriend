package cn.meng.aifriend;

import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.List;

public class EnvironmentInfo {

    private static final int RADIUS = 8;

    public static String getInfo(EntityPlayer player) {
        World world = player.world;
        StringBuilder sb = new StringBuilder();

        sb.append("【环境】").append(player.getName())
          .append(" 血量").append((int) player.getHealth()).append("/").append((int) player.getMaxHealth())
          .append(" 饥饿").append((int) player.getFoodStats().getFoodLevel()).append("/20")
          .append(" 手持").append(player.getHeldItemMainhand().getDisplayName())
          .append(" 高度").append((int) player.posY)
          .append(" ").append(world.provider.getDimensionType().getName())
          .append(" ").append(world.isDaytime() ? "白天" : "夜晚")
          .append(" ").append(world.isRaining() ? (world.isThundering() ? "雷雨" : "下雨") : "晴")
          .append("。\n");

        EnumFacing facing = player.getHorizontalFacing();
        sb.append("玩家面向:").append(facing.getName())
          .append("（坐标: 北=-Z, 南=+Z, 西=-X, 东=+X; 正前方=面向方向）\n");

        List<Entity> entities = world.getEntitiesWithinAABB(Entity.class,
                player.getEntityBoundingBox().grow(RADIUS), e -> e != player);
        List<String> hostile = new ArrayList<>();
        List<String> animals = new ArrayList<>();
        for (Entity e : entities) {
            if (e instanceof EntityPlayer) continue;
            if (e instanceof EntityMob) {
                hostile.add(e.getName() + "(" + (int) e.getDistanceToEntity(player) + "格)");
            } else if (e instanceof EntityAnimal) {
                animals.add(e.getName());
            }
        }
        if (!hostile.isEmpty()) sb.append("危险生物: ").append(String.join(",", hostile)).append("\n");
        if (!animals.isEmpty()) sb.append("动物: ").append(String.join(",", animals)).append("\n");

        sb.append("重要方块: ");
        List<String> blocks = scanBlocks(world, player.getPosition());
        sb.append(blocks.isEmpty() ? "无" : String.join(",", blocks)).append("\n");
        return sb.toString();
    }

    private static List<String> scanBlocks(World world, BlockPos center) {
        List<String> found = new ArrayList<>();
        for (int dx = -RADIUS; dx <= RADIUS; dx++)
            for (int dy = -2; dy <= 2; dy++)
                for (int dz = -RADIUS; dz <= RADIUS; dz++) {
                    Block b = world.getBlockState(center.add(dx, dy, dz)).getBlock();
                    String key = classify(b);
                    if (key != null && !found.contains(key)) found.add(key);
                }
        return found;
    }

    private static String classify(Block b) {
        if (b == Blocks.DIAMOND_ORE || b == Blocks.LAPIS_ORE) return "钻石矿";
        if (b == Blocks.GOLD_ORE) return "金矿";
        if (b == Blocks.IRON_ORE) return "铁矿";
        if (b == Blocks.COAL_ORE) return "煤矿";
        if (b == Blocks.LAVA || b == Blocks.FLOWING_LAVA) return "岩浆";
        if (b == Blocks.WATER || b == Blocks.FLOWING_WATER) return "水";
        if (b == Blocks.TNT) return "TNT";
        if (b == Blocks.MOB_SPAWNER) return "刷怪笼";
        if (b == Blocks.CHEST) return "箱子";
        return null;
    }
}