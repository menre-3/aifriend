package cn.meng.aifriend.info;

import org.apache.logging.log4j.Logger;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * 知识库：外置说明书 + 自动学习
 */
public class KnowledgeStore {

    private final File knowledgeDir;
    private final Logger logger;
    private final Map<String, String> externalKnowledge = new HashMap<>();
    private final Map<String, String> learnedKnowledge = new HashMap<>();
    private final Set<String> knownRegistries = new java.util.HashSet<>();

    public KnowledgeStore(File configDir, Logger logger) {
        this.knowledgeDir = new File(configDir, "aifriend/knowledge");
        this.logger = logger;
        if (!knowledgeDir.exists()) knowledgeDir.mkdirs();
    }

    public void loadAll() {
        externalKnowledge.clear();
        if (!knowledgeDir.isDirectory()) return;
        File[] files = knowledgeDir.listFiles((dir, name) -> name.endsWith(".txt") || name.endsWith(".md"));
        if (files == null) return;
        for (File file : files) {
            try {
                String topic = file.getName().replaceAll("\\.(txt|md)$", "");
                String content = new String(Files.readAllBytes(file.toPath()), StandardCharsets.UTF_8);
                externalKnowledge.put(topic, content);
            } catch (IOException e) {
                logger.error("读取知识库失败 {}: {}", file.getName(), e.getMessage());
            }
        }
        logger.info("知识库加载完成，共 {} 个主题", externalKnowledge.size());
    }

    public String retrieve(String... keywords) {
        StringBuilder result = new StringBuilder();
        for (String keyword : keywords) {
            if (keyword == null || keyword.isEmpty()) continue;
            String lower = keyword.toLowerCase();
            for (Map.Entry<String, String> entry : externalKnowledge.entrySet()) {
                if (entry.getKey().toLowerCase().contains(lower) || entry.getValue().toLowerCase().contains(lower)) {
                    result.append("【").append(entry.getKey()).append("】\n")
                            .append(truncate(entry.getValue(), 500)).append("\n\n");
                }
            }
            for (Map.Entry<String, String> entry : learnedKnowledge.entrySet()) {
                if (entry.getKey().toLowerCase().contains(lower) || entry.getValue().toLowerCase().contains(lower)) {
                    result.append("【学习-").append(entry.getKey()).append("】\n")
                            .append(truncate(entry.getValue(), 300)).append("\n\n");
                }
            }
        }
        return result.toString();
    }

    public void learn(String topic, String content) {
        if (knownRegistries.contains(topic)) return;
        knownRegistries.add(topic);
        learnedKnowledge.put(topic, content);
    }

    public boolean isKnown(String topic) {
        return knownRegistries.contains(topic) || externalKnowledge.containsKey(topic) || learnedKnowledge.containsKey(topic);
    }

    public String buildSummary() {
        if (externalKnowledge.isEmpty() && learnedKnowledge.isEmpty()) return "【知识库】暂无";
        StringBuilder sb = new StringBuilder("【知识库】\n");
        if (!externalKnowledge.isEmpty())
            sb.append("外置(").append(externalKnowledge.size()).append(")：").append(String.join(", ", externalKnowledge.keySet())).append("\n");
        if (!learnedKnowledge.isEmpty())
            sb.append("学习(").append(learnedKnowledge.size()).append(")：").append(String.join(", ", learnedKnowledge.keySet())).append("\n");
        return sb.toString();
    }

    private String truncate(String s, int max) {
        return s.length() <= max ? s : s.substring(0, max) + "...";
    }
}
