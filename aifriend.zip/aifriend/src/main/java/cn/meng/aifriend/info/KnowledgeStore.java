package com.aifriend.info;

import org.apache.logging.log4j.Logger;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * 知识库模块
 * 支持两种知识来源：
 * 1) 外置知识库：玩家在 config/aifriend/knowledge/ 目录下写 .txt 或 .md 文件，
 *    作为第三方模组说明书、玩法规则等
 * 2) 自动学习：AI在游戏过程中发现新物品/方块/机制时，自动记录到知识库
 *
 * 知识库以"主题->内容"的形式组织，AI决策时可检索相关主题
 */
public class KnowledgeStore {

    private final File knowledgeDir;
    private final Logger logger;

    // 外置知识库：主题名 -> 内容
    private final Map<String, String> externalKnowledge = new HashMap<>();

    // 自动学习知识库：主题名 -> 内容
    private final Map<String, String> learnedKnowledge = new HashMap<>();

    // 已知物品/方块注册表（用于自动学习去重）
    private final Set<String> knownRegistries = new java.util.HashSet<>();

    public KnowledgeStore(File configDir, Logger logger) {
        this.knowledgeDir = new File(configDir, "aifriend/knowledge");
        this.logger = logger;
        if (!knowledgeDir.exists()) {
            knowledgeDir.mkdirs();
            // 创建示例文件
            createExampleFile();
        }
    }

    private void createExampleFile() {
        File example = new File(knowledgeDir, "README.txt");
        try {
            String content = "AI Friend 知识库说明\n" +
                    "====================\n" +
                    "在此目录下放置 .txt 或 .md 文件，每个文件是一个知识主题。\n" +
                    "文件名（不含扩展名）将作为主题名，文件内容将被AI读取。\n\n" +
                    "示例：\n" +
                    "  - tconstruct.txt  -> 匠魂模组说明\n" +
                    "  - thermal_expansion.md -> 热力膨胀说明\n" +
                    "  - server_rules.txt -> 服务器规则\n\n" +
                    "AI在决策时会根据当前场景检索相关知识。\n";
            Files.write(example.toPath(), content.getBytes(StandardCharsets.UTF_8));
        } catch (IOException e) {
            logger.warn("创建知识库示例文件失败: {}", e.getMessage());
        }
    }

    /**
     * 加载所有外置知识库文件
     */
    public void loadAll() {
        externalKnowledge.clear();
        if (!knowledgeDir.exists() || !knowledgeDir.isDirectory()) {
            logger.warn("知识库目录不存在: {}", knowledgeDir.getPath());
            return;
        }
        File[] files = knowledgeDir.listFiles((dir, name) ->
                name.endsWith(".txt") || name.endsWith(".md"));
        if (files == null) return;

        for (File file : files) {
            try {
                String topic = file.getName().replaceAll("\\.(txt|md)$", "");
                String content = new String(Files.readAllBytes(file.toPath()), StandardCharsets.UTF_8);
                externalKnowledge.put(topic, content);
                logger.info("加载知识库: {} ({}字符)", topic, content.length());
            } catch (IOException e) {
                logger.error("读取知识库文件失败 {}: {}", file.getName(), e.getMessage());
            }
        }
        logger.info("知识库加载完成，共 {} 个主题", externalKnowledge.size());
    }

    /**
     * 根据关键词检索相关知识
     * @param keywords 关键词数组
     * @return 匹配的知识内容（拼接）
     */
    public String retrieve(String... keywords) {
        StringBuilder result = new StringBuilder();
        for (String keyword : keywords) {
            if (keyword == null || keyword.isEmpty()) continue;
            String lower = keyword.toLowerCase();
            // 搜索外置知识
            for (Map.Entry<String, String> entry : externalKnowledge.entrySet()) {
                if (entry.getKey().toLowerCase().contains(lower)
                        || entry.getValue().toLowerCase().contains(lower)) {
                    result.append("【").append(entry.getKey()).append("】\n")
                            .append(truncate(entry.getValue(), 500)).append("\n\n");
                }
            }
            // 搜索学习知识
            for (Map.Entry<String, String> entry : learnedKnowledge.entrySet()) {
                if (entry.getKey().toLowerCase().contains(lower)
                        || entry.getValue().toLowerCase().contains(lower)) {
                    result.append("【学习-").append(entry.getKey()).append("】\n")
                            .append(truncate(entry.getValue(), 300)).append("\n\n");
                }
            }
        }
        return result.toString();
    }

    /**
     * 获取所有外置知识主题名
     */
    public Set<String> getTopics() {
        return externalKnowledge.keySet();
    }

    /**
     * 自动学习：记录新发现的物品/方块/机制
     * @param topic 主题（如 "item:minecraft:diamond"）
     * @param content 学到的内容
     */
    public void learn(String topic, String content) {
        if (knownRegistries.contains(topic)) return;
        knownRegistries.add(topic);
        learnedKnowledge.put(topic, content);
        logger.debug("AI学习新知识: {} -> {}", topic, content);
    }

    /**
     * 检查是否已知某主题
     */
    public boolean isKnown(String topic) {
        return knownRegistries.contains(topic)
                || externalKnowledge.containsKey(topic)
                || learnedKnowledge.containsKey(topic);
    }

    /**
     * 生成知识库摘要（用于AI上下文）
     */
    public String buildSummary() {
        if (externalKnowledge.isEmpty() && learnedKnowledge.isEmpty()) {
            return "【知识库】暂无已加载知识";
        }
        StringBuilder sb = new StringBuilder("【知识库】\n");
        if (!externalKnowledge.isEmpty()) {
            sb.append("外置知识(").append(externalKnowledge.size()).append("个主题)：");
            sb.append(String.join(", ", externalKnowledge.keySet())).append("\n");
        }
        if (!learnedKnowledge.isEmpty()) {
            sb.append("自动学习(").append(learnedKnowledge.size()).append("条)：");
            sb.append(String.join(", ", learnedKnowledge.keySet())).append("\n");
        }
        return sb.toString();
    }

    private String truncate(String s, int maxLen) {
        if (s.length() <= maxLen) return s;
        return s.substring(0, maxLen) + "...";
    }
}
