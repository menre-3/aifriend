package cn.meng.aifriend.goal;

import cn.meng.aifriend.api.IPartnerBody;
import org.apache.logging.log4j.Logger;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * 目标注册表
 */
public class GoalRegistry {

    private final List<IGoal> goals = new ArrayList<>();
    private IGoal currentGoal;
    private final Logger logger;

    public GoalRegistry(Logger logger) {
        this.logger = logger;
    }

    public void registerGoal(IGoal goal) {
        goals.add(goal);
        goals.sort(Comparator.comparingInt(IGoal::getPriority));
        logger.info("注册目标: {} (P{})", goal.getName(), goal.getPriority());
    }

    public void tick(IPartnerBody body) {
        for (IGoal goal : goals) {
            if (goal == currentGoal) continue;
            if (goal.shouldStart(body)) {
                if (currentGoal == null || goal.getPriority() < currentGoal.getPriority()) {
                    switchTo(goal, body);
                    break;
                }
            }
        }
        if (currentGoal != null) {
            if (!currentGoal.update(body)) {
                currentGoal.stop(body);
                logger.debug("目标完成: {}", currentGoal.getName());
                currentGoal = null;
            }
        }
    }

    private void switchTo(IGoal newGoal, IPartnerBody body) {
        if (currentGoal != null) currentGoal.stop(body);
        currentGoal = newGoal;
        newGoal.start(body);
    }

    public void forceGoal(IGoal goal, IPartnerBody body) {
        if (currentGoal != null) currentGoal.stop(body);
        currentGoal = goal;
        goal.start(body);
    }

    public void stopCurrent(IPartnerBody body) {
        if (currentGoal != null) {
            currentGoal.stop(body);
            currentGoal = null;
        }
    }

    public IGoal getCurrentGoal() { return currentGoal; }

    public String buildSummary() {
        StringBuilder sb = new StringBuilder("【目标】");
        if (currentGoal != null) sb.append("当前：").append(currentGoal.getName()).append(" - ").append(currentGoal.getDescription());
        else sb.append("当前：空闲");
        return sb.toString();
    }
}
