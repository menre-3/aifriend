package com.aifriend.goal;

import com.aifriend.api.IPartnerBody;
import org.apache.logging.log4j.Logger;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * 目标注册表（任务层核心）
 * 管理所有可用目标，按优先级调度执行
 *
 * 调度规则：
 * 1. 每tick检查所有目标，找出应该开始的目标
 * 2. 如果有更高优先级的目标，打断当前目标
 * 3. 同一时间只执行一个目标
 * 4. 目标完成后自动选择下一个
 */
public class GoalRegistry {

    private final List<IGoal> goals = new ArrayList<>();
    private IGoal currentGoal;
    private final Logger logger;

    public GoalRegistry(Logger logger) {
        this.logger = logger;
    }

    /**
     * 注册目标
     */
    public void registerGoal(IGoal goal) {
        goals.add(goal);
        // 按优先级排序（数字小的在前）
        goals.sort(Comparator.comparingInt(IGoal::getPriority));
        logger.info("注册目标: {} (优先级={})", goal.getName(), goal.getPriority());
    }

    /**
     * 每tick更新目标系统
     */
    public void tick(IPartnerBody body) {
        // 检查是否有更高优先级的目标应该开始
        for (IGoal goal : goals) {
            if (goal == currentGoal) continue;
            if (goal.shouldStart(body)) {
                // 如果当前有目标且优先级更低，打断它
                if (currentGoal == null || goal.getPriority() < currentGoal.getPriority()) {
                    switchToGoal(goal, body);
                    break;
                }
            }
        }

        // 更新当前目标
        if (currentGoal != null) {
            boolean continueGoal = currentGoal.update(body);
            if (!continueGoal) {
                currentGoal.stop(body);
                logger.debug("目标完成: {}", currentGoal.getName());
                currentGoal = null;
            }
        }
    }

    /**
     * 切换到新目标
     */
    private void switchToGoal(IGoal newGoal, IPartnerBody body) {
        if (currentGoal != null) {
            currentGoal.stop(body);
            logger.debug("打断目标: {}，切换到: {}", currentGoal.getName(), newGoal.getName());
        }
        currentGoal = newGoal;
        newGoal.start(body);
        logger.debug("开始目标: {}", newGoal.getName());
    }

    /**
     * 强制设置当前目标（如玩家指令）
     */
    public void forceGoal(IGoal goal, IPartnerBody body) {
        if (currentGoal != null) {
            currentGoal.stop(body);
        }
        currentGoal = goal;
        goal.start(body);
    }

    /**
     * 停止当前目标
     */
    public void stopCurrent(IPartnerBody body) {
        if (currentGoal != null) {
            currentGoal.stop(body);
            currentGoal = null;
        }
    }

    /**
     * 获取当前目标
     */
    public IGoal getCurrentGoal() {
        return currentGoal;
    }

    /**
     * 获取所有已注册目标
     */
    public List<IGoal> getAllGoals() {
        return new ArrayList<>(goals);
    }

    /**
     * 生成目标状态摘要（用于AI上下文）
     */
    public String buildSummary() {
        StringBuilder sb = new StringBuilder("【目标系统】\n");
        if (currentGoal != null) {
            sb.append("当前目标：").append(currentGoal.getName())
                    .append(" - ").append(currentGoal.getDescription()).append("\n");
        } else {
            sb.append("当前目标：无（空闲）\n");
        }
        sb.append("可用目标：");
        for (int i = 0; i < goals.size(); i++) {
            if (i > 0) sb.append(", ");
            sb.append(goals.get(i).getName()).append("(P").append(goals.get(i).getPriority()).append(")");
        }
        return sb.toString();
    }
}
