package cn.meng.aifriend.client;

import cn.meng.aifriend.AIPartnerEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.nio.file.Paths;

@SideOnly(Side.CLIENT)
public class RenderAIPartner extends RenderLiving<AIPartnerEntity> {

    private static final ResourceLocation DEFAULT_SKIN = new ResourceLocation("minecraft", "textures/entity/steve.png");
    private static ResourceLocation customSkin = null;

    public RenderAIPartner(RenderManager renderManager) {
        super(renderManager, new ModelBiped(0.0F), 0.5F);
    }

    @Override
    protected ResourceLocation getEntityTexture(AIPartnerEntity entity) {
        return getSkin();
    }

    private static ResourceLocation getSkin() {
        if (customSkin != null) return customSkin;
        try {
            File f = Paths.get("config", "aifriend", "skin", "partner.png").toFile();
            if (f.exists()) {
                BufferedImage img = ImageIO.read(f);
                if (img != null) {
                    DynamicTexture tex = new DynamicTexture(img);
                    customSkin = Minecraft.getMinecraft().getTextureManager()
                            .getDynamicTextureLocation("aifriend_partner", tex);
                    return customSkin;
                }
            }
        } catch (Exception ignored) {}
        return DEFAULT_SKIN;
    }
}