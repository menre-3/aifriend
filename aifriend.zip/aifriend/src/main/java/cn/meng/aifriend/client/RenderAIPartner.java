package cn.meng.aifriend.client;

import cn.meng.aifriend.AIPartnerEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelPlayer;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;

@SideOnly(Side.CLIENT)
public class RenderAIPartner extends RenderLiving<AIPartnerEntity> {

    private static final ResourceLocation DEFAULT_SKIN =
            new ResourceLocation("minecraft", "textures/entity/steve.png");
    private static ResourceLocation customSkin = null;

    public RenderAIPartner(RenderManager renderManager) {
        super(renderManager, new ModelPlayer(0.0F, false), 0.5F);
    }

    @Override
    protected ResourceLocation getEntityTexture(AIPartnerEntity entity) {
        return getSkin();
    }

    private static ResourceLocation getSkin() {
        if (customSkin != null) return customSkin;
        try {
            File f = new File(Minecraft.getMinecraft().mcDataDir,
                    "config/aifriend/skin/partner.png");
            if (f.exists()) {
                BufferedImage img = ImageIO.read(f);
                if (img != null) {
                    DynamicTexture tex = new DynamicTexture(img);
                    customSkin = Minecraft.getMinecraft().getTextureManager()
                            .getDynamicTextureLocation("aifriend_partner", tex);
                    return customSkin;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return DEFAULT_SKIN;
    }
}