package cn.meng.aifriend.client;

import cn.meng.aifriend.AIFriendMod;
import cn.meng.aifriend.entity.AIPartnerEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelPlayer;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;

public class RenderAIPartner extends RenderLiving<AIPartnerEntity> {

    private static ResourceLocation partnerTexture;
    private static boolean textureLoadFailed = false;

    // false = Steve粗手臂；true = Alex细手臂
    private static final ModelPlayer MODEL = new ModelPlayer(false);

    public RenderAIPartner(RenderManager rendermanagerIn) {
        // ✅ 关键：把ModelPlayer传给super，绝对不能传null！
        super(rendermanagerIn, MODEL, 0.5F);
        this.mainModel = MODEL;
    }

    public static void loadCustomSkin() {
        File skinFile = new File(Minecraft.getMinecraft().gameDir, "config/aifriend/skin/partner.png");
        textureLoadFailed = false;
        if (!skinFile.exists()) {
            textureLoadFailed = true;
            return;
        }
        try {
            DynamicTexture dynTex = new DynamicTexture(ImageIO.read(skinFile));
            partnerTexture = Minecraft.getMinecraft().getTextureManager()
                    .getDynamicTextureLocation("aifriend_skin", dynTex);
        } catch (IOException e) {
            textureLoadFailed = true;
            AIFriendMod.instance.getLogger().error("读取伙伴皮肤partner.png失败", e);
        }
    }

    @Override
    protected ResourceLocation getEntityTexture(AIPartnerEntity entity) {
        if (textureLoadFailed || partnerTexture == null) {
            return new ResourceLocation("minecraft:textures/entity/steve.png");
        }
        return partnerTexture;
    }

    @Override
    protected void preRenderCallback(AIPartnerEntity entity, float partialTickTime) {
        super.preRenderCallback(entity, partialTickTime);
        GL11.glScalef(1.0F, 1.0F, 1.0F);
    }
}
