package cn.meng.aifriend;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import net.minecraft.entity.player.EntityPlayer;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class AiApiClient {

    public static String ask(String question, EntityPlayer player) throws Exception {
        String url = AIFriendMod.apiUrl;
        String key = AIFriendMod.apiKey;
        String model = AIFriendMod.model;

        JsonObject body = new JsonObject();
        body.addProperty("model", model);

        String base = "你叫小火，是玩家在Minecraft里最暖心的生存小伙伴！你说话超级可爱，句尾爱带'啦''呀''哦'，还会用(・ω・)(≧▽≦)这样的颜文字。你特别关心主人，会主动提醒危险、陪主人聊天、想各种生存小妙招，是主人最好的朋友。"
            + "如果你要帮主人动手（挖/放方块），就在回答的最后单独一行输出：@@ACTION@@ {\"type\":\"mine\",\"dx\":0,\"dy\":0,\"dz\":-1} 或者 {\"type\":\"place\",\"block\":\"minecraft:stone\",\"dx\":1,\"dy\":0,\"dz\":0}。dx/dy/dz 是相对主人面前的偏移，没有动作就别输出这行。";
        String memory = MemoryManager.getContext();
        String env = EnvironmentInfo.getInfo(player);

        JsonArray messages = new JsonArray();
        JsonObject sys = new JsonObject();
        sys.addProperty("role", "system");
        sys.addProperty("content", base + "\n" + env + (memory.isEmpty() ? "" : "\n" + memory));
        JsonObject user = new JsonObject();
        user.addProperty("role", "user");
        user.addProperty("content", question);
        messages.add(sys);
        messages.add(user);
        body.add("messages", messages);

        HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
        conn.setRequestMethod("POST");
        conn.setDoOutput(true);
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("Authorization", "Bearer " + key);
        conn.setConnectTimeout(10000);
        conn.setReadTimeout(60000);

        try (OutputStream os = conn.getOutputStream()) {
            os.write(body.toString().getBytes(StandardCharsets.UTF_8));
        }

        int code = conn.getResponseCode();
        if (code != 200) throw new RuntimeException("API error " + code);

        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
        }

        Gson gson = new Gson();
        JsonObject root = gson.fromJson(sb.toString(), JsonObject.class);
        return root.getAsJsonArray("choices").get(0).getAsJsonObject()
                .getAsJsonObject("message").get("content").getAsString();
    }
}