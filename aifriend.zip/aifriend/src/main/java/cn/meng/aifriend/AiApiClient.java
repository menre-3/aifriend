package cn.meng.aifriend;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import net.minecraft.entity.player.EntityPlayer;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class AiApiClient {

    /** 统一 POST 请求，返回 AI 文本 */
    private static String post(String system, String userMessage) throws Exception {
        JsonObject body = new JsonObject();
        body.addProperty("model", AIFriendMod.model);
        if (AIFriendMod.replyMaxTokens > 0) {
            body.addProperty("max_tokens", AIFriendMod.replyMaxTokens); // 输出Token硬限制
        }

        JsonArray messages = new JsonArray();
        JsonObject sys = new JsonObject();
        sys.addProperty("role", "system");
        sys.addProperty("content", system);
        JsonObject user = new JsonObject();
        user.addProperty("role", "user");
        user.addProperty("content", userMessage);
        messages.add(sys);
        messages.add(user);
        body.add("messages", messages);

        HttpURLConnection conn = (HttpURLConnection) new URL(AIFriendMod.apiUrl).openConnection();
        conn.setRequestMethod("POST");
        conn.setDoOutput(true);
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("Authorization", "Bearer " + AIFriendMod.apiKey);
        int timeoutMs = AIFriendMod.apiTimeout * 1000;
        conn.setConnectTimeout(timeoutMs);
        conn.setReadTimeout(timeoutMs);

        try (OutputStream os = conn.getOutputStream()) {
            os.write(body.toString().getBytes(StandardCharsets.UTF_8));
        }

        int code = conn.getResponseCode();
        if (code != 200) throw new RuntimeException("API error " + code);

        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(
                new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
        }

        Gson gson = new Gson();
        JsonObject root = gson.fromJson(sb.toString(), JsonObject.class);
        return root.getAsJsonArray("choices").get(0).getAsJsonObject()
                .getAsJsonObject("message").get("content").getAsString();
    }

    /** 聊天回复（纯语言，不输出指令） */
    public static String ask(String question, EntityPlayer player) throws Exception {
        String system = PromptBuilder.base() + "\n"
                + ContextBuilder.build(player, 0, "聊天");
        return post(system, question);
    }

    /** 无任务按键决策 */
    public static String decideKeys(EntityPlayer player, float partnerYaw) throws Exception {
        String system = PromptBuilder.base() + "\n" + PromptBuilder.keyProtocol() + "\n"
                + ContextBuilder.build(player, partnerYaw, "移动", "走", "挖");
        return post(system, "现在该做什么？（输出按键指令）");
    }

    /** 任务决策 */
    public static String decideTask(EntityPlayer player, String taskPrompt, float partnerYaw) throws Exception {
        String system = PromptBuilder.base() + "\n" + PromptBuilder.keyProtocol() + "\n"
                + ContextBuilder.build(player, partnerYaw, "挖", "走", "放");
        return post(system, "任务：" + taskPrompt + "\n下一步？（输出按键指令）");
    }

    /** 主动发言（只说话，不输出指令） */
    public static String speak(EntityPlayer player, String eventDesc) throws Exception {
        String system = PromptBuilder.base() + "\n"
                + ContextBuilder.build(player, 0, "聊天");
        return post(system, "事件：" + eventDesc + "\n用你的性格说一句话（只说话，不要指令）。");
    }
}