package cn.meng.aifriend.command;

import cn.meng.aifriend.entity.AIPartnerEntity;
import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;

import javax.annotation.Nullable;
import java.util.Collections;
import java.util.List;

/**
 * 移除AI伙伴命令
 */
public class CommandKillPartner extends CommandBase {

    @Override public String getName() { return "killpartner"; }

    @Override
    public String getUsage(ICommandSender sender) { return "/killpartner - 移除AI伙伴"; }

    @Override public int getRequiredPermissionLevel() { return 2; }

    @Override
    public void execute(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {
        if (!(sender instanceof EntityPlayer)) throw new CommandException("此命令只能由玩家执行");
        EntityPlayer player = (EntityPlayer) sender;
        World world = player.world;

        List<AIPartnerEntity> partners = world.getEntitiesWithinAABB(AIPartnerEntity.class, player.getEntityBoundingBox().grow(128));
        int removed = 0;
        for (AIPartnerEntity p : partners) {
            if (p.getOwnerUUID() != null && p.getOwnerUUID().equals(player.getUniqueID())) {
                if (p.getBrain() != null) p.getBrain().shutdown();
                p.setDead();
                removed++;
            }
        }
        player.sendMessage(new TextComponentString(removed > 0 ? "已移除 " + removed + " 个AI伙伴" : "你没有AI伙伴"));
    }

    @Override
    public List<String> getTabCompletions(MinecraftServer server, ICommandSender sender, String[] args, @Nullable BlockPos targetPos) {
        return Collections.emptyList();
    }
}
