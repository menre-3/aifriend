package com.aifriend.command;

import com.aifriend.entity.AIPartnerEntity;
import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;

import javax.annotation.Nullable;
import java.util.List;

/**
 * 移除AI伙伴命令
 * 用法：/killpartner
 * 移除属于当前玩家的AI伙伴
 */
public class CommandKillPartner extends CommandBase {

    @Override
    public String getName() {
        return "killpartner";
    }

    @Override
    public String getUsage(ICommandSender sender) {
        return "/killpartner - 移除你的AI伙伴";
    }

    @Override
    public int getRequiredPermissionLevel() {
        return 2;
    }

    @Override
    public void execute(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {
        if (!(sender instanceof EntityPlayer)) {
            throw new CommandException("此命令只能由玩家执行");
        }

        EntityPlayer player = (EntityPlayer) sender;
        World world = player.world;

        List<AIPartnerEntity> partners = world.getEntitiesWithinAABB(
                AIPartnerEntity.class,
                player.getEntityBoundingBox().grow(128));

        int removed = 0;
        for (AIPartnerEntity partner : partners) {
            if (partner.getOwnerUUID() != null
                    && partner.getOwnerUUID().equals(player.getUniqueID())) {
                // 关闭大脑线程
                if (partner.getBrain() != null) {
                    partner.getBrain().shutdown();
                }
                partner.setDead();
                removed++;
            }
        }

        if (removed > 0) {
            player.sendMessage(new TextComponentString("已移除 " + removed + " 个AI伙伴"));
        } else {
            player.sendMessage(new TextComponentString("你没有AI伙伴"));
        }
    }

    @Override
    public List<String> getTabCompletions(MinecraftServer server, ICommandSender sender,
                                          String[] args, @Nullable BlockPos targetPos) {
        return java.util.Collections.emptyList();
    }
}
