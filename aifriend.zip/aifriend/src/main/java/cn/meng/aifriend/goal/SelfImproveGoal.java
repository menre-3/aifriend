package com.aifriend.goal;

import com.aifriend.AIFriendConfig;
import com.aifriend.api.IPartnerBody;
import net.minecraft.item.ItemStack;

/**
 * 自我提升目标
 * 检查并装备更好的护甲、武器，整理背包，确保生存能力
 *
 * 行为：
 * 1. 检查背包中是否有更好的护甲，有就装备
 * 2. 检查是否有更好的武器，有就装备
 * 3. 整理背包（合并相同物品）
 * 4. 检查生命值，低就吃食物
 * 5. 完成后进入空闲
 */
public class SelfImproveGoal implements IGoal {

    private final AIFriendConfig config;
    private boolean active = false;
    private int checkTimer = 0;
    private long lastCheckTick = 0;

    public SelfImproveGoal(AIFriendConfig config) {
        this.config = config;
    }

    @Override
    public String getName() { return "自我提升"; }

    @Override
    public int getPriority() { return 30; } // 成长级优先级（高于工作，低于避险）

    @Override
    public boolean shouldStart(IPartnerBody body) {
        if (active) return false;
        if (!config.isEnableSelfImprove()) return false;
        // 检查间隔
        long currentTick = body.getWorld().getTotalWorldTime();
        if (currentTick - lastCheckTick < config.getSelfImproveIntervalTicks()) return false;

        // 有更好的装备可换
        return hasBetterEquipment(body);
    }

    @Override
    public void start(IPartnerBody body) {
        active = true;
        checkTimer = 0;
    }

    @Override
    public boolean update(IPartnerBody body) {
        checkTimer++;
        if (checkTimer > 20) {
            // 执行提升
            boolean improved = false;
            if (body.getInventory().equipBetterArmor()) improved = true;
            if (body.getInventory().equipBetterWeapon()) improved = true;
            body.getInventory().sortInventory();

            // 检查生命值
            if (body.getHealth() < body.getMaxHealth() * 0.5) {
                body.getInventory().eatFood();
            }

            lastCheckTick = body.getWorld().getTotalWorldTime();
            return false; // 完成
        }
        return true;
    }

    @Override
    public void stop(IPartnerBody body) {
        active = false;
    }

    @Override
    public boolean isActive() { return active; }

    @Override
    public String getDescription() {
        return "正在检查并提升装备";
    }

    /**
     * 检查是否有更好的装备可换
     */
    private boolean hasBetterEquipment(IPartnerBody body) {
        // 简化检查：背包中有护甲或武器就算
        for (ItemStack stack : body.getInventory().getAllItems()) {
            if (stack.getItem() instanceof net.minecraft.item.ItemArmor) return true;
            if (stack.getItem() instanceof net.minecraft.item.ItemSword) return true;
        }
        return false;
    }
}
