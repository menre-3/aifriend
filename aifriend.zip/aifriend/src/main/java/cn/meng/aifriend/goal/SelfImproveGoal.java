package cn.meng.aifriend.goal;

import cn.meng.aifriend.AIFriendConfig;
import cn.meng.aifriend.api.IPartnerBody;
import net.minecraft.item.ItemStack;

/**
 * 自我提升目标
 */
public class SelfImproveGoal implements IGoal {

    private final AIFriendConfig config;
    private boolean active = false;
    private int checkTimer = 0;
    private long lastCheckTick = 0;

    public SelfImproveGoal(AIFriendConfig config) {
        this.config = config;
    }

    @Override public String getName() { return "自我提升"; }
    @Override public int getPriority() { return 30; }
    @Override public boolean isActive() { return active; }

    @Override
    public boolean shouldStart(IPartnerBody body) {
        if (active || !config.enableSelfImprove) return false;
        long tick = body.getWorldObject().getTotalWorldTime();
        if (tick - lastCheckTick < config.selfImproveIntervalTicks) return false;
        for (ItemStack stack : body.getInventory().getAllItems()) {
            if (stack.getItem() instanceof net.minecraft.item.ItemArmor) return true;
            if (stack.getItem() instanceof net.minecraft.item.ItemSword) return true;
        }
        return false;
    }

    @Override
    public void start(IPartnerBody body) {
        active = true;
        checkTimer = 0;
    }

    @Override
    public boolean update(IPartnerBody body) {
        checkTimer++;
        if (checkTimer > 20) {
            body.getInventory().equipBetterArmor();
            body.getInventory().equipBetterWeapon();
            body.getInventory().sortInventoryNow();
            if (body.getHealthValue() < body.getMaxHealthValue() * 0.5) {
                body.getInventory().eatFoodNow();
            }
            lastCheckTick = body.getWorldObject().getTotalWorldTime();
            return false;
        }
        return true;
    }

    @Override
    public void stop(IPartnerBody body) {
        active = false;
    }

    @Override
    public String getDescription() {
        return "检查并提升装备";
    }
}
